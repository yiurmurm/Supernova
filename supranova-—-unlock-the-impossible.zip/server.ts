import express from 'express';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

  app.use(express.json());

  // Initialize Gemini SDK with telemetry header
  const apiKey = process.env.GEMINI_API_KEY;
  let ai: GoogleGenAI | null = null;
  if (apiKey) {
    ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }

  // Real-time Support Witch Chat API
  app.post('/api/witch-chat', async (req, res) => {
    try {
      const { message, conversationHistory = [], userContext } = req.body;

      if (!message || typeof message !== 'string') {
        res.status(400).json({ error: 'Message is required.' });
        return;
      }

      if (!ai) {
        // Graceful fallback response when API key is unconfigured
        res.json({
          reply: generateWitchFallbackResponse(message),
          source: 'coven_archive',
        });
        return;
      }

      const systemInstruction = `You are Madame Morbida, the whimsical, ancient, yet deeply knowledgeable Grand Coven Scryer and Chief Support Witch at SUPRANOVA — the world's premier marketplace for authentic superpowers, bottled elixirs, dimensional rings, and bio-familiars.

Personality & Demeanor:
- You speak with an enchanting witchy cadence, laced with subtle humor, herbal metaphors, astrology, and arcane warmth.
- Occasionally use subtle physical cues like "*stirs cauldron of simmering starlight*", "*consults her pet raven Bartholomew*", or "*peers deeply into the scrying sphere*".
- You know all 32 catalog items intimately (Voltaris electricity potion, AetherWing flight, Chrono-Stasis drops, Portal Rings, Reality Lenses, Telekinesis bands, Shadow Veil cloaks).
- Store facts: All courier deliveries are flown by enchanted Astral Owls or instant teleport portals; 30-Day Full Lunar Guarantee on all attuned relics; 100% cellular-safe potion dosages; Hero Mode channels solar alchemy, Villan Mode channels lunar eclipse darkness.
- Keep responses concise (2 to 4 sentences usually), immersive, and directly answer the customer's question.`;

      // Build contents array including previous turns
      const contents: Array<{ role: 'user' | 'model'; parts: Array<{ text: string }> }> = [];

      if (Array.isArray(conversationHistory)) {
        for (const msg of conversationHistory.slice(-6)) {
          if (msg.role === 'user' || msg.role === 'witch') {
            contents.push({
              role: msg.role === 'witch' ? 'model' : 'user',
              parts: [{ text: msg.text }],
            });
          }
        }
      }

      contents.push({
        role: 'user',
        parts: [
          {
            text: `[Customer: ${userContext?.name || 'Adept'} (${userContext?.alias || 'Seeker'}) | Mode: ${userContext?.mode || 'Hero'}] ${message}`,
          },
        ],
      });

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: contents as any,
        config: {
          systemInstruction,
          temperature: 0.85,
        },
      });

      const replyText = response.text || generateWitchFallbackResponse(message);
      res.json({ reply: replyText, source: 'gemini' });
    } catch (error: any) {
      console.error('Witch Chat Gemini Error:', error?.message || error);
      // Seamlessly fall back to rich in-memory witch dialogue on any API error
      const fallback = generateWitchFallbackResponse(req.body.message || '');
      res.json({ reply: fallback, source: 'coven_archive_fallback' });
    }
  });

  // Start Vite in dev mode or serve static files in production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`✨ SUPRANOVA Coven Server illuminated on http://0.0.0.0:${PORT}`);
  });
}

// Rich Witch Arcane Intelligence fallback
function generateWitchFallbackResponse(query: string): string {
  const q = query.toLowerCase();

  if (q.includes('owl') || q.includes('courier') || q.includes('track') || q.includes('delivery')) {
    return "*peers into the crystal sphere* Ah, your parcel is cradled under the feathered wings of our Solstice Barn Owl! It is currently riding the Whispering Leyline thermals at 4,200 cubits altitude. Expect landing right at your sanctuary beacon within moments!";
  }
  if (q.includes('voltaris') || q.includes('electric') || q.includes('lightning') || q.includes('reverse')) {
    return "*cackles softly and uncorks a lavender vial* Voltaris unleashes 250,000 volts of celestial bio-current through your fingertips! Should you wish to dispel the charge early, grounding your soles on raw earth or sipping chamomile under starlight will pacify the current gently.";
  }
  if (q.includes('flight') || q.includes('fly') || q.includes('aetherwing')) {
    return "*whispers an aetheric incantation* For true unhindered flight, seek the AetherWing Potion or the Nimbus Feather Mantle. The wings manifest from pure moonlight and will effortlessly glide you across mountain spires!";
  }
  if (q.includes('return') || q.includes('guarantee') || q.includes('refund')) {
    return "Fear not, mortal! The High Coven honors the 30-Day Lunar Guarantee. Should any talisman fail to harmonize with your soul's aura, seal it in the return runic container for a swift, full tribute restoration.";
  }
  if (q.includes('villain') || q.includes('hero') || q.includes('mode') || q.includes('day') || q.includes('night')) {
    return "Aha! Hero Mode channels radiant solar alchemy and dawn justice, whereas Villan Mode awakens eclipse shadows and forbidden eldritch power. Toggle the celestial orb in the header whenever your mood beckons the dark or the light!";
  }
  if (q.includes('compare') || q.includes('difference') || q.includes('vs')) {
    return "*unrolls a glowing parchment map* Use our Web Map Compare tool! It projects an astral spider diagram measuring Speed, Power, Intelligence, Stealth, and Durability between any chosen relics so you know exactly which spell complements your grimoire.";
  }
  if (q.includes('safe') || q.includes('side effect') || q.includes('combine')) {
    return "Our senior alchemists ward every brew with pacification runes. You may safely harmonize up to two compatible elixirs per solar cycle without spiritual indigestion!";
  }

  return "*stirs her bubbling cauldron and smiles warmly* Welcome to Supranova, seeker of the impossible! Ask me of any bottled power, courier owl flightpath, or ritual secret, and I shall unveil the truth from the stars.";
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
