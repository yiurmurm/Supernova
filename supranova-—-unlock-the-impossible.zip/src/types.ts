export type CategoryId = 'potions' | 'sprays' | 'accessories' | 'insects' | 'eyewear';

export type Rarity = 'Common' | 'Uncommon' | 'Rare' | 'Epic' | 'Legendary' | 'Mythic' | 'Cosmic' | 'God-Tier';

export type Archetype = 'Tech-Enhanced' | 'Mutant' | 'Mystic' | 'Cosmic';

export interface PowerStats {
  speed: number;
  power: number;
  intelligence: number;
  stealth: number;
  durability: number;
}

export interface Product {
  id: string;
  name: string;
  category: CategoryId;
  price: number;
  originalPrice?: number;
  rating: number;
  reviewsCount: number;
  rarity: Rarity;
  archetype: Archetype;
  shortDesc: string;
  fullDesc: string;
  howItWorks: string;
  magicType: string;
  duration: string;
  powerLevel: number; // e.g. 8500
  powerGrade: string; // e.g. "S-Rank"
  compatibility: string;
  lore: string;
  stats: PowerStats;
  image: string;
  inStock: boolean;
  isBestseller?: boolean;
  isNewArrival?: boolean;
  isLimitedEdition?: boolean;
  variants?: string[];
  specs: { label: string; value: string }[];
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedVariant?: string;
}

export interface SavedItem {
  product: Product;
  savedAt: string;
}

export interface Order {
  id: string;
  date: string;
  items: CartItem[];
  total: number;
  status: 'Teleport Queued' | 'Sonic In-Transit' | 'Delivered' | 'Returned';
  deliveryMode: 'Teleport Dispatch' | 'Sonic Drone' | 'Subterranean Transport';
  dispatchDistance: string;
  trackingStep: number; // 1 to 4
  shippingAddress: {
    alias: string;
    street: string;
    coordinates: { lat: number; lng: number };
  };
}

export interface SupportTicket {
  id: string;
  issueType: string;
  subject: string;
  message: string;
  orderId?: string;
  status: 'Submitted' | 'Under Review' | 'In Progress' | 'Resolved';
  submittedAt: string;
  witchDiagnosis: string;
}

export interface CustomerReview {
  id: string;
  author: string;
  title: string;
  badge: string; // e.g. "Verified Wizard ✦", "S-Class Hero ✦"
  rating: number;
  comment: string;
  productName: string;
  date: string;
}
