import React, { useState } from 'react';
import { SuperProvider, useSuper } from './context/SuperContext';
import { CustomCursor } from './components/CustomCursor';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { CategoryShowcase } from './components/CategoryShowcase';
import { ProductCard } from './components/ProductCard';
import { PowerQuiz } from './components/PowerQuiz';
import { ProductDetailPage } from './components/ProductDetailPage';
import { CategoryPage } from './components/CategoryPage';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutPage } from './components/CheckoutPage';
import { AccountDossier } from './components/AccountDossier';
import { HelpCenter } from './components/HelpCenter';
import { ReviewsSection } from './components/ReviewsSection';
import { LoginModal } from './components/LoginModal';
import { LoginPage } from './components/LoginPage';
import { ProductCompareModal } from './components/ProductCompareModal';
import { CompareFloatingBar } from './components/CompareFloatingBar';
import { SupportWitchChatbot } from './components/SupportWitchChatbot';
import { QuickViewModal } from './components/QuickViewModal';
import { Footer } from './components/Footer';
import { PRODUCTS } from './data/products';
import { Product } from './types';
import { Sparkles, ArrowRight, Moon, Compass } from 'lucide-react';

const MainContent: React.FC = () => {
  const {
    currentView,
    selectedCategoryId,
    selectedProductId,
    navigateTo,
    flashBanner,
    isVillainMode,
    triggerSoundFx,
  } = useSuper();

  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);

  // Bestsellers for home grid
  const featuredProducts = PRODUCTS.filter((p) => p.isBestseller).slice(0, 6);

  return (
    <div className="min-h-screen bg-[#0d0814] dark:bg-[#050308] text-white flex flex-col selection:bg-[#D4AF37] selection:text-black transition-colors duration-400">
      {/* Custom Twinkling Star & Moon Cursor Trail */}
      <CustomCursor />

      {/* Secret Villain Mode Flashed Banner Overlay */}
      {flashBanner && (
        <div className="fixed top-20 inset-x-0 z-50 flex justify-center pointer-events-none animate-bounce">
          <div className="px-6 py-3 rounded-2xl bg-[#9333EA] border border-[#FDE047] text-white font-witch text-base uppercase tracking-wider shadow-[0_0_20px_rgba(245,158,11,0.5)]">
            {flashBanner}
          </div>
        </div>
      )}

      {/* Global Navigation Top Bar */}
      <Navbar />

      {/* Main View Router */}
      <main className="flex-1">
        {currentView === 'home' && (
          <>
            {/* 1. Hero Section with Interactive Moon & Star Picture Showcase */}
            <HeroSection />

            {/* 2. Featured Powers Arcane Grid */}
            <section className="py-20 bg-[#0d0814] dark:bg-[#050308] border-b border-[#2d1b46]/70 transition-colors duration-400">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
                <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-xs font-whimsical uppercase text-[#FDE047] font-semibold tracking-wider">
                      <Sparkles className="w-3.5 h-3.5" /> Revered by the High Coven
                    </div>
                    <h2 className="font-witch text-3xl sm:text-4xl text-white tracking-wide">
                      Popular Superpowers & Relics
                    </h2>
                    <p className="font-whimsical text-purple-200/80 text-sm max-w-lg">
                      Attuned by our senior practitioners. Verified instant metamorphic activation.
                    </p>
                  </div>

                  <button
                    onClick={() => {
                      navigateTo('shop');
                      triggerSoundFx('✧ Browse All Arcana');
                    }}
                    className="flex items-center gap-1.5 text-xs font-whimsical font-bold uppercase tracking-wider text-[#FDE047] hover:underline"
                  >
                    <span>Browse All 32 Powers</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>

                {/* Arcane Product Card Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {featuredProducts.map((p) => (
                    <ProductCard
                      key={p.id}
                      product={p}
                      onQuickView={(prod) => setQuickViewProduct(prod)}
                    />
                  ))}
                </div>
              </div>
            </section>

            {/* 3. Choose Your Power — 5 Category Grimoires */}
            <CategoryShowcase />

            {/* 4. Grand Celestial Moon & Star Chart Interlude Banner */}
            <section className="py-16 bg-[#170e24] border-b border-[#2d1b46]/70 relative overflow-hidden">
              {/* Background ambient stars */}
              <div className="pointer-events-none absolute inset-0 bg-celestial-stars opacity-40" />

              <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                  {/* Left Column: Story & Call to Action */}
                  <div className="lg:col-span-6 space-y-4">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#0d0814] border border-[#D4AF37]/40 text-xs font-whimsical uppercase text-[#FDE047]">
                      <Moon className="w-3.5 h-3.5 text-[#FDE047]" />
                      <span>Celestial Lunar Alignment</span>
                    </div>

                    <h3 className="font-witch text-3xl sm:text-4xl lg:text-5xl text-white tracking-wide leading-tight">
                      When the Full Moon Rises, <br />
                      <span className="text-[#FDE047] drop-shadow-[0_0_20px_rgba(253,224,71,0.4)]">
                        Your Powers Surge +40%
                      </span>
                    </h3>

                    <p className="font-whimsical text-purple-200/90 text-sm sm:text-base leading-relaxed max-w-xl">
                      Ancient astronomical charts reveal that lunar tides amplify all ring portals and bottled starlight elixirs. Align your ritual with the celestial constellations to unlock transcendent potential.
                    </p>

                    <div className="flex flex-wrap gap-3 pt-2">
                      <button
                        onClick={() => navigateTo('product', { productId: 'potion-aetherwing' })}
                        className="px-6 py-3 rounded-xl font-whimsical text-xs uppercase tracking-wider text-black font-bold bg-[#D4AF37] hover:bg-[#FDE047] shadow-[0_0_16px_rgba(212,175,55,0.3)] transition-all hover:-translate-y-0.5 flex items-center gap-2"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Inspect AetherWing Flight</span>
                      </button>

                      <button
                        onClick={() => navigateTo('quiz')}
                        className="px-6 py-3 rounded-xl font-whimsical text-xs uppercase tracking-wider text-purple-200 bg-[#0d0814] border border-[#D4AF37]/40 hover:border-[#FDE047] hover:text-[#FDE047] transition-all"
                      >
                        <span>Oracle Power Quiz</span>
                      </button>
                    </div>
                  </div>

                  {/* Right Column: Pictures of Moons and Constellation Star Chart */}
                  <div className="lg:col-span-6 grid grid-cols-2 gap-4">
                    {/* Moon Photo Card */}
                    <div className="relative rounded-2xl overflow-hidden border border-[#D4AF37]/40 arcane-card aspect-[4/3] group shadow-xl">
                      <img
                        src="/src/assets/images/celestial_moon_stars_1790162488603.jpg"
                        alt="Enchanted Full Moon in Starry Nebula"
                        className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#0d0814] via-transparent to-black/20" />
                      <div className="absolute bottom-3 left-3 right-3 p-2 rounded-xl bg-[#0d0814]/85 backdrop-blur-sm border border-[#D4AF37]/30">
                        <div className="flex items-center gap-1.5 text-[10px] font-whimsical uppercase text-[#FDE047]">
                          <span>✦ Harvest Moon Tide</span>
                        </div>
                        <div className="font-witch text-xs text-white">Full Moon Arcana</div>
                      </div>
                    </div>

                    {/* Zodiac Star Chart Photo Card */}
                    <div className="relative rounded-2xl overflow-hidden border border-[#D4AF37]/40 arcane-card aspect-[4/3] group shadow-xl">
                      <img
                        src="/src/assets/images/star_chart_nebula_1790162515204.jpg"
                        alt="Zodiac Constellation Star Chart"
                        className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#0d0814] via-transparent to-black/20" />
                      <div className="absolute bottom-3 left-3 right-3 p-2 rounded-xl bg-[#0d0814]/85 backdrop-blur-sm border border-[#D4AF37]/30">
                        <div className="flex items-center gap-1.5 text-[10px] font-whimsical uppercase text-purple-300">
                          <Compass className="w-3 h-3" />
                          <span>✧ Astral Map</span>
                        </div>
                        <div className="font-witch text-xs text-white">Zodiac Star Chart</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* 5. What’s Your Superpower? Oracle Quiz */}
            <PowerQuiz />

            {/* 6. Customer Testaments & High Coven Reviews */}
            <ReviewsSection />
          </>
        )}

        {currentView === 'shop' && <CategoryPage />}

        {currentView === 'category' && (
          <CategoryPage initialCategoryId={selectedCategoryId} />
        )}

        {currentView === 'product' && (
          <ProductDetailPage productId={selectedProductId} />
        )}

        {currentView === 'quiz' && <PowerQuiz />}

        {currentView === 'checkout' && <CheckoutPage />}

        {currentView === 'account' && <AccountDossier />}

        {currentView === 'login' && <LoginPage />}

        {currentView === 'help' && <HelpCenter />}
      </main>

      {/* Global Modals & Drawers */}
      <CartDrawer />
      <LoginModal />
      <ProductCompareModal />
      <CompareFloatingBar />
      <SupportWitchChatbot />
      <QuickViewModal
        product={quickViewProduct}
        onClose={() => setQuickViewProduct(null)}
      />

      {/* Global Multi-Column Footer */}
      <Footer />
    </div>
  );
};

export function App() {
  return (
    <SuperProvider>
      <MainContent />
    </SuperProvider>
  );
}

export default App;
