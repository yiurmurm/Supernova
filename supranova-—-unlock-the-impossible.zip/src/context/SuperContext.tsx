import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product, CartItem, Order, SupportTicket, CustomerReview, CategoryId } from '../types';
import { PRODUCTS, INITIAL_REVIEWS } from '../data/products';

interface Onomatopoeia {
  id: string;
  text: string;
  x: number;
  y: number;
  color: string;
}

interface SuperContextType {
  // Navigation
  currentView: string;
  selectedCategoryId: CategoryId | null;
  selectedProductId: string | null;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  navigateTo: (view: string, options?: { categoryId?: CategoryId; productId?: string }) => void;

  // Cart & Utility Belt
  cart: CartItem[];
  savedItems: Product[];
  addToCart: (product: Product, quantity?: number, variant?: string) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  saveForLater: (product: Product) => void;
  moveSavedToCart: (product: Product) => void;
  removeSaved: (productId: string) => void;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  appliedCoupon: string | null;
  discountRate: number;
  applyCoupon: (code: string) => { success: boolean; message: string };
  cartSubtotal: number;
  cartDiscount: number;
  cartShipping: number;
  cartTax: number;
  cartTotal: number;
  utilityBeltPercent: number;

  // Wishlist
  wishlist: string[];
  toggleWishlist: (productId: string) => void;
  isInWishlist: (productId: string) => boolean;

  // Compare System
  comparedProductIds: string[];
  addToCompare: (productId: string) => void;
  removeFromCompare: (productId: string) => void;
  toggleCompare: (productId: string) => void;
  clearCompare: () => void;
  isCompareOpen: boolean;
  setIsCompareOpen: (open: boolean) => void;
  isInCompare: (productId: string) => boolean;

  // User Profile / Dossier
  user: {
    name: string;
    email: string;
    alias: string;
    rank: string;
    powerScore: number;
    synergyGauge: number;
    avatar: string;
    hideoutAddress: string;
    hideoutCoords: { lat: number; lng: number };
    affinity?: string;
  };
  isLoggedIn: boolean;
  isLoginModalOpen: boolean;
  setIsLoginModalOpen: (open: boolean) => void;
  loginUser: (email: string, alias?: string) => void;
  signUpUser: (details: {
    name: string;
    alias: string;
    email: string;
    address?: string;
    affinity?: string;
    roleOath?: string;
  }) => void;
  logoutUser: () => void;
  updateUserAlias: (alias: string) => void;

  // Theme & Easter Eggs
  isVillainMode: boolean;
  toggleVillainMode: () => void;
  powerSurge: number;
  setPowerSurge: (level: number) => void;
  flashBanner: string | null;

  // Onomatopoeia FX
  onomatopoeiaList: Onomatopoeia[];
  triggerSoundFx: (text?: string, x?: number, y?: number) => void;

  // Orders & Tracking
  orders: Order[];
  placeOrder: (deliveryMode: Order['deliveryMode'], customAddress?: string, coords?: { lat: number; lng: number }) => Order;
  activeOrder: Order | null;
  setActiveOrder: (order: Order | null) => void;

  // Support Witch
  tickets: SupportTicket[];
  submitSupportTicket: (issueType: string, subject: string, message: string, orderId?: string) => SupportTicket;

  // Reviews
  reviews: CustomerReview[];
  addCustomerReview: (productName: string, author: string, title: string, rating: number, comment: string) => void;
}

const SuperContext = createContext<SuperContextType | undefined>(undefined);

const WITCHY_INCANTATIONS = ['✨ Essence Attuned', '✦ Spell Bound', '✧ Starlight Brewed', '✦ Seal Inscribed'];

export const SuperProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Navigation State
  const [currentView, setCurrentView] = useState<string>('home');
  const [selectedCategoryId, setSelectedCategoryId] = useState<CategoryId | null>(null);
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Cart State
  const [cart, setCart] = useState<CartItem[]>(() => {
    const voltar = PRODUCTS.find((p) => p.id === 'potion-voltaris');
    return voltar ? [{ product: voltar, quantity: 1, selectedVariant: 'Standard (100ml)' }] : [];
  });
  const [savedItems, setSavedItems] = useState<Product[]>([]);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [appliedCoupon, setAppliedCoupon] = useState<string | null>(null);
  const [discountRate, setDiscountRate] = useState<number>(0);

  // Wishlist State
  const [wishlist, setWishlist] = useState<string[]>(['potion-voltaris', 'jewel-portalring', 'eye-realitylens']);

  // Compare State (Up to 4 products)
  const [comparedProductIds, setComparedProductIds] = useState<string[]>([
    'potion-voltaris',
    'potion-aetherwing',
  ]);
  const [isCompareOpen, setIsCompareOpen] = useState<boolean>(false);

  // User State
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(true);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState<boolean>(false);
  const [user, setUser] = useState({
    name: 'Rajesh P. Bathija',
    email: 'bathijarajeshp@gmail.com',
    alias: 'High Alchemist Bathija',
    rank: 'High Coven Adept',
    powerScore: 9480,
    synergyGauge: 92,
    avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=supranova-hero&backgroundColor=0b0a10',
    hideoutAddress: 'Sanctuary Spire 44, Mystic Haven',
    hideoutCoords: { lat: 37.7749, lng: -122.4194 },
    affinity: 'Celestial Solar',
  });

  // Theme & Modes (Day: Hero Mode | Night: Villan Mode)
  const [isVillainMode, setIsVillainMode] = useState<boolean>(false);
  const [powerSurge, setPowerSurge] = useState<number>(65);
  const [flashBanner, setFlashBanner] = useState<string | null>(null);

  // Sound FX (Subtle mystical notifications)
  const [onomatopoeiaList, setOnomatopoeiaList] = useState<Onomatopoeia[]>([]);

  // Orders State
  const [orders, setOrders] = useState<Order[]>([
    {
      id: 'SN-90821-X',
      date: 'Sept 21, 2026',
      items: [
        {
          product: PRODUCTS.find((p) => p.id === 'jewel-portalring') || PRODUCTS[0],
          quantity: 1,
          selectedVariant: 'Forged Meteorite (Standard)',
        },
      ],
      total: 480,
      status: 'Sonic In-Transit',
      deliveryMode: 'Sonic Drone',
      dispatchDistance: '3.8 Light-Minutes from HQ',
      trackingStep: 3,
      shippingAddress: {
        alias: 'Subterranean Bunker Alpha',
        street: '404 Nexus Way, Sky-Dock 12',
        coordinates: { lat: 37.7749, lng: -122.4194 },
      },
    },
  ]);
  const [activeOrder, setActiveOrder] = useState<Order | null>(orders[0]);

  // Support Tickets
  const [tickets, setTickets] = useState<SupportTicket[]>([
    {
      id: 'TCK-772',
      issueType: 'Track Order',
      subject: 'Portal Ring Resonance Query',
      message: 'Will the dimensional portal synchronize if I am 200 feet below sea level?',
      orderId: 'SN-90821-X',
      status: 'In Progress',
      submittedAt: 'Yesterday, 14:20',
      witchDiagnosis: 'The High Witch confirms: Quenched volcanic stone maintains dimensional stability up to 1 league under oceanic pressure.',
    },
  ]);

  // Reviews
  const [reviews, setReviews] = useState<CustomerReview[]>(INITIAL_REVIEWS);

  // Update CSS variable on Power Surge
  useEffect(() => {
    document.documentElement.style.setProperty('--power-surge', powerSurge.toString());
  }, [powerSurge]);

  // Villain / Hero Mode Toggle Class on Body
  useEffect(() => {
    if (isVillainMode) {
      document.body.classList.add('villain-mode');
      document.body.classList.remove('hero-mode');
    } else {
      document.body.classList.remove('villain-mode');
      document.body.classList.add('hero-mode');
    }
  }, [isVillainMode]);

  // Konami Code Easter Egg Listener
  useEffect(() => {
    const konamiSequence = [
      'ArrowUp',
      'ArrowUp',
      'ArrowDown',
      'ArrowDown',
      'ArrowLeft',
      'ArrowRight',
      'ArrowLeft',
      'ArrowRight',
      'b',
      'a',
    ];
    let cursor = 0;

    const onKeyDown = (e: KeyboardEvent) => {
      const key = e.key;
      if (key.toLowerCase() === konamiSequence[cursor].toLowerCase()) {
        cursor++;
        if (cursor === konamiSequence.length) {
          setIsVillainMode((prev) => !prev);
          triggerSoundFx('VILLAN NIGHT REALM AWAKENED', window.innerWidth / 2, window.innerHeight / 2);
          setFlashBanner('🌙 NIGHT REALM: VILLAN MODE AWAKENED');
          setTimeout(() => setFlashBanner(null), 3000);
          cursor = 0;
        }
      } else {
        cursor = 0;
      }
    };

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  const triggerSoundFx = (text?: string, x?: number, y?: number) => {
    const word = text || WITCHY_INCANTATIONS[Math.floor(Math.random() * WITCHY_INCANTATIONS.length)];
    const posX = x !== undefined ? x : Math.random() * (window.innerWidth - 200) + 100;
    const posY = y !== undefined ? y : Math.random() * (window.innerHeight - 200) + 100;
    const colors = ['#D4AF37', '#FDE047', '#C084FC', '#A855F7', '#F59E0B'];
    const color = colors[Math.floor(Math.random() * colors.length)];

    const newFx: Onomatopoeia = {
      id: Math.random().toString(36).substring(7),
      text: word,
      x: posX,
      y: posY,
      color,
    };

    setOnomatopoeiaList((prev) => [...prev, newFx]);
    setTimeout(() => {
      setOnomatopoeiaList((prev) => prev.filter((item) => item.id !== newFx.id));
    }, 1200);
  };

  const navigateTo = (view: string, options?: { categoryId?: CategoryId; productId?: string }) => {
    if (options?.categoryId) setSelectedCategoryId(options.categoryId);
    if (options?.productId) setSelectedProductId(options.productId);
    setCurrentView(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
    triggerSoundFx('✧ Grimoire Opened');
  };

  // Cart Handlers
  const addToCart = (product: Product, quantity = 1, variant?: string) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id && item.selectedVariant === variant);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id && item.selectedVariant === variant
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { product, quantity, selectedVariant: variant || product.variants?.[0] }];
    });
    triggerSoundFx('✨ Elixir Attuned');
    setIsCartOpen(true);
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
    triggerSoundFx('POP!');
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) => (item.product.id === productId ? { ...item, quantity } : item))
    );
  };

  const saveForLater = (product: Product) => {
    removeFromCart(product.id);
    if (!savedItems.some((p) => p.id === product.id)) {
      setSavedItems((prev) => [...prev, product]);
    }
    triggerSoundFx('SAVED!');
  };

  const moveSavedToCart = (product: Product) => {
    setSavedItems((prev) => prev.filter((p) => p.id !== product.id));
    addToCart(product, 1);
  };

  const removeSaved = (productId: string) => {
    setSavedItems((prev) => prev.filter((p) => p.id !== productId));
  };

  const applyCoupon = (code: string) => {
    const clean = code.trim().toUpperCase();
    if (clean === 'HERO10') {
      setAppliedCoupon('HERO10');
      setDiscountRate(0.1);
      triggerSoundFx('DISCOUNT 10%!');
      return { success: true, message: 'Hero Discount Applied: 10% Off!' };
    }
    if (clean === 'SUPRA25') {
      setAppliedCoupon('SUPRA25');
      setDiscountRate(0.25);
      triggerSoundFx('CRITICAL 25%!');
      return { success: true, message: 'Overcharge Code: 25% Off Entire Cart!' };
    }
    if (clean === 'SPOOKY20') {
      setAppliedCoupon('SPOOKY20');
      setDiscountRate(0.2);
      triggerSoundFx('DARK MAGIC 20%!');
      return { success: true, message: 'Dark Magic Sale: 20% Off Applied!' };
    }
    return { success: false, message: 'Invalid Power Glyph Code.' };
  };

  // Cart Calculations
  const cartSubtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const cartDiscount = cartSubtotal * discountRate;
  const cartShipping = cartSubtotal > 250 || cart.length === 0 ? 0 : 25;
  const cartTax = Math.round((cartSubtotal - cartDiscount) * 0.08);
  const cartTotal = Math.max(0, cartSubtotal - cartDiscount + cartShipping + cartTax);
  const totalItemCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const utilityBeltPercent = Math.min(100, Math.round((totalItemCount / 8) * 100));

  // Wishlist Handlers
  const toggleWishlist = (productId: string) => {
    setWishlist((prev) => {
      const exists = prev.includes(productId);
      if (exists) {
        triggerSoundFx('RELEASED!');
        return prev.filter((id) => id !== productId);
      } else {
        triggerSoundFx('EQUIPPED!');
        return [...prev, productId];
      }
    });
  };

  const isInWishlist = (productId: string) => wishlist.includes(productId);

  // Compare Handlers
  const addToCompare = (productId: string) => {
    setComparedProductIds((prev) => {
      if (prev.includes(productId)) return prev;
      if (prev.length >= 4) {
        return [...prev.slice(1), productId];
      }
      return [...prev, productId];
    });
    triggerSoundFx('✦ Added to Web Map');
  };

  const removeFromCompare = (productId: string) => {
    setComparedProductIds((prev) => prev.filter((id) => id !== productId));
    triggerSoundFx('✦ Removed from Map');
  };

  const toggleCompare = (productId: string) => {
    if (comparedProductIds.includes(productId)) {
      removeFromCompare(productId);
    } else {
      addToCompare(productId);
    }
  };

  const clearCompare = () => {
    setComparedProductIds([]);
    triggerSoundFx('✦ Map Cleared');
  };

  const isInCompare = (productId: string) => comparedProductIds.includes(productId);

  // User Handlers
  const loginUser = (email: string, alias?: string) => {
    setIsLoggedIn(true);
    setUser((prev) => ({
      ...prev,
      email,
      alias: alias || 'Apex Vanguard',
    }));
    triggerSoundFx('IDENTITY VERIFIED!');
    setIsLoginModalOpen(false);
  };

  const signUpUser = (details: {
    name: string;
    alias: string;
    email: string;
    address?: string;
    affinity?: string;
    roleOath?: string;
  }) => {
    setIsLoggedIn(true);
    setUser((prev) => ({
      ...prev,
      name: details.name,
      alias: details.alias,
      email: details.email,
      hideoutAddress: details.address || prev.hideoutAddress,
      affinity: details.affinity || 'Celestial Solar',
      powerScore: Math.floor(8900 + Math.random() * 1100),
      synergyGauge: 96,
      avatar: `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(details.alias)}&backgroundColor=0b0a10`,
    }));
    triggerSoundFx('✦ COVENANT SEALED');
    setIsLoginModalOpen(false);
  };

  const logoutUser = () => {
    setIsLoggedIn(false);
    triggerSoundFx('DISENGAGED');
  };

  const updateUserAlias = (alias: string) => {
    setUser((prev) => ({ ...prev, alias }));
    triggerSoundFx('ALIAS UPDATED');
  };

  const toggleVillainMode = () => {
    setIsVillainMode((prev) => !prev);
    triggerSoundFx(isVillainMode ? 'HERO PROTOCOL' : 'VILLAIN OVERCHARGE');
  };

  // Place Order
  const placeOrder = (
    deliveryMode: Order['deliveryMode'],
    customAddress?: string,
    coords?: { lat: number; lng: number }
  ): Order => {
    const orderNum = Math.floor(10000 + Math.random() * 90000);
    const newOrder: Order = {
      id: `SN-${orderNum}-Ω`,
      date: 'Just Now',
      items: [...cart],
      total: cartTotal,
      status: deliveryMode === 'Teleport Dispatch' ? 'Teleport Queued' : 'Sonic In-Transit',
      deliveryMode,
      dispatchDistance: deliveryMode === 'Teleport Dispatch' ? '0.0 Instant Portal' : '4.2 Light-Minutes from HQ',
      trackingStep: 1,
      shippingAddress: {
        alias: user.alias + ' Hideout',
        street: customAddress || user.hideoutAddress,
        coordinates: coords || user.hideoutCoords,
      },
    };

    setOrders((prev) => [newOrder, ...prev]);
    setActiveOrder(newOrder);
    setCart([]);
    triggerSoundFx('DISPATCH ORDERED!');
    return newOrder;
  };

  // Support Ticket
  const submitSupportTicket = (
    issueType: string,
    subject: string,
    message: string,
    orderId?: string
  ): SupportTicket => {
    const solutions: Record<string, string> = {
      'Track Order': 'The Support Witch has cast an all-seeing scrying spell on your dispatch parcel. Sonic drones have zero spatial drift.',
      'Return Product': 'Unused powers can be sealed into the return Faraday container. A spatial carrier will materialize within 24 hours.',
      'Request Refund': 'Galactic currency return is credited directly back to your original energy vault in 1–2 planetary cycles.',
      'Payment Failed': 'Quantum handshake timeout detected. Check that your Google Identity or crypto key has sufficient ether.',
      'Product Question': 'The alchemists recommend testing all temporary serums in a controlled radius of 50 meters away from fragile vases.',
      'Damaged Product': 'Immediate replacement potion sent via Hermes expedited carrier pigeon.',
      'Account Issue': 'Your Hero Dossier has been re-anchored to your primary Google address.',
      'Gift Card Issue': 'Gift card runes can be redeemed at checkout in the Power Glyph voucher box.',
    };

    const newTicket: SupportTicket = {
      id: `TCK-${Math.floor(100 + Math.random() * 900)}`,
      issueType,
      subject,
      message,
      orderId,
      status: 'Under Review',
      submittedAt: 'Just Now',
      witchDiagnosis: solutions[issueType] || 'The High Witch has recorded your petition into the Great Archive.',
    };

    setTickets((prev) => [newTicket, ...prev]);
    triggerSoundFx('SPELL CAST!');
    return newTicket;
  };

  // Add Review
  const addCustomerReview = (
    productName: string,
    author: string,
    title: string,
    rating: number,
    comment: string
  ) => {
    const newRev: CustomerReview = {
      id: `rev-${Date.now()}`,
      author,
      title,
      badge: 'Verified Customer ✦',
      rating,
      comment,
      productName,
      date: 'Just Now',
    };
    setReviews((prev) => [newRev, ...prev]);
    triggerSoundFx('REVIEW INSCRIBED!');
  };

  return (
    <SuperContext.Provider
      value={{
        currentView,
        selectedCategoryId,
        selectedProductId,
        searchQuery,
        setSearchQuery,
        navigateTo,
        cart,
        savedItems,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        saveForLater,
        moveSavedToCart,
        removeSaved,
        isCartOpen,
        setIsCartOpen,
        appliedCoupon,
        discountRate,
        applyCoupon,
        cartSubtotal,
        cartDiscount,
        cartShipping,
        cartTax,
        cartTotal,
        utilityBeltPercent,
        wishlist,
        toggleWishlist,
        isInWishlist,
        comparedProductIds,
        addToCompare,
        removeFromCompare,
        toggleCompare,
        clearCompare,
        isCompareOpen,
        setIsCompareOpen,
        isInCompare,
        user,
        isLoggedIn,
        isLoginModalOpen,
        setIsLoginModalOpen,
        loginUser,
        signUpUser,
        logoutUser,
        updateUserAlias,
        isVillainMode,
        toggleVillainMode,
        powerSurge,
        setPowerSurge,
        flashBanner,
        onomatopoeiaList,
        triggerSoundFx,
        orders,
        placeOrder,
        activeOrder,
        setActiveOrder,
        tickets,
        submitSupportTicket,
        reviews,
        addCustomerReview,
      }}
    >
      {children}
    </SuperContext.Provider>
  );
};

export const useSuper = () => {
  const context = useContext(SuperContext);
  if (!context) {
    throw new Error('useSuper must be used within a SuperProvider');
  }
  return context;
};
