import React, { useState } from 'react';
import { useSuper } from '../context/SuperContext';
import { PRODUCTS } from '../data/products';
import { ProductCard } from './ProductCard';
import {
  Sparkles,
  MapPin,
  Heart,
  Package,
  Edit2,
  Check,
  Sun,
  Moon,
} from 'lucide-react';

export const AccountDossier: React.FC = () => {
  const {
    user,
    orders,
    wishlist,
    updateUserAlias,
    isVillainMode,
    toggleVillainMode,
    navigateTo,
  } = useSuper();

  const [isEditingAlias, setIsEditingAlias] = useState(false);
  const [aliasInput, setAliasInput] = useState(user.alias);
  const [activeTab, setActiveTab] = useState<'dossier' | 'wishlist' | 'orders'>('dossier');

  const handleSaveAlias = () => {
    if (aliasInput.trim()) {
      updateUserAlias(aliasInput.trim());
      setIsEditingAlias(false);
    }
  };

  const wishlistedProducts = PRODUCTS.filter((p) => wishlist.includes(p.id));

  return (
    <div className="min-h-screen bg-[#0d0814] dark:bg-[#050308] text-white py-10 px-4 sm:px-6 lg:px-8 transition-colors duration-400">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Adept Header */}
        <div className="relative rounded-3xl bg-[#170e24] border border-[#D4AF37]/40 p-6 sm:p-8 arcane-card overflow-hidden">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
            {/* User Avatar & Alias */}
            <div className="flex items-center gap-5">
              <div className="relative">
                <img
                  src={user.avatar}
                  alt={user.alias}
                  className="w-18 h-18 rounded-2xl border border-[#D4AF37]/50 bg-black p-1 shadow-lg"
                  referrerPolicy="no-referrer"
                />
                <span className="absolute -top-2 -right-2 px-2 py-0.5 rounded-full font-whimsical text-[10px] font-bold text-black bg-[#FDE047]">
                  {user.rank}
                </span>
              </div>

              <div className="space-y-1">
                <div className="flex items-center gap-2 text-xs font-whimsical text-[#FDE047]">
                  <span>Adept Record #SN-7729</span>
                  <span>✦</span>
                  <span className="text-emerald-400">Attunement Active</span>
                </div>

                {isEditingAlias ? (
                  <div className="flex items-center gap-2 pt-1">
                    <input
                      type="text"
                      value={aliasInput}
                      onChange={(e) => setAliasInput(e.target.value)}
                      className="bg-[#0d0814] border border-[#D4AF37] rounded-xl px-2.5 py-1 text-sm font-witch text-white focus:outline-none"
                    />
                    <button
                      onClick={handleSaveAlias}
                      className="p-1.5 rounded-lg bg-[#D4AF37] text-black font-bold"
                    >
                      <Check className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <h1 className="font-witch text-2xl sm:text-3xl text-white">{user.alias}</h1>
                    <button
                      onClick={() => setIsEditingAlias(true)}
                      className="text-purple-300 hover:text-white p-1"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
                <div className="text-xs font-whimsical text-purple-300/70">{user.email}</div>
              </div>
            </div>

            {/* Mode Switch Button */}
            <div className="flex items-center gap-3">
              <button
                onClick={toggleVillainMode}
                className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-whimsical tracking-wide uppercase border border-[#D4AF37]/50 bg-[#0d0814] hover:border-[#FDE047] text-[#FDE047] transition-all shadow-[0_0_12px_rgba(212,175,55,0.2)]"
              >
                {isVillainMode ? (
                  <>
                    <Moon className="w-4 h-4 text-[#C084FC]" />
                    <span>Villan Mode (Night)</span>
                  </>
                ) : (
                  <>
                    <Sun className="w-4 h-4 text-[#FDE047]" />
                    <span>Hero Mode (Day)</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 border-b border-[#2d1b46] pb-2 font-whimsical text-xs">
          <button
            onClick={() => setActiveTab('dossier')}
            className={`px-4 py-2 rounded-xl border transition-all ${
              activeTab === 'dossier'
                ? 'bg-[#D4AF37] text-black font-bold border-[#FDE047]'
                : 'bg-[#170e24] text-purple-300 border-[#2d1b46]'
            }`}
          >
            Sanctum Dossier
          </button>
          <button
            onClick={() => setActiveTab('wishlist')}
            className={`px-4 py-2 rounded-xl border transition-all ${
              activeTab === 'wishlist'
                ? 'bg-[#D4AF37] text-black font-bold border-[#FDE047]'
                : 'bg-[#170e24] text-purple-300 border-[#2d1b46]'
            }`}
          >
            Sacred Wishlist ({wishlist.length})
          </button>
          <button
            onClick={() => setActiveTab('orders')}
            className={`px-4 py-2 rounded-xl border transition-all ${
              activeTab === 'orders'
                ? 'bg-[#D4AF37] text-black font-bold border-[#FDE047]'
                : 'bg-[#170e24] text-purple-300 border-[#2d1b46]'
            }`}
          >
            Ritual Manifests ({orders.length})
          </button>
        </div>

        {/* Tab Contents */}
        {activeTab === 'dossier' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-6 rounded-2xl bg-[#170e24] border border-[#2d1b46] space-y-3 font-whimsical text-xs">
              <div className="flex items-center gap-2 text-white font-witch text-base">
                <MapPin className="w-4 h-4 text-[#FDE047]" />
                <span>Sanctuary Coordinates</span>
              </div>
              <p className="text-purple-200/80">{user.hideoutAddress}</p>
              <div className="text-purple-300/60 text-[11px]">
                Attuned beacon for automatic astral dispatch.
              </div>
            </div>

            <div className="p-6 rounded-2xl bg-[#170e24] border border-[#2d1b46] space-y-3 font-whimsical text-xs">
              <div className="flex items-center gap-2 text-white font-witch text-base">
                <Sparkles className="w-4 h-4 text-[#FDE047]" />
                <span>Aura Alignment</span>
              </div>
              <p className="text-purple-200/80">
                Current Alignment: <span className="text-[#FDE047] font-semibold">{isVillainMode ? 'Villan Mode (Nightfall Shadows)' : 'Hero Mode (Daybreak Sunfire)'}</span>
              </p>
              <p className="text-purple-300/60 text-[11px]">
                Toggle between modes at any time to recalibrate your cosmic essence.
              </p>
            </div>
          </div>
        )}

        {activeTab === 'wishlist' && (
          <div>
            {wishlistedProducts.length === 0 ? (
              <div className="p-12 text-center bg-[#170e24] rounded-2xl border border-[#2d1b46] space-y-2">
                <Heart className="w-10 h-10 text-purple-400/40 mx-auto" />
                <h3 className="font-witch text-lg text-white">No Relics Saved Yet</h3>
                <p className="font-whimsical text-xs text-purple-300/70">
                  Click the heart icon on any power to bind it to your sacred grimoire.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {wishlistedProducts.map((p) => (
                  <ProductCard key={p.id} product={p} />
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'orders' && (
          <div className="space-y-4">
            {orders.length === 0 ? (
              <div className="p-12 text-center bg-[#170e24] rounded-2xl border border-[#2d1b46] space-y-2">
                <Package className="w-10 h-10 text-purple-400/40 mx-auto" />
                <h3 className="font-witch text-lg text-white">No Ritual Dispatches Yet</h3>
                <p className="font-whimsical text-xs text-purple-300/70">
                  Your ritual dispatches and courier tracking will be preserved here.
                </p>
              </div>
            ) : (
              orders.map((ord) => (
                <div
                  key={ord.id}
                  className="p-5 rounded-2xl bg-[#170e24] border border-[#2d1b46] space-y-3 font-whimsical text-xs"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-witch text-white text-sm">Ritual #{ord.id}</span>
                      <span className="text-purple-300/60 ml-2">{ord.date}</span>
                    </div>
                    <span className="text-[#FDE047] font-bold font-mono-nums">${ord.total}</span>
                  </div>
                  <div className="text-purple-300/70">
                    Dispatched via: <span className="text-white">{ord.deliveryMode}</span> · Sanctuary: {ord.shippingAddress.street}
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
};
