import React, { useState, useRef, useEffect } from 'react';
import { useSuper } from '../context/SuperContext';
import {
  Sparkles,
  X,
  Send,
  Minimize2,
  Maximize2,
  HelpCircle,
  Flame,
  Feather,
  RotateCcw,
} from 'lucide-react';

interface ChatMessage {
  id: string;
  sender: 'user' | 'witch';
  text: string;
  time: string;
}

const INITIAL_MESSAGES: ChatMessage[] = [
  {
    id: 'msg-1',
    sender: 'witch',
    text: "*stirs her bubbling cauldron of simmering star-dew and cackles gently* Greetings, curious mortal! I am Madame Morbida, Grand Coven Scryer. Speak: which supernatural artifact or courier owl flightpath does your spirit seek guidance upon?",
    time: 'Just Now',
  },
];

const PROMPT_CHIPS = [
  'Where is my courier owl?',
  'How do I dispel Voltaris current?',
  'Which elixir gives the highest speed?',
  'Can I combine two potions safely?',
  'Tell me about the 30-day guarantee',
];

export const SupportWitchChatbot: React.FC = () => {
  const { user, isVillainMode, triggerSoundFx } = useSuper();

  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>(INITIAL_MESSAGES);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
      setUnreadCount(0);
    }
  }, [isOpen, messages, isTyping]);

  const handleSendMessage = async (textToSend?: string) => {
    const messageText = (textToSend || inputValue).trim();
    if (!messageText) return;

    const userMsg: ChatMessage = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: messageText,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputValue('');
    setIsTyping(true);
    triggerSoundFx('✦ Incantation Inscribed');

    try {
      // POST to backend Gemini server route
      const response = await fetch('/api/witch-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: messageText,
          conversationHistory: messages.map((m) => ({
            role: m.sender === 'witch' ? 'witch' : 'user',
            text: m.text,
          })),
          userContext: {
            name: user.name,
            alias: user.alias,
            mode: isVillainMode ? 'Villan Dusk' : 'Hero Dawn',
          },
        }),
      });

      if (response.ok) {
        const data = await response.json();
        const witchMsg: ChatMessage = {
          id: `witch-${Date.now()}`,
          sender: 'witch',
          text: data.reply || getLocalWitchResponse(messageText),
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        setMessages((prev) => [...prev, witchMsg]);
        triggerSoundFx('✦ Witch Scrying Received');
      } else {
        throw new Error('Fallback to local scrying');
      }
    } catch (error) {
      // Local infallible witch AI engine
      const fallbackText = getLocalWitchResponse(messageText);
      const witchMsg: ChatMessage = {
        id: `witch-${Date.now()}`,
        sender: 'witch',
        text: fallbackText,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, witchMsg]);
      triggerSoundFx('✦ Witch Scrying Received');
    } finally {
      setIsTyping(false);
    }
  };

  const getLocalWitchResponse = (query: string): string => {
    const q = query.toLowerCase();
    if (q.includes('owl') || q.includes('courier') || q.includes('track') || q.includes('delivery')) {
      return "*gazes into the glowing crystal sphere* Ah! Our Solstice Courier Owl is cruising through the Whispering Leyline thermals at 82 knots. Its enchanted claws hold your parcel tightly. Check the interactive delivery map in the header to observe its wings in flight!";
    }
    if (q.includes('voltaris') || q.includes('electric') || q.includes('dispel') || q.includes('reverse')) {
      return "*cackles softly and sprinkles ground amethyst dust* To ground Voltaris current before the 6-hour cycle expires, place both bare soles upon living moss and drink unboiled spring water steeped in elderberry. The lightning will sink harmoniously into the earth.";
    }
    if (q.includes('speed') || q.includes('fast') || q.includes('flight') || q.includes('aetherwing')) {
      return "*whispers an aether incantation* For raw velocity, the AetherWing Potion grants +94 speed with zero spiritual turbulence! Or for horizontal ground dash, pair it with the Chrono-Stasis Drops to move while reality stands still.";
    }
    if (q.includes('combine') || q.includes('safe') || q.includes('two')) {
      return "By Coven decree, you may harmonize up to two compatible tier-A elixirs simultaneously. However, never mix Voltaris bio-electricity with Pyromancer's Draught without an earthen warding ring, lest your eyebrows singe!";
    }
    if (q.includes('guarantee') || q.includes('return') || q.includes('refund')) {
      return "All bottled arcana come with our 30-Day Full Lunar Attunement Guarantee. If your soul does not resonate with the relic, simply invoke a return parcel via courier owl for full tribute restoration.";
    }
    if (q.includes('blessing') || q.includes('luck') || q.includes('spell')) {
      return "*traces an astral pentagram in midair* ✦ May the North Star steady your hand, may the shadows flee before your light, and may your pocket grimoire never run dry of mana!";
    }
    return `*stirs the cauldron and nods knowingly* The stars reveal great curiosity in you, ${user.alias || 'adept'}. Every relic in Supranova has been tested across 10,000 simulations. Ask freely of our courier flightpaths, elixir recipes, or return rites!`;
  };

  return (
    <>
      {/* Floating Trigger Button */}
      {!isOpen && (
        <div className="fixed bottom-6 right-6 z-50 animate-bounce-gentle">
          <button
            onClick={() => {
              setIsOpen(true);
              triggerSoundFx('✦ Witch Familiar Summoned');
            }}
            className="group relative flex items-center gap-2.5 p-3 sm:px-4 sm:py-3 rounded-full bg-[#150924] border-2 border-[#D4AF37] text-white shadow-[0_8px_32px_rgba(212,175,55,0.4)] hover:scale-105 hover:border-[#FDE047] transition-all"
          >
            {/* Animated Familiar Orb with glowing eye */}
            <div className="relative w-8 h-8 rounded-full bg-gradient-to-tr from-[#7E22CE] to-[#FDE047] p-[1.5px] animate-pulse">
              <div className="w-full h-full rounded-full bg-[#0d0814] flex items-center justify-center text-sm">
                🔮
              </div>
            </div>

            <div className="hidden sm:block text-left">
              <div className="text-[10px] font-whimsical uppercase tracking-wider text-[#FDE047] font-bold">
                Support Witch
              </div>
              <div className="text-xs font-witch truncate max-w-[120px]">
                Madame Morbida
              </div>
            </div>

            {/* Sparkle badge */}
            <span className="w-2.5 h-2.5 rounded-full bg-[#FDE047] absolute top-1 right-1 animate-ping" />
          </button>
        </div>
      )}

      {/* Scrying Mirror Chat Window */}
      {isOpen && (
        <div className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-50 w-[95vw] sm:w-[420px] h-[560px] max-h-[90vh] flex flex-col rounded-3xl border-2 border-[#D4AF37]/70 shadow-[0_16px_50px_rgba(0,0,0,0.85)] overflow-hidden bg-[#0F071B] text-[#F3E8FF] animate-in slide-in-from-bottom-6 duration-300">
          {/* Header with Bubbling Cauldron Animation */}
          <div className="relative p-4 border-b border-[#2d1b46] bg-[#150924] flex items-center justify-between">
            {/* Ambient Cauldron steam glow */}
            <div className="absolute top-0 right-1/4 w-32 h-10 bg-purple-500/20 blur-xl pointer-events-none" />

            <div className="flex items-center gap-3">
              {/* Animated Witch Avatar & Cauldron */}
              <div className="relative w-11 h-11 rounded-2xl bg-[#07040B] border border-[#D4AF37] flex items-center justify-center text-xl overflow-hidden shadow-inner">
                <span>🧙‍♀️</span>
                {/* Rising Cauldron Bubbles */}
                <span className="absolute bottom-1 left-2 w-1.5 h-1.5 rounded-full bg-[#FDE047] animate-cauldron-bubble-1" />
                <span className="absolute bottom-1 left-5 w-2 h-2 rounded-full bg-[#C084FC] animate-cauldron-bubble-2" />
                <span className="absolute bottom-1 right-2 w-1.5 h-1.5 rounded-full bg-emerald-400 animate-cauldron-bubble-3" />
              </div>

              <div>
                <div className="flex items-center gap-1.5">
                  <h3 className="font-witch text-base text-[#FDE047] font-bold">
                    Madame Morbida
                  </h3>
                  <span className="px-1.5 py-0.2 rounded-full text-[9px] font-whimsical bg-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/30">
                    Grand Scryer
                  </span>
                </div>
                <div className="flex items-center gap-1.5 text-[11px] font-whimsical text-purple-300/80">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span>Astral Cauldron Active · Real-time AI</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => setIsOpen(false)}
              className="p-2 rounded-xl text-purple-300 hover:text-white hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Messages Stream */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs font-whimsical bg-[#07040B]/80">
            {messages.map((m) => (
              <div
                key={m.id}
                className={`flex gap-2.5 ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {m.sender === 'witch' && (
                  <div className="w-7 h-7 rounded-xl bg-[#150924] border border-[#D4AF37]/40 flex items-center justify-center shrink-0 text-sm">
                    🔮
                  </div>
                )}

                <div
                  className={`max-w-[82%] p-3 rounded-2xl leading-relaxed shadow-md ${
                    m.sender === 'user'
                      ? 'bg-[#D4AF37] text-black font-semibold rounded-tr-none'
                      : 'bg-[#150924] border border-[#2d1b46] text-purple-100 rounded-tl-none'
                  }`}
                >
                  <p className="whitespace-pre-line">{m.text}</p>
                  <div
                    className={`text-[9px] mt-1 text-right ${
                      m.sender === 'user' ? 'text-black/60' : 'text-purple-300/50'
                    }`}
                  >
                    {m.time}
                  </div>
                </div>
              </div>
            ))}

            {/* Witch Scrying Typing Indicator */}
            {isTyping && (
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-xl bg-[#150924] border border-[#D4AF37]/40 flex items-center justify-center shrink-0 text-sm animate-spin-slow">
                  ✨
                </div>
                <div className="px-3.5 py-2.5 rounded-2xl rounded-tl-none bg-[#150924] border border-[#2d1b46] flex items-center gap-2 text-purple-300 text-xs">
                  <span className="italic">Scrying celestial stars...</span>
                  <div className="flex gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#FDE047] animate-ping" />
                    <span className="w-1.5 h-1.5 rounded-full bg-[#C084FC] animate-ping" />
                  </div>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Quick Prompt Chips */}
          <div className="px-3 py-2 bg-[#0d0716] border-t border-[#2d1b46] overflow-x-auto whitespace-nowrap flex gap-1.5 no-scrollbar">
            {PROMPT_CHIPS.map((chip, idx) => (
              <button
                key={idx}
                onClick={() => handleSendMessage(chip)}
                className="px-2.5 py-1 rounded-full text-[10px] font-whimsical bg-[#170e24] hover:bg-[#D4AF37] hover:text-black border border-[#D4AF37]/30 text-[#FDE047] transition-all shrink-0"
              >
                ✦ {chip}
              </button>
            ))}
          </div>

          {/* Message Input Bar */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="p-3 bg-[#150924] border-t border-[#2d1b46] flex items-center gap-2"
          >
            <input
              ref={inputRef}
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Ask Madame Morbida about any spell, owl, or relic..."
              className="flex-1 px-3.5 py-2 rounded-xl text-xs font-whimsical bg-black/40 border border-[#D4AF37]/40 text-white placeholder-purple-300/40 focus:outline-none focus:border-[#FDE047]"
            />
            <button
              type="submit"
              disabled={!inputValue.trim() || isTyping}
              className="p-2.5 rounded-xl bg-[#D4AF37] hover:bg-[#FDE047] text-black font-bold disabled:opacity-40 transition-all hover:scale-105 shadow-[0_0_10px_rgba(212,175,55,0.3)]"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}
    </>
  );
};
