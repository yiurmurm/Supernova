import React from 'react';
import { useSuper } from '../context/SuperContext';
import { CATEGORIES_DATA } from '../data/products';
import { ArrowRight, Sparkles } from 'lucide-react';
import { CategoryId } from '../types';

export const CategoryShowcase: React.FC = () => {
  const { navigateTo, triggerSoundFx } = useSuper();

  return (
    <section className="relative w-full py-16 bg-[#0d0814] dark:bg-[#050308] border-b border-[#2d1b46]/70 transition-colors duration-400">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-10">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 text-xs font-whimsical uppercase text-[#FDE047] font-semibold tracking-wider">
              <Sparkles className="w-3.5 h-3.5" /> Five Sacred Grimoires
            </div>
            <h2 className="font-witch text-3xl sm:text-4xl text-white tracking-wide">
              Select Your Medium of Power
            </h2>
            <p className="font-whimsical text-purple-200/80 text-base max-w-lg">
              Bottled elixirs, enchanted jewels, awakened bio-familiars, and reality lenses.
            </p>
          </div>

          <button
            onClick={() => {
              triggerSoundFx('✧ All Grimoires');
              navigateTo('shop');
            }}
            className="flex items-center gap-2 text-sm font-whimsical uppercase tracking-wider text-[#FDE047] hover:text-amber-200 transition-colors"
          >
            <span>View All Powers</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* 5 Category Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {CATEGORIES_DATA.map((cat, index) => {
            const isWide = index === 0 || index === 3;
            return (
              <div
                key={cat.id}
                onClick={() => {
                  triggerSoundFx(`✧ ${cat.name}`);
                  navigateTo('category', { categoryId: cat.id as CategoryId });
                }}
                className={`group cursor-pointer relative rounded-2xl bg-[#170e24] border border-[#D4AF37]/30 hover:border-[#FDE047] arcane-card overflow-hidden transition-all duration-300 flex flex-col justify-between ${
                  isWide ? 'lg:col-span-2' : 'lg:col-span-1'
                }`}
              >
                {/* Background Image Container */}
                <div className="relative aspect-[16/9] w-full overflow-hidden bg-black/60">
                  <img
                    src={cat.image}
                    alt={cat.name}
                    className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700 opacity-80 group-hover:opacity-100"
                    referrerPolicy="no-referrer"
                  />
                  {/* Arcane Vignette Scrim */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#170e24] via-[#170e24]/40 to-transparent" />

                  {/* Grimoire Number / Rune */}
                  <div
                    className="absolute top-4 left-4 px-2.5 py-1 rounded-lg font-witch text-xs text-black font-bold shadow-[0_2px_8px_rgba(0,0,0,0.5)]"
                    style={{ backgroundColor: '#FDE047' }}
                  >
                    {cat.number}
                  </div>
                </div>

                {/* Card Content Details */}
                <div className="p-6 relative z-10 space-y-2 bg-[#170e24]">
                  <div className="text-[11px] font-whimsical uppercase tracking-wider text-purple-300/60">
                    {cat.tagline}
                  </div>
                  <h3 className="font-witch text-xl sm:text-2xl text-white group-hover:text-[#FDE047] transition-colors">
                    {cat.name}
                  </h3>
                  <p className="font-whimsical text-sm text-purple-200/80 leading-relaxed line-clamp-2">
                    {cat.description}
                  </p>

                  <div className="pt-2 flex items-center justify-between border-t border-[#2d1b46]/60">
                    <span className="font-whimsical text-xs uppercase tracking-wider text-[#FDE047] flex items-center gap-1.5 group-hover:translate-x-1 transition-transform font-bold">
                      <span>Explore Grimoire</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </span>
                    <span className="text-xs font-mono-nums text-purple-300/50">Arcana Cataloged</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
