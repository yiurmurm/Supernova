import React, { useState } from 'react';
import { useSuper } from '../context/SuperContext';
import { PRODUCTS } from '../data/products';
import { Sparkles, ArrowRight, RotateCcw, CheckCircle2 } from 'lucide-react';
import { Product } from '../types';

interface Question {
  id: number;
  question: string;
  options: {
    label: string;
    description: string;
    powerArchetype: 'Teleportation' | 'Chrono' | 'Electric' | 'Bio-Morph' | 'Omniscient';
  }[];
}

const QUIZ_QUESTIONS: Question[] = [
  {
    id: 1,
    question: 'When faced with an impossible obstacle, what is your first instinct?',
    options: [
      {
        label: 'Step through the fabric of space',
        description: 'Fold dimensions and appear on the other side.',
        powerArchetype: 'Teleportation',
      },
      {
        label: 'Suspend the flow of time',
        description: 'Calmly ponder infinite possibilities in stasis.',
        powerArchetype: 'Chrono',
      },
      {
        label: 'Overcharge with 250,000V of celestial lightning',
        description: 'Pure radiant voltage and electric speed.',
        powerArchetype: 'Electric',
      },
      {
        label: 'Summon an attuned bio-familiar or wing morphology',
        description: 'Evolve wings of starlight to soar above it.',
        powerArchetype: 'Bio-Morph',
      },
    ],
  },
  {
    id: 2,
    question: 'Where would you craft your sacred sanctuary?',
    options: [
      {
        label: 'An astral pocket between dimensions',
        description: 'Reachable only by an encrypted meteorite ring.',
        powerArchetype: 'Teleportation',
      },
      {
        label: 'A perpetual twilight clocktower',
        description: 'Where moments stretch into golden centuries.',
        powerArchetype: 'Chrono',
      },
      {
        label: 'A storm-crowned mountain spire',
        description: 'Crackling with raw arcane lightning.',
        powerArchetype: 'Electric',
      },
      {
        label: 'An ancient luminescent moss grove',
        description: 'Nourished by moon moths and enchanted flora.',
        powerArchetype: 'Bio-Morph',
      },
    ],
  },
  {
    id: 3,
    question: 'Which sensory attunement would transform your journey most?',
    options: [
      {
        label: 'Omnipresence: Travel instantly anywhere with a thought',
        description: 'Distance is merely an illusion.',
        powerArchetype: 'Teleportation',
      },
      {
        label: 'Third-Eye Divination: Glimpse 30 minutes into futures',
        description: 'Read the branching lines of fate before they unfold.',
        powerArchetype: 'Omniscient',
      },
      {
        label: 'Bio-Carapace: Invincible against all earthly weariness',
        description: 'Impenetrable physical serenity and strength.',
        powerArchetype: 'Bio-Morph',
      },
      {
        label: 'Surge Resonance: Energize relics with your fingertips',
        description: 'Infinite vitality flowing like liquid fire.',
        powerArchetype: 'Electric',
      },
    ],
  },
  {
    id: 4,
    question: 'Which talisman medium draws your gaze?',
    options: [
      {
        label: 'Quenched volcanic meteorite rings with glowing portals',
        description: 'Forged in stellar collapse.',
        powerArchetype: 'Teleportation',
      },
      {
        label: 'Bottled violet elixirs bubbling with golden lightning',
        description: 'Brewed under midnight solstice eclipses.',
        powerArchetype: 'Electric',
      },
      {
        label: 'An obsidian eyewear lens displaying the astral plane',
        description: 'Showing hidden ley-lines and spectral auras.',
        powerArchetype: 'Omniscient',
      },
      {
        label: 'An awakened golden beetle chrysalis pulsing with life',
        description: 'Bonding with your shadow as a loyal familiar.',
        powerArchetype: 'Bio-Morph',
      },
    ],
  },
];

export const PowerQuiz: React.FC = () => {
  const { navigateTo, addToCart, triggerSoundFx } = useSuper();

  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<string[]>([]);
  const [resultArchetype, setResultArchetype] = useState<string | null>(null);

  const handleSelectOption = (archetype: string) => {
    const nextAnswers = [...answers, archetype];
    setAnswers(nextAnswers);
    triggerSoundFx('✧ Attunement Inscribed');

    if (currentStep < QUIZ_QUESTIONS.length - 1) {
      setCurrentStep((prev) => prev + 1);
    } else {
      // Tally archetype
      const countMap: Record<string, number> = {};
      nextAnswers.forEach((a) => {
        countMap[a] = (countMap[a] || 0) + 1;
      });
      let highestArchetype = 'Teleportation';
      let maxVotes = 0;
      Object.entries(countMap).forEach(([k, v]) => {
        if (v > maxVotes) {
          maxVotes = v;
          highestArchetype = k;
        }
      });
      setResultArchetype(highestArchetype);
      triggerSoundFx('✨ Calling Revealed');
    }
  };

  const handleReset = () => {
    setCurrentStep(0);
    setAnswers([]);
    setResultArchetype(null);
  };

  // Matched products
  const matchedProducts: Product[] = React.useMemo(() => {
    if (!resultArchetype) return [];
    if (resultArchetype === 'Teleportation') {
      return PRODUCTS.filter((p) => p.category === 'accessories' || p.archetype === 'Cosmic').slice(0, 3);
    }
    if (resultArchetype === 'Electric') {
      return PRODUCTS.filter((p) => p.category === 'potions' || p.archetype === 'Tech-Enhanced').slice(0, 3);
    }
    if (resultArchetype === 'Omniscient') {
      return PRODUCTS.filter((p) => p.category === 'eyewear' || p.archetype === 'Mystic').slice(0, 3);
    }
    if (resultArchetype === 'Bio-Morph') {
      return PRODUCTS.filter((p) => p.category === 'insects' || p.category === 'sprays' || p.archetype === 'Mutant').slice(0, 3);
    }
    return PRODUCTS.slice(0, 3);
  }, [resultArchetype]);

  const activeQuestion = QUIZ_QUESTIONS[currentStep];

  return (
    <div className="min-h-screen bg-[#0d0814] dark:bg-[#050308] text-white py-12 px-4 sm:px-6 transition-colors duration-400">
      <div className="max-w-3xl mx-auto space-y-8">
        {/* Header with Celestial Moon & Star Imagery */}
        <div className="relative rounded-3xl overflow-hidden bg-[#170e24] border border-[#D4AF37]/40 p-6 sm:p-8 text-center space-y-3 arcane-card shadow-2xl">
          <div className="absolute inset-0 opacity-20 pointer-events-none">
            <img
              src="/src/assets/images/star_chart_nebula_1790162515204.jpg"
              alt="Star Chart & Nebula"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-[#170e24]/60 via-[#170e24] to-[#170e24]" />
          </div>

          <div className="relative z-10 space-y-2">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#0d0814]/90 border border-[#D4AF37]/40 text-xs font-whimsical uppercase text-[#FDE047]">
              <Sparkles className="w-3.5 h-3.5 animate-twinkle" />
              <span>High Coven Lunar Oracle</span>
            </div>
            <h1 className="font-witch text-3xl sm:text-4xl text-white">
              Which Power Beckons You?
            </h1>
            <p className="font-whimsical text-purple-200/90 text-sm max-w-md mx-auto">
              Answer 4 ritual inquiries to attune your natural affinity with the sacred catalog under starlight.
            </p>
          </div>
        </div>

        {!resultArchetype ? (
          /* Question View */
          <div className="p-6 sm:p-8 rounded-3xl bg-[#170e24] border border-[#D4AF37]/35 arcane-card space-y-6">
            {/* Progress Bar */}
            <div className="space-y-1.5 font-whimsical">
              <div className="flex justify-between text-xs text-purple-300/70">
                <span>Inquiry {currentStep + 1} of {QUIZ_QUESTIONS.length}</span>
                <span className="text-[#FDE047] font-semibold">
                  {Math.round(((currentStep + 1) / QUIZ_QUESTIONS.length) * 100)}% Attuned
                </span>
              </div>
              <div className="w-full h-1.5 bg-[#0d0814] rounded-full overflow-hidden border border-[#2d1b46]">
                <div
                  className="h-full bg-gradient-to-r from-[#D4AF37] to-[#FDE047] transition-all duration-300"
                  style={{ width: `${((currentStep + 1) / QUIZ_QUESTIONS.length) * 100}%` }}
                />
              </div>
            </div>

            <h2 className="font-witch text-xl sm:text-2xl text-white">
              {activeQuestion.question}
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {activeQuestion.options.map((opt, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSelectOption(opt.powerArchetype)}
                  className="p-4 rounded-2xl bg-[#0d0814] border border-[#2d1b46] hover:border-[#D4AF37] text-left font-whimsical transition-all hover:-translate-y-0.5 group space-y-1 shadow-sm"
                >
                  <div className="font-bold text-white text-sm group-hover:text-[#FDE047] transition-colors">
                    {opt.label}
                  </div>
                  <p className="text-xs text-purple-300/70 leading-relaxed">
                    {opt.description}
                  </p>
                </button>
              ))}
            </div>
          </div>
        ) : (
          /* Result View */
          <div className="space-y-8 animate-in fade-in zoom-in-95 duration-200">
            <div className="relative overflow-hidden p-8 rounded-3xl bg-[#170e24] border border-[#D4AF37]/50 arcane-card text-center space-y-4 shadow-2xl">
              {/* Moon & Star backdrop */}
              <div className="absolute inset-0 opacity-25 pointer-events-none">
                <img
                  src="/src/assets/images/celestial_moon_stars_1790162488603.jpg"
                  alt="Celestial Moon"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#170e24] via-[#170e24]/70 to-[#170e24]" />
              </div>

              <div className="relative z-10 space-y-4">
                <div className="inline-flex p-3.5 rounded-full bg-[#D4AF37]/20 border border-[#D4AF37] text-[#FDE047] shadow-[0_0_15px_rgba(212,175,55,0.4)]">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <div className="text-xs font-whimsical uppercase text-[#FDE047] tracking-wider flex items-center justify-center gap-2">
                  <span>✦</span>
                  <span>Aura Attunement Verified under Full Moon</span>
                  <span>✦</span>
                </div>
                <h2 className="font-witch text-3xl sm:text-4xl text-white">
                  You Are Aligned to: {resultArchetype} Arcana
                </h2>
                <p className="font-whimsical text-purple-200/90 text-sm max-w-lg mx-auto">
                  Your spirit resonates with spatial sovereignty and starlight currents. Explore your customized lunar loadout below.
                </p>

                <button
                  onClick={handleReset}
                  className="inline-flex items-center gap-1.5 text-xs font-whimsical text-[#FDE047] hover:underline pt-2"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Re-attune Diagnostic</span>
                </button>
              </div>
            </div>

            {/* Matched Relics */}
            <div className="space-y-4">
              <h3 className="font-witch text-xl text-white">
                Recommended Attunements for You
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {matchedProducts.map((p) => (
                  <div
                    key={p.id}
                    className="p-4 rounded-2xl bg-[#170e24] border border-[#D4AF37]/30 space-y-3 arcane-card flex flex-col justify-between"
                  >
                    <div className="aspect-[4/3] rounded-xl overflow-hidden bg-black border border-[#2d1b46]">
                      <img
                        src={p.image}
                        alt={p.name}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <div className="space-y-1">
                      <div className="font-witch text-sm text-white truncate">{p.name}</div>
                      <div className="font-witch text-xs text-[#FDE047]">${p.price}</div>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => addToCart(p, 1)}
                        className="flex-1 py-1.5 px-3 rounded-lg bg-[#D4AF37] text-black font-whimsical text-xs font-bold hover:bg-[#FDE047]"
                      >
                        Attune
                      </button>
                      <button
                        onClick={() => navigateTo('product', { productId: p.id })}
                        className="py-1.5 px-2.5 rounded-lg border border-[#2d1b46] text-purple-200 text-xs hover:border-[#D4AF37]"
                      >
                        Inspect
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
