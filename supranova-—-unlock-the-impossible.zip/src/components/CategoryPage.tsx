import React, { useState, useMemo } from 'react';
import { useSuper } from '../context/SuperContext';
import { PRODUCTS, CATEGORIES_DATA } from '../data/products';
import { ProductCard } from './ProductCard';
import { CategoryId } from '../types';
import {
  Sparkles,
  Filter,
  X,
  SlidersHorizontal,
} from 'lucide-react';

interface CategoryPageProps {
  initialCategoryId?: CategoryId | null;
}

export const CategoryPage: React.FC<CategoryPageProps> = ({ initialCategoryId }) => {
  const {
    searchQuery,
    setSearchQuery,
    triggerSoundFx,
  } = useSuper();

  const [selectedCategory, setSelectedCategory] = useState<CategoryId | 'all'>(
    initialCategoryId || 'all'
  );
  const [selectedRarity, setSelectedRarity] = useState<string>('all');
  const [selectedArchetype, setSelectedArchetype] = useState<string>('all');
  const [maxPrice, setMaxPrice] = useState<number>(750);
  const [minRating, setMinRating] = useState<number>(0);
  const [sortBy, setSortBy] = useState<string>('featured');
  const [isMobileFilterOpen, setIsMobileFilterOpen] = useState<boolean>(false);

  const activeCategoryData = useMemo(() => {
    return CATEGORIES_DATA.find((c) => c.id === selectedCategory);
  }, [selectedCategory]);

  const filteredProducts = useMemo(() => {
    return PRODUCTS.filter((p) => {
      if (selectedCategory !== 'all' && p.category !== selectedCategory) return false;

      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesName = p.name.toLowerCase().includes(query);
        const matchesDesc = p.shortDesc.toLowerCase().includes(query);
        const matchesCategory = p.category.toLowerCase().includes(query);
        const matchesArchetype = p.archetype.toLowerCase().includes(query);
        const matchesMagic = p.magicType.toLowerCase().includes(query);
        if (!matchesName && !matchesDesc && !matchesCategory && !matchesArchetype && !matchesMagic) {
          return false;
        }
      }

      if (selectedRarity !== 'all' && p.rarity !== selectedRarity) return false;
      if (selectedArchetype !== 'all' && p.archetype !== selectedArchetype) return false;
      if (p.price > maxPrice) return false;
      if (p.rating < minRating) return false;

      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-low') return a.price - b.price;
      if (sortBy === 'price-high') return b.price - a.price;
      if (sortBy === 'rating') return b.rating - a.rating;
      if (sortBy === 'power') return b.powerLevel - a.powerLevel;
      return (b.isBestseller ? 1 : 0) - (a.isBestseller ? 1 : 0);
    });
  }, [
    selectedCategory,
    searchQuery,
    selectedRarity,
    selectedArchetype,
    maxPrice,
    minRating,
    sortBy,
  ]);

  const resetFilters = () => {
    setSelectedCategory('all');
    setSelectedRarity('all');
    setSelectedArchetype('all');
    setMaxPrice(750);
    setMinRating(0);
    setSearchQuery('');
    setSortBy('featured');
    triggerSoundFx('✧ Reset Filters');
  };

  return (
    <div className="min-h-screen bg-[#0d0814] dark:bg-[#050308] text-white py-8 transition-colors duration-400">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Category Header Banner with Moon & Star Imagery */}
        <div className="relative rounded-3xl bg-[#170e24] border border-[#D4AF37]/45 p-6 sm:p-10 arcane-card overflow-hidden shadow-2xl">
          {/* Moon & Star Visual Backing */}
          <div className="absolute top-0 right-0 w-full sm:w-1/2 h-full opacity-30 sm:opacity-45 pointer-events-none overflow-hidden">
            <img
              src="/src/assets/images/celestial_moon_stars_1790162488603.jpg"
              alt="Celestial Moon and Stars"
              className="w-full h-full object-cover object-right"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-[#170e24] via-[#170e24]/80 to-transparent" />
          </div>

          <div className="relative z-10 max-w-2xl space-y-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#0d0814]/90 border border-[#D4AF37]/40 backdrop-blur-sm">
              <Sparkles className="w-3.5 h-3.5 text-[#FDE047] animate-twinkle" />
              <span className="text-xs font-whimsical uppercase text-[#FDE047] font-semibold tracking-wider">
                {activeCategoryData ? `Grimoire ${activeCategoryData.number}` : 'Central Arcana Vault • Starlight Catalog'}
              </span>
            </div>

            <h1 className="font-witch text-3xl sm:text-5xl text-white tracking-wide">
              {activeCategoryData ? activeCategoryData.name : 'All Superpowers & Relics'}
            </h1>

            <p className="font-whimsical text-purple-200/90 text-sm sm:text-base leading-relaxed">
              {activeCategoryData
                ? activeCategoryData.description
                : 'Browse our complete catalog of 32 authentic superhuman abilities, bottled elixirs, familiar creatures, and reality-altering talismans woven under moonlit tides.'}
            </p>

            <div className="flex items-center gap-4 text-xs font-whimsical text-[#FDE047] pt-1">
              <span>✦ Aligned to Celestial Constellations</span>
              <span>•</span>
              <span>🌙 Lunar Attunement Guaranteed</span>
            </div>
          </div>
        </div>

        {/* Category Navigation Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none border-b border-[#2d1b46]">
          <button
            onClick={() => {
              setSelectedCategory('all');
              triggerSoundFx('✧ All Relics');
            }}
            className={`px-4 py-2 text-xs font-whimsical uppercase rounded-xl border transition-all ${
              selectedCategory === 'all'
                ? 'bg-[#D4AF37] text-black font-bold border-[#FDE047] shadow-[0_0_12px_rgba(212,175,55,0.3)]'
                : 'bg-[#170e24] text-purple-300 border-[#2d1b46] hover:border-[#D4AF37]/40'
            }`}
          >
            All Arcana ({PRODUCTS.length})
          </button>

          {CATEGORIES_DATA.map((cat) => {
            const count = PRODUCTS.filter((p) => p.category === cat.id).length;
            const isSelected = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => {
                  setSelectedCategory(cat.id as CategoryId);
                  triggerSoundFx(`✧ ${cat.name}`);
                }}
                className={`px-4 py-2 text-xs font-whimsical uppercase rounded-xl border whitespace-nowrap transition-all ${
                  isSelected
                    ? 'bg-[#D4AF37] text-black font-bold border-[#FDE047] shadow-[0_0_12px_rgba(212,175,55,0.3)]'
                    : 'bg-[#170e24] text-purple-300 border-[#2d1b46] hover:border-[#D4AF37]/40'
                }`}
              >
                {cat.name} ({count})
              </button>
            );
          })}
        </div>

        {/* Layout: Filter Sidebar + Products Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Desktop Filter Sidebar */}
          <aside className="hidden lg:block lg:col-span-3 sticky top-24 space-y-6 rounded-2xl bg-[#170e24] border border-[#D4AF37]/30 p-5 arcane-card">
            <div className="flex items-center justify-between pb-3 border-b border-[#2d1b46]">
              <span className="font-whimsical text-xs uppercase tracking-wider text-white font-bold flex items-center gap-1.5">
                <Filter className="w-3.5 h-3.5 text-[#FDE047]" /> Attune Filter
              </span>
              <button
                onClick={resetFilters}
                className="text-xs font-whimsical text-purple-300/70 hover:text-white transition-colors"
              >
                Reset
              </button>
            </div>

            {/* Search Input */}
            <div className="space-y-1.5 font-whimsical">
              <label className="text-xs uppercase text-purple-300/70">Scry Powers</label>
              <div className="relative">
                <input
                  type="text"
                  placeholder="Keyword, incantation..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-[#0d0814] border border-[#2d1b46] rounded-xl px-3 py-2 text-xs text-white placeholder-purple-300/40 focus:outline-none focus:border-[#D4AF37]"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-purple-300/60 hover:text-white text-xs"
                  >
                    ×
                  </button>
                )}
              </div>
            </div>

            {/* Archetype Filter */}
            <div className="space-y-1.5 font-whimsical">
              <label className="text-xs uppercase text-purple-300/70">Aura Archetype</label>
              <select
                value={selectedArchetype}
                onChange={(e) => setSelectedArchetype(e.target.value)}
                className="w-full bg-[#0d0814] border border-[#2d1b46] rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#D4AF37]"
              >
                <option value="all">All Archetypes</option>
                <option value="Tech-Enhanced">Tech-Enhanced</option>
                <option value="Mutant">Mutant</option>
                <option value="Mystic">Mystic</option>
                <option value="Cosmic">Cosmic</option>
              </select>
            </div>

            {/* Rarity Tier */}
            <div className="space-y-1.5 font-whimsical">
              <label className="text-xs uppercase text-purple-300/70">Rarity Tier</label>
              <select
                value={selectedRarity}
                onChange={(e) => setSelectedRarity(e.target.value)}
                className="w-full bg-[#0d0814] border border-[#2d1b46] rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#D4AF37]"
              >
                <option value="all">All Tiers</option>
                <option value="God-Tier">✦ God-Tier</option>
                <option value="Cosmic">✧ Cosmic</option>
                <option value="Mythic">✦ Mythic</option>
                <option value="Legendary">✧ Legendary</option>
                <option value="Epic">✦ Epic</option>
              </select>
            </div>

            {/* Max Tribute (Price) Slider */}
            <div className="space-y-2 font-whimsical">
              <div className="flex justify-between text-xs">
                <span className="uppercase text-purple-300/70">Max Tribute:</span>
                <span className="font-mono-nums text-[#FDE047] font-bold">${maxPrice}</span>
              </div>
              <input
                type="range"
                min="50"
                max="750"
                step="25"
                value={maxPrice}
                onChange={(e) => setMaxPrice(Number(e.target.value))}
                className="w-full accent-[#D4AF37] cursor-pointer"
              />
            </div>
          </aside>

          {/* Mobile Filter Toggle Button */}
          <div className="lg:hidden col-span-1 flex items-center justify-between gap-4 p-3 bg-[#170e24] border border-[#2d1b46] rounded-xl">
            <button
              onClick={() => setIsMobileFilterOpen(true)}
              className="flex items-center gap-2 text-xs font-whimsical text-[#FDE047]"
            >
              <SlidersHorizontal className="w-4 h-4" />
              <span>Filters ({filteredProducts.length} Powers)</span>
            </button>

            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="bg-[#0d0814] border border-[#2d1b46] rounded-lg px-2 py-1 text-xs text-white"
            >
              <option value="featured">Featured</option>
              <option value="price-low">Tribute: Low to High</option>
              <option value="price-high">Tribute: High to Low</option>
              <option value="power">Potency Level</option>
            </select>
          </div>

          {/* Products Grid (lg:col-span-9) */}
          <div className="lg:col-span-9 space-y-6">
            {/* Top Toolbar (Desktop Sort & Count) */}
            <div className="hidden lg:flex items-center justify-between pb-3 border-b border-[#2d1b46] text-xs font-whimsical">
              <div className="text-purple-300/70">
                Displaying <span className="text-[#FDE047] font-bold">{filteredProducts.length}</span> sacred powers
              </div>

              <div className="flex items-center gap-2">
                <span className="text-purple-300/60">Sort By:</span>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="bg-[#170e24] border border-[#2d1b46] rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#D4AF37]"
                >
                  <option value="featured">Coven Recommendations</option>
                  <option value="price-low">Tribute: Low to High</option>
                  <option value="price-high">Tribute: High to Low</option>
                  <option value="power">Aura Potency</option>
                  <option value="rating">Coven Rating</option>
                </select>
              </div>
            </div>

            {/* Grid */}
            {filteredProducts.length === 0 ? (
              <div className="py-20 text-center space-y-3 bg-[#170e24] rounded-2xl border border-[#2d1b46]">
                <div className="font-witch text-xl text-white">No Matching Arcana Found</div>
                <p className="font-whimsical text-xs text-purple-300/70 max-w-sm mx-auto">
                  Adjust your filters or reset to browse all 32 powers in the Coven Grimoire.
                </p>
                <button
                  onClick={resetFilters}
                  className="px-4 py-2 rounded-xl bg-[#D4AF37] text-black font-whimsical text-xs uppercase font-bold"
                >
                  Clear Filters
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
                {filteredProducts.map((p) => (
                  <ProductCard key={p.id} product={p} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
