import React, { useState } from 'react';
import { useSuper } from '../context/SuperContext';
import {
  X,
  Trash2,
  Bookmark,
  ShoppingBag,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Tag,
} from 'lucide-react';

export const CartDrawer: React.FC = () => {
  const {
    isCartOpen,
    setIsCartOpen,
    cart,
    savedItems,
    removeFromCart,
    updateCartQuantity,
    saveForLater,
    moveSavedToCart,
    removeSaved,
    cartSubtotal,
    cartDiscount,
    cartShipping,
    cartTax,
    cartTotal,
    appliedCoupon,
    applyCoupon,
    navigateTo,
    triggerSoundFx,
  } = useSuper();

  const [couponInput, setCouponInput] = useState('');
  const [couponMsg, setCouponMsg] = useState<{ success: boolean; text: string } | null>(null);

  if (!isCartOpen) return null;

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponInput) return;
    const res = applyCoupon(couponInput);
    setCouponMsg({ success: res.success, text: res.message });
  };

  const handleCheckout = () => {
    setIsCartOpen(false);
    navigateTo('checkout');
    triggerSoundFx('✧ Astral Seal');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
        onClick={() => setIsCartOpen(false)}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-8">
        <div className="w-screen max-w-md bg-[#170e24] border-l border-[#D4AF37]/40 flex flex-col justify-between shadow-2xl animate-in slide-in-from-right duration-200">
          {/* Header Strip */}
          <div className="p-5 border-b border-[#2d1b46] bg-[#0d0814] space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg border border-[#D4AF37]/50 flex items-center justify-center bg-[#1e1330] text-[#FDE047] text-xs">
                  ✦
                </div>
                <span className="font-witch text-lg text-white tracking-wide">
                  Arcane Satchel
                </span>
              </div>
              <button
                onClick={() => setIsCartOpen(false)}
                className="p-1 rounded-lg text-purple-300 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Cart Items List */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            {cart.length === 0 ? (
              <div className="text-center py-16 space-y-3">
                <ShoppingBag className="w-12 h-12 text-purple-400/40 mx-auto" />
                <div className="font-witch text-lg text-white">Your Satchel is Empty</div>
                <p className="font-whimsical text-xs text-purple-300/70 max-w-xs mx-auto">
                  No enchanted relics attuned yet. Browse the grimoire to summon powers.
                </p>
                <button
                  onClick={() => {
                    setIsCartOpen(false);
                    navigateTo('shop');
                  }}
                  className="px-4 py-2 rounded-xl font-whimsical text-xs uppercase text-black font-bold bg-[#D4AF37] hover:bg-[#FDE047] transition-all"
                >
                  Explore Grimoires →
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                {cart.map((item) => (
                  <div
                    key={`${item.product.id}-${item.selectedVariant || 'default'}`}
                    className="p-3 rounded-xl bg-[#0d0814] border border-[#2d1b46] flex gap-3 items-center arcane-card"
                  >
                    {/* Item Thumbnail */}
                    <div className="w-14 h-14 rounded-lg overflow-hidden border border-[#D4AF37]/30 shrink-0 bg-[#0d0814]">
                      <img
                        src={item.product.image}
                        alt={item.product.name}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </div>

                    {/* Details */}
                    <div className="flex-1 min-w-0 space-y-0.5">
                      <div className="text-[10px] font-whimsical uppercase text-[#FDE047]">
                        {item.product.rarity} · {item.product.powerGrade}
                      </div>
                      <h4 className="font-witch text-sm text-white truncate">
                        {item.product.name}
                      </h4>
                      {item.selectedVariant && (
                        <div className="text-[10px] font-whimsical text-purple-300/70 truncate">
                          {item.selectedVariant}
                        </div>
                      )}
                      <div className="font-witch text-xs text-[#FDE047]">
                        ${item.product.price}
                      </div>
                    </div>

                    {/* Quantity Stepper & Actions */}
                    <div className="flex flex-col items-end gap-1.5">
                      <div className="flex items-center bg-[#170e24] border border-[#2d1b46] rounded-lg p-0.5">
                        <button
                          onClick={() => updateCartQuantity(item.product.id, item.quantity - 1)}
                          className="w-5 h-5 flex items-center justify-center font-bold text-xs text-purple-300 hover:text-white"
                        >
                          -
                        </button>
                        <span className="w-6 text-center font-mono-nums text-xs font-bold text-[#FDE047]">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateCartQuantity(item.product.id, item.quantity + 1)}
                          className="w-5 h-5 flex items-center justify-center font-bold text-xs text-purple-300 hover:text-white"
                        >
                          +
                        </button>
                      </div>

                      <div className="flex items-center gap-1.5 text-xs text-purple-300/60">
                        <button
                          onClick={() => saveForLater(item.product)}
                          title="Save for Later"
                          className="hover:text-[#FDE047] p-1"
                        >
                          <Bookmark className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => removeFromCart(item.product.id)}
                          title="Remove"
                          className="hover:text-red-400 p-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Saved For Later */}
            {savedItems.length > 0 && (
              <div className="pt-4 border-t border-[#2d1b46] space-y-2.5">
                <span className="text-xs font-whimsical uppercase text-purple-300/70 font-semibold block">
                  Saved For Later ({savedItems.length})
                </span>
                {savedItems.map((p) => (
                  <div
                    key={p.id}
                    className="p-2.5 rounded-xl bg-[#0d0814] border border-[#2d1b46] flex items-center justify-between gap-3 text-xs"
                  >
                    <div className="truncate font-whimsical">
                      <div className="font-bold text-white truncate">{p.name}</div>
                      <div className="text-[11px] font-mono-nums text-[#FDE047]">${p.price}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => moveSavedToCart(p)}
                        className="px-2.5 py-1 rounded-lg bg-[#D4AF37] text-black font-whimsical text-[11px] font-bold"
                      >
                        Attune
                      </button>
                      <button
                        onClick={() => removeSaved(p.id)}
                        className="text-purple-300/60 hover:text-white"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Footer Area */}
          {cart.length > 0 && (
            <div className="p-5 bg-[#0d0814] border-t border-[#2d1b46] space-y-4">
              {/* Coupon */}
              <form onSubmit={handleApplyCoupon} className="flex gap-2">
                <div className="relative flex-1">
                  <input
                    type="text"
                    placeholder="Runic code (e.g. SPOOKY20)"
                    value={couponInput}
                    onChange={(e) => setCouponInput(e.target.value)}
                    className="w-full bg-[#170e24] border border-[#2d1b46] rounded-xl px-3 py-2 text-xs text-white placeholder-purple-300/40 focus:outline-none focus:border-[#D4AF37]"
                  />
                  <Tag className="absolute right-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-purple-400/50" />
                </div>
                <button
                  type="submit"
                  className="px-3.5 py-2 rounded-xl bg-[#1e1330] border border-[#D4AF37]/50 text-xs font-whimsical text-[#FDE047] hover:bg-[#D4AF37] hover:text-black transition-all"
                >
                  Inscribe
                </button>
              </form>

              {couponMsg && (
                <div
                  className={`text-xs font-whimsical ${
                    couponMsg.success ? 'text-emerald-400' : 'text-red-400'
                  }`}
                >
                  {couponMsg.text}
                </div>
              )}

              {/* Price Breakdown */}
              <div className="space-y-1.5 text-xs font-whimsical text-purple-300/80 pt-2 border-t border-[#2d1b46]/70">
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span className="font-mono-nums text-white">${cartSubtotal}</span>
                </div>
                {cartDiscount > 0 && (
                  <div className="flex justify-between text-emerald-400">
                    <span>Coven Discount:</span>
                    <span className="font-mono-nums">-${cartDiscount}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Astral Dispatch:</span>
                  <span className="font-mono-nums text-white">
                    {cartShipping === 0 ? 'Free' : `$${cartShipping}`}
                  </span>
                </div>
                <div className="flex justify-between font-witch text-base text-white pt-2 border-t border-[#2d1b46]">
                  <span>Total Tribute:</span>
                  <span className="text-[#FDE047]">${cartTotal}</span>
                </div>
              </div>

              {/* Checkout CTA */}
              <button
                onClick={handleCheckout}
                className="w-full py-3 px-4 rounded-xl font-whimsical text-xs uppercase tracking-wider text-black font-bold bg-[#D4AF37] hover:bg-[#FDE047] transition-all flex items-center justify-center gap-2 shadow-[0_0_16px_rgba(212,175,55,0.3)]"
              >
                <span>Proceed to Astral Checkout</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="flex items-center justify-center gap-1.5 text-[10px] font-whimsical text-purple-300/60 text-center">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Protected by Runic Ward of High Coven</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
