import React, { useState } from 'react';
import { Product } from '../types';
import { useSuper } from '../context/SuperContext';
import { X, Sparkles, ShoppingBag, Heart, ArrowRight } from 'lucide-react';

interface QuickViewModalProps {
  product: Product | null;
  onClose: () => void;
}

export const QuickViewModal: React.FC<QuickViewModalProps> = ({ product, onClose }) => {
  const { addToCart, toggleWishlist, isInWishlist, navigateTo } = useSuper();

  if (!product) return null;

  const [qty, setQty] = useState(1);
  const [selectedVariant, setSelectedVariant] = useState(product.variants?.[0] || 'Standard Spec');

  const isWish = isInWishlist(product.id);

  const handleAdd = () => {
    addToCart(product, qty, selectedVariant);
    onClose();
  };

  const handleFullInspect = () => {
    onClose();
    navigateTo('product', { productId: product.id });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose} />

      <div className="relative w-full max-w-2xl bg-[#170e24] border border-[#D4AF37]/50 rounded-3xl p-6 sm:p-8 arcane-card z-10 space-y-6 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full bg-[#0d0814] border border-[#D4AF37]/30 text-purple-300 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 items-center">
          {/* Left: Image & Badge */}
          <div className="relative aspect-[4/3] rounded-2xl overflow-hidden border border-[#D4AF37]/40 bg-[#0d0814]">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute top-2 left-2 px-2.5 py-0.5 rounded-full font-whimsical text-xs uppercase bg-[#0d0814]/90 text-[#FDE047] border border-[#D4AF37]/40">
              {product.powerGrade}
            </div>
            <div className="absolute bottom-2 left-2 px-2 py-0.5 rounded-full bg-[#0d0814]/90 backdrop-blur-sm text-[10px] font-whimsical text-purple-200">
              {product.rarity} · {product.archetype}
            </div>
          </div>

          {/* Right: Details & Action */}
          <div className="space-y-3">
            <div className="text-xs font-whimsical text-purple-300/70 uppercase tracking-wider">
              {product.category} · {product.magicType}
            </div>

            <h2 className="font-witch text-2xl text-white leading-tight">
              {product.name}
            </h2>

            <div className="flex items-center gap-3">
              <span className="font-witch text-2xl text-[#FDE047]">
                ${product.price}
              </span>
              <span className="text-xs font-whimsical text-purple-300 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-[#FDE047]" /> {product.powerLevel} Potency
              </span>
            </div>

            <p className="text-xs font-whimsical text-purple-200/80 leading-relaxed">
              {product.shortDesc}
            </p>

            {/* Variants if present */}
            {product.variants && product.variants.length > 0 && (
              <div className="space-y-1">
                <span className="text-[10px] font-whimsical uppercase text-purple-300/70">Potency Dosage:</span>
                <div className="flex flex-wrap gap-1.5">
                  {product.variants.map((v) => (
                    <button
                      key={v}
                      onClick={() => setSelectedVariant(v)}
                      className={`px-2.5 py-1 text-xs font-whimsical rounded-lg border transition-colors ${
                        selectedVariant === v
                          ? 'bg-[#D4AF37] text-black font-bold border-[#FDE047]'
                          : 'bg-[#0d0814] text-purple-200 border-[#2d1b46]'
                      }`}
                    >
                      {v}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={handleAdd}
                className="flex-1 py-2.5 px-4 rounded-xl font-whimsical text-xs uppercase tracking-wider text-black font-bold bg-[#D4AF37] hover:bg-[#FDE047] transition-all flex items-center justify-center gap-2 shadow-[0_0_12px_rgba(212,175,55,0.3)]"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Attune Relic</span>
              </button>

              <button
                onClick={() => toggleWishlist(product.id)}
                className="p-2.5 rounded-xl border border-[#D4AF37]/40 bg-[#0d0814] text-purple-200 hover:text-white transition-colors"
              >
                <Heart className={`w-4 h-4 ${isWish ? 'fill-[#D4AF37] text-[#D4AF37]' : ''}`} />
              </button>
            </div>

            <button
              onClick={handleFullInspect}
              className="w-full text-center text-xs font-whimsical text-[#FDE047] hover:text-amber-200 flex items-center justify-center gap-1 pt-1"
            >
              <span>View Sacred Grimoire Entry</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
