import React, { useState } from 'react';
import { useSuper } from '../context/SuperContext';
import {
  Sparkles,
  Lock,
  Mail,
  User,
  MapPin,
  Eye,
  EyeOff,
  ShieldCheck,
  CheckCircle2,
  Moon,
  Sun,
  Flame,
  Zap,
} from 'lucide-react';

export const LoginPage: React.FC = () => {
  const {
    loginUser,
    signUpUser,
    user,
    navigateTo,
    triggerSoundFx,
    isVillainMode,
    toggleVillainMode,
  } = useSuper();

  const [mode, setMode] = useState<'login' | 'signup'>('signup');
  const [showPassword, setShowPassword] = useState(false);

  // Form Fields
  const [name, setName] = useState(user.name || '');
  const [alias, setAlias] = useState(user.alias || '');
  const [email, setEmail] = useState(user.email || '');
  const [password, setPassword] = useState('ArcanePass2026!');
  const [address, setAddress] = useState(user.hideoutAddress || '');
  const [affinity, setAffinity] = useState('Celestial Solar');
  const [covenantRole, setCovenantRole] = useState<'Hero' | 'Villain'>('Hero');
  const [agreedOath, setAgreedOath] = useState(true);

  // Success state
  const [isSuccess, setIsSuccess] = useState(false);

  const calculatePasswordStrength = (pass: string) => {
    if (!pass) return { score: 0, text: 'No Runes Inscribed', color: 'bg-gray-500' };
    if (pass.length < 6) return { score: 1, text: 'Fragile Ward', color: 'bg-red-500' };
    if (pass.length < 10) return { score: 2, text: 'Adequate Ward', color: 'bg-yellow-500' };
    return { score: 3, text: 'Impenetrable Elder Ward', color: 'bg-emerald-500' };
  };

  const strength = calculatePasswordStrength(password);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) return;

    if (mode === 'signup') {
      signUpUser({
        name: name || 'Adept Seeker',
        alias: alias || 'Solar Alchemist',
        email,
        address: address || 'Sanctuary Spire, Mystic Realm',
        affinity,
        roleOath: covenantRole,
      });
      if (covenantRole === 'Villain' && !isVillainMode) {
        toggleVillainMode();
      } else if (covenantRole === 'Hero' && isVillainMode) {
        toggleVillainMode();
      }
    } else {
      loginUser(email, alias || user.alias);
    }

    setIsSuccess(true);
    triggerSoundFx('✦ COVENANT BOUND');

    setTimeout(() => {
      navigateTo('account');
    }, 1400);
  };

  return (
    <div
      className={`min-h-screen py-12 px-4 sm:px-6 flex items-center justify-center transition-colors duration-400 ${
        isVillainMode ? 'bg-[#07040B] text-[#F3E8FF]' : 'bg-[#F8F5EE] text-[#1F1432]'
      }`}
    >
      <div className="w-full max-w-2xl space-y-8 animate-in fade-in zoom-in-95 duration-300">
        {/* Top Arcane Branding */}
        <div className="text-center space-y-2">
          <button
            onClick={() => navigateTo('home')}
            className="inline-flex items-center gap-2 p-2 rounded-2xl bg-black/10 hover:bg-black/20 transition-all"
          >
            <div className="w-10 h-10 rounded-xl bg-[#D4AF37]/20 border border-[#D4AF37] flex items-center justify-center text-[#D4AF37] font-witch text-xl font-bold">
              ✦
            </div>
            <span className="font-display font-black text-2xl tracking-wider">
              SUPRANOVA
            </span>
          </button>
          <h1 className="font-witch text-3xl sm:text-4xl font-bold tracking-wide">
            {mode === 'signup' ? 'Initiate Adept Covenant' : 'Enter Sanctum Dossier'}
          </h1>
          <p className="font-whimsical text-sm opacity-75 max-w-md mx-auto">
            {mode === 'signup'
              ? 'Inscribe your true mortal name, secret power alias, and sanctuary coordinates into the High Coven Registry.'
              : 'Provide your secret coven correspondence runes to access your personal powers vault.'}
          </p>
        </div>

        {/* Form Container */}
        <div
          className={`relative p-6 sm:p-10 rounded-3xl border shadow-2xl overflow-hidden transition-all ${
            isVillainMode
              ? 'bg-[#150924] border-[#D4AF37]/40 shadow-[0_12px_40px_rgba(0,0,0,0.8)]'
              : 'bg-[#FFFFFF] border-[#D4AF37]/50 shadow-[0_12px_40px_rgba(0,0,0,0.1)]'
          }`}
        >
          {/* Animated Background Arcane Seal */}
          <div className="absolute -right-16 -top-16 w-64 h-64 opacity-10 pointer-events-none animate-spin-slow">
            <svg viewBox="0 0 100 100" className="w-full h-full stroke-current">
              <circle cx="50" cy="50" r="45" fill="none" strokeWidth="1" strokeDasharray="4 4" />
              <circle cx="50" cy="50" r="35" fill="none" strokeWidth="1" />
              <polygon points="50,15 80,75 20,75" fill="none" strokeWidth="1" />
              <polygon points="50,85 80,25 20,25" fill="none" strokeWidth="1" />
            </svg>
          </div>

          {/* Mode Tabs */}
          <div
            className={`flex items-center p-1 rounded-2xl border mb-8 text-xs font-whimsical ${
              isVillainMode ? 'bg-[#07040B] border-[#2d1b46]' : 'bg-[#F2ECE0] border-[#D8CEB8]'
            }`}
          >
            <button
              type="button"
              onClick={() => {
                setMode('signup');
                triggerSoundFx('✦ Inscription Mode');
              }}
              className={`flex-1 py-2 rounded-xl font-bold transition-all ${
                mode === 'signup'
                  ? 'bg-[#D4AF37] text-black shadow-md'
                  : 'opacity-70 hover:opacity-100'
              }`}
            >
              ✦ Create Adept Account (Sign Up)
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('login');
                triggerSoundFx('✦ Sanctum Access');
              }}
              className={`flex-1 py-2 rounded-xl font-bold transition-all ${
                mode === 'login'
                  ? 'bg-[#D4AF37] text-black shadow-md'
                  : 'opacity-70 hover:opacity-100'
              }`}
            >
              ✧ Existing Adept Sign In
            </button>
          </div>

          {/* Success Message Banner */}
          {isSuccess ? (
            <div className="py-12 text-center space-y-4 font-whimsical animate-in zoom-in-95">
              <div className="w-16 h-16 rounded-full bg-[#D4AF37]/20 border-2 border-[#D4AF37] flex items-center justify-center mx-auto text-[#D4AF37]">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              <h3 className="font-witch text-2xl text-[#D4AF37]">
                Sacred Covenant Sealed!
              </h3>
              <p className="text-sm opacity-80 max-w-sm mx-auto">
                Your aura has synchronized with the Supranova Grimoire. Materializing your Hero Dossier...
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-5 text-xs font-whimsical">
              {mode === 'signup' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Adept Full Name */}
                  <div>
                    <label className="block mb-1.5 font-semibold opacity-80">
                      Mortal Identity Name
                    </label>
                    <div className="relative">
                      <User className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 opacity-50" />
                      <input
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="e.g. Rajesh P. Bathija"
                        className="w-full pl-9 pr-3 py-2.5 rounded-xl border bg-black/10 focus:outline-none focus:border-[#D4AF37] transition-colors"
                      />
                    </div>
                  </div>

                  {/* Hero / Villan Alias */}
                  <div>
                    <label className="block mb-1.5 font-semibold opacity-80">
                      Chosen Superpower Alias
                    </label>
                    <div className="relative">
                      <Sparkles className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#D4AF37]" />
                      <input
                        type="text"
                        required
                        value={alias}
                        onChange={(e) => setAlias(e.target.value)}
                        placeholder="e.g. High Alchemist Bathija"
                        className="w-full pl-9 pr-3 py-2.5 rounded-xl border bg-black/10 focus:outline-none focus:border-[#D4AF37] transition-colors"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Email */}
              <div>
                <label className="block mb-1.5 font-semibold opacity-80">
                  Coven Correspondence Email
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 opacity-50" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="bathijarajeshp@gmail.com"
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl border bg-black/10 focus:outline-none focus:border-[#D4AF37] transition-colors"
                  />
                </div>
              </div>

              {/* Password */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="font-semibold opacity-80">Runic Cipher Password</label>
                  {mode === 'signup' && (
                    <span className="text-[10px] opacity-75">{strength.text}</span>
                  )}
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 opacity-50" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full pl-9 pr-10 py-2.5 rounded-xl border bg-black/10 focus:outline-none focus:border-[#D4AF37] transition-colors"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 opacity-60 hover:opacity-100"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>

                {mode === 'signup' && (
                  <div className="w-full bg-black/10 rounded-full h-1.5 mt-2 overflow-hidden flex gap-1">
                    <div
                      className={`h-full flex-1 rounded-full transition-all ${
                        strength.score >= 1 ? strength.color : 'bg-transparent'
                      }`}
                    />
                    <div
                      className={`h-full flex-1 rounded-full transition-all ${
                        strength.score >= 2 ? strength.color : 'bg-transparent'
                      }`}
                    />
                    <div
                      className={`h-full flex-1 rounded-full transition-all ${
                        strength.score >= 3 ? strength.color : 'bg-transparent'
                      }`}
                    />
                  </div>
                )}
              </div>

              {mode === 'signup' && (
                <>
                  {/* Sanctuary Address */}
                  <div>
                    <label className="block mb-1.5 font-semibold opacity-80">
                      Sanctuary / Courier Delivery Spire Address
                    </label>
                    <div className="relative">
                      <MapPin className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 opacity-50" />
                      <input
                        type="text"
                        required
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                        placeholder="Sanctuary Spire 44, Mystic Haven"
                        className="w-full pl-9 pr-3 py-2.5 rounded-xl border bg-black/10 focus:outline-none focus:border-[#D4AF37] transition-colors"
                      />
                    </div>
                  </div>

                  {/* Alignment & Covenant Oath */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                    <div>
                      <label className="block mb-1.5 font-semibold opacity-80">
                        Primary Astral Affinity
                      </label>
                      <select
                        value={affinity}
                        onChange={(e) => setAffinity(e.target.value)}
                        className={`w-full px-3 py-2.5 rounded-xl border bg-black/10 focus:outline-none focus:border-[#D4AF37] ${
                          isVillainMode ? 'text-white bg-[#07040B]' : 'text-black bg-white'
                        }`}
                      >
                        <option value="Celestial Solar">✦ Celestial Solar (Dawn Radiance)</option>
                        <option value="Midnight Shadow">🌙 Midnight Shadow (Eclipse Void)</option>
                        <option value="Alchemical Spark">⚡ Alchemical Spark (Voltaris)</option>
                        <option value="Aether Flight">🕊️ Aether Wind (Nimbus Soar)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block mb-1.5 font-semibold opacity-80">
                        Covenant Realm Allegiance
                      </label>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => setCovenantRole('Hero')}
                          className={`flex-1 py-2 px-3 rounded-xl border font-bold flex items-center justify-center gap-1.5 transition-all ${
                            covenantRole === 'Hero'
                              ? 'bg-[#D4AF37] text-black border-[#D4AF37]'
                              : 'opacity-60 border-current hover:opacity-100'
                          }`}
                        >
                          <Sun className="w-3.5 h-3.5" />
                          <span>Hero Dawn</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setCovenantRole('Villain')}
                          className={`flex-1 py-2 px-3 rounded-xl border font-bold flex items-center justify-center gap-1.5 transition-all ${
                            covenantRole === 'Villain'
                              ? 'bg-[#9333EA] text-white border-[#C084FC]'
                              : 'opacity-60 border-current hover:opacity-100'
                          }`}
                        >
                          <Moon className="w-3.5 h-3.5" />
                          <span>Villan Dusk</span>
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Oath Checkbox */}
                  <label className="flex items-start gap-2.5 pt-1 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={agreedOath}
                      onChange={(e) => setAgreedOath(e.target.checked)}
                      className="mt-0.5 rounded accent-[#D4AF37]"
                    />
                    <span className="opacity-80 text-[11px] leading-relaxed">
                      I solemnly swear to honor the High Coven Non-Proliferation Accord and test bottled elixirs safely within a 50-meter warded perimeter.
                    </span>
                  </label>
                </>
              )}

              {/* Submit Button */}
              <button
                type="submit"
                disabled={mode === 'signup' && !agreedOath}
                className="w-full py-3.5 px-6 rounded-2xl bg-[#D4AF37] hover:bg-[#FDE047] text-black font-witch text-sm font-bold uppercase tracking-wider transition-all hover:scale-[1.01] shadow-[0_0_20px_rgba(212,175,55,0.35)] flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <Sparkles className="w-4 h-4" />
                <span>
                  {mode === 'signup' ? 'Seal Sacred Covenant' : 'Unlock Sanctum Dossier'}
                </span>
              </button>
            </form>
          )}

          {/* Quick Switch Footer */}
          <div className="mt-6 text-center text-xs font-whimsical opacity-75">
            {mode === 'signup' ? (
              <span>
                Already registered in the Grimoire?{' '}
                <button
                  onClick={() => setMode('login')}
                  className="text-[#D4AF37] font-bold hover:underline"
                >
                  Sign In to Sanctum
                </button>
              </span>
            ) : (
              <span>
                New adept seeking powers?{' '}
                <button
                  onClick={() => setMode('signup')}
                  className="text-[#D4AF37] font-bold hover:underline"
                >
                  Initiate New Covenant
                </button>
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
