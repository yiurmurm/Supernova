import React, { useState, useRef, useEffect } from 'react';
import { useSuper } from '../context/SuperContext';
import { CATEGORIES_DATA } from '../data/products';
import { CategoryId } from '../types';
import {
  Search,
  Heart,
  ShoppingBag,
  User,
  Menu,
  X,
  ChevronDown,
  Sparkles,
  Sun,
  Moon,
  Zap,
  Layers,
} from 'lucide-react';

const PROMO_BANNERS = [
  '✦ SACRED SOLSTICE: HAND-CRAFTED ELIXIRS & SUMMONING RITUALS',
  '✨ MYSTIC OFFER: 20% OFF POTIONS & SPRAYS WITH RUNIC CODE SPOOKY20',
  '🌙 CELESTIAL DISPATCH: INSTANT TELEPORT TO YOUR SANCTUARY OVER $250',
  '✦ GRIMOIRE ARCHIVE: CODE SUPRA25 UNLOCKS 25% ALCHEMICAL ESSENCE',
];

export const Navbar: React.FC = () => {
  const {
    currentView,
    navigateTo,
    cart,
    wishlist,
    setIsCartOpen,
    user,
    isLoggedIn,
    setIsLoginModalOpen,
    powerSurge,
    setPowerSurge,
    isVillainMode,
    toggleVillainMode,
    searchQuery,
    setSearchQuery,
    triggerSoundFx,
    comparedProductIds,
    setIsCompareOpen,
  } = useSuper();

  const [promoIdx, setPromoIdx] = useState(0);
  const [showPromo, setShowPromo] = useState(true);
  const [isCategoryOpen, setIsCategoryOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isSurgeModalOpen, setIsSurgeModalOpen] = useState(false);

  const categoryDropdownRef = useRef<HTMLDivElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);

  // Cycle promo banner
  useEffect(() => {
    const timer = setInterval(() => {
      setPromoIdx((prev) => (prev + 1) % PROMO_BANNERS.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  // Close dropdown on click outside
  useEffect(() => {
    const onClickOutside = (e: MouseEvent) => {
      if (categoryDropdownRef.current && !categoryDropdownRef.current.contains(e.target as Node)) {
        setIsCategoryOpen(false);
      }
    };
    document.addEventListener('mousedown', onClickOutside);
    return () => document.removeEventListener('mousedown', onClickOutside);
  }, []);

  const totalCartItems = cart.reduce((sum, item) => sum + item.quantity, 0);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigateTo('shop');
      setIsSearchOpen(false);
      triggerSoundFx('✦ Scrying Grimoire');
    }
  };

  const primaryGold = isVillainMode ? '#F59E0B' : '#D4AF37';

  return (
    <header className="sticky top-0 z-40 w-full bg-[#0d0814]/90 dark:bg-[#050308]/95 backdrop-blur-md border-b border-[#2d1b46]/70 transition-colors duration-300">
      {/* Promotional Top Ticker Banner */}
      {showPromo && (
        <div
          className="relative px-4 py-1.5 text-xs text-center font-whimsical tracking-wide uppercase overflow-hidden transition-colors border-b border-[#2d1b46]/60"
          style={{
            backgroundColor: isVillainMode ? '#1e0d33' : '#170e24',
            color: '#FDE047',
          }}
        >
          <div className="flex items-center justify-center gap-2 max-w-7xl mx-auto truncate text-[11px] sm:text-xs">
            <Sparkles className="w-3.5 h-3.5 shrink-0 text-[#FDE047] animate-pulse" />
            <span className="truncate tracking-wider font-semibold">{PROMO_BANNERS[promoIdx]}</span>
          </div>
          <button
            onClick={() => setShowPromo(false)}
            aria-label="Dismiss banner"
            className="absolute right-3 top-1/2 -translate-y-1/2 hover:opacity-70 text-[#FDE047] font-serif text-sm"
          >
            ×
          </button>
        </div>
      )}

      {/* Main Top Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Zone 1: Single Brand Wordmark in Whimsical Display Font */}
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigateTo('home')}
            className="group flex items-center gap-2 text-left focus:outline-none"
          >
            <div
              className="w-9 h-9 rounded-xl border border-[#D4AF37]/60 flex items-center justify-center bg-[#1e1330] shadow-[0_0_15px_rgba(212,175,55,0.3)] group-hover:border-[#FDE047] group-hover:shadow-[0_0_20px_rgba(253,224,71,0.5)] transition-all relative overflow-hidden"
            >
              <div className="text-sm">🌙</div>
              <span className="font-witch text-xs text-[#FDE047] absolute top-1 right-1 animate-twinkle">✦</span>
            </div>
            <div className="flex flex-col">
              <span className="font-display font-black text-2xl tracking-wider text-white group-hover:text-[#FDE047] transition-colors flex items-center gap-1">
                SUPRANOVA
                <span className="text-xs text-[#FDE047] font-normal">✧</span>
              </span>
              <span className="text-[9px] font-whimsical tracking-widest text-[#FDE047]/80 uppercase -mt-1 hidden sm:block">
                Celestial Apothecary
              </span>
            </div>
          </button>

          {/* DAY / NIGHT (Hero / Villan) Mode Switcher */}
          <button
            onClick={toggleVillainMode}
            title="Toggle between Hero Mode (Day) and Villan Mode (Night)"
            className={`hidden md:flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-whimsical tracking-wide uppercase border transition-all duration-300 ${
              isVillainMode
                ? 'bg-[#1e0d33] text-[#FBBF24] border-[#9333EA] shadow-[0_0_12px_rgba(147,51,234,0.3)]'
                : 'bg-[#1e1330] text-[#FDE047] border-[#D4AF37]/60 shadow-[0_0_12px_rgba(212,175,55,0.25)]'
            }`}
          >
            {isVillainMode ? (
              <>
                <Moon className="w-3.5 h-3.5 text-[#C084FC]" />
                <span className="font-bold">Villan Mode (Night)</span>
              </>
            ) : (
              <>
                <Sun className="w-3.5 h-3.5 text-[#FDE047]" />
                <span className="font-bold">Hero Mode (Day)</span>
              </>
            )}
          </button>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden lg:flex items-center gap-6 text-sm font-whimsical tracking-wide text-purple-200/80">
          <button
            onClick={() => navigateTo('home')}
            className={`hover:text-[#FDE047] transition-colors pb-0.5 border-b ${
              currentView === 'home' ? 'text-[#FDE047] border-[#D4AF37]' : 'border-transparent'
            }`}
          >
            Sanctuary
          </button>

          <button
            onClick={() => navigateTo('shop')}
            className={`hover:text-[#FDE047] transition-colors pb-0.5 border-b ${
              currentView === 'shop' ? 'text-[#FDE047] border-[#D4AF37]' : 'border-transparent'
            }`}
          >
            Arcane Shop
          </button>

          {/* Categories Dropdown */}
          <div className="relative" ref={categoryDropdownRef}>
            <button
              onClick={() => setIsCategoryOpen(!isCategoryOpen)}
              className="flex items-center gap-1 hover:text-[#FDE047] transition-colors py-1"
            >
              <span>Grimoires</span>
              <ChevronDown
                className={`w-3.5 h-3.5 transition-transform ${isCategoryOpen ? 'rotate-180 text-[#FDE047]' : ''}`}
              />
            </button>

            {isCategoryOpen && (
              <div className="absolute top-full left-0 mt-2 w-64 bg-[#170e24] border border-[#D4AF37]/40 rounded-xl shadow-[0_12px_30px_rgba(0,0,0,0.8),0_0_20px_rgba(212,175,55,0.15)] p-2 z-50 animate-in fade-in zoom-in-95 duration-100">
                <div className="px-3 py-1.5 text-[10px] font-whimsical uppercase tracking-wider text-purple-300/60 border-b border-[#2d1b46]">
                  Select Power Grimoire
                </div>
                {CATEGORIES_DATA.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => {
                      navigateTo('category', { categoryId: cat.id as CategoryId });
                      setIsCategoryOpen(false);
                    }}
                    className="w-full text-left px-3 py-2 text-sm text-purple-100 hover:text-[#FDE047] hover:bg-[#26183d] rounded-lg flex items-center justify-between group transition-colors"
                  >
                    <div>
                      <div className="font-whimsical font-semibold group-hover:text-[#FDE047] transition-colors">
                        {cat.name}
                      </div>
                      <div className="text-[11px] text-purple-300/60 truncate">{cat.tagline}</div>
                    </div>
                    <span className="text-xs text-[#D4AF37]/60 font-mono-nums">{cat.number}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          <button
            onClick={() => navigateTo('quiz')}
            className="flex items-center gap-1.5 text-[#FDE047] hover:text-amber-200 transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Power Quiz</span>
          </button>

          <button
            onClick={() => navigateTo('help')}
            className="hover:text-[#FDE047] transition-colors text-purple-200/70"
          >
            Support Witch
          </button>
        </nav>

        {/* Zone 3: Actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Search */}
          <div className="relative">
            {isSearchOpen ? (
              <form onSubmit={handleSearchSubmit} className="flex items-center">
                <input
                  ref={searchInputRef}
                  type="text"
                  placeholder="Search potions, charms, rings..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-44 sm:w-60 bg-[#170e24] border border-[#D4AF37]/50 rounded-lg px-3 py-1 text-xs text-white placeholder-purple-300/40 focus:outline-none focus:border-[#FDE047]"
                  autoFocus
                />
                <button
                  type="button"
                  onClick={() => setIsSearchOpen(false)}
                  className="ml-1 p-1 text-purple-300 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </form>
            ) : (
              <button
                onClick={() => {
                  setIsSearchOpen(true);
                  setTimeout(() => searchInputRef.current?.focus(), 100);
                }}
                title="Search Arcana"
                className="p-2 text-purple-200/80 hover:text-[#FDE047] rounded-lg hover:bg-[#1e1330] transition-colors"
              >
                <Search className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Power Potency Gauge */}
          <button
            onClick={() => setIsSurgeModalOpen(!isSurgeModalOpen)}
            title="Apothecary Potency Surge"
            className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 text-xs font-whimsical rounded-lg bg-[#170e24] border border-[#D4AF37]/30 hover:border-[#D4AF37] text-purple-100 transition-colors"
          >
            <Zap className="w-3.5 h-3.5 text-[#FDE047]" />
            <span className="font-mono-nums text-[#FDE047] font-semibold">{powerSurge}% Potency</span>
          </button>

          {/* Web Map Compare Mode */}
          <button
            onClick={() => {
              setIsCompareOpen(true);
              triggerSoundFx('✦ Astral Web Map Opened');
            }}
            title="Astral Comparison Web Map"
            className="relative p-2 text-purple-200/80 hover:text-[#FDE047] rounded-lg hover:bg-[#1e1330] transition-colors"
          >
            <Layers className="w-4 h-4 text-[#FDE047]" />
            {comparedProductIds.length > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#7E22CE] border border-[#C084FC] text-white text-[10px] font-bold rounded-full flex items-center justify-center animate-pulse">
                {comparedProductIds.length}
              </span>
            )}
          </button>

          {/* Wishlist */}
          <button
            onClick={() => navigateTo('account')}
            title="Sacred Wishlist"
            className="relative p-2 text-purple-200/80 hover:text-[#FDE047] rounded-lg hover:bg-[#1e1330] transition-colors"
          >
            <Heart className="w-4 h-4" />
            {wishlist.length > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#D4AF37] text-black text-[10px] font-bold rounded-full flex items-center justify-center">
                {wishlist.length}
              </span>
            )}
          </button>

          {/* Satchel Cart */}
          <button
            onClick={() => {
              setIsCartOpen(true);
              triggerSoundFx('✨ Satchel Opened');
            }}
            title="Arcane Satchel"
            className="group relative flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#1e1330] border border-[#D4AF37]/50 hover:border-[#FDE047] shadow-[0_0_12px_rgba(212,175,55,0.15)] transition-all"
          >
            <ShoppingBag className="w-4 h-4 text-[#FDE047] group-hover:scale-110 transition-transform" />
            <span className="hidden sm:inline font-whimsical text-xs tracking-wider text-purple-100 uppercase">
              Satchel
            </span>
            <span className="px-1.5 py-0.2 rounded-full text-[10px] font-mono-nums font-bold bg-[#D4AF37] text-black">
              {totalCartItems}
            </span>
          </button>

          {/* User Alchemist Dossier or Login */}
          <button
            onClick={() => {
              navigateTo('login');
            }}
            title={isLoggedIn ? `Alchemist: ${user.alias} (Dossier)` : 'Sign In / Register'}
            className="p-1.5 rounded-xl border border-[#D4AF37]/40 hover:border-[#FDE047] bg-[#170e24] flex items-center gap-1.5 transition-all text-xs font-whimsical"
          >
            {isLoggedIn ? (
              <>
                <img
                  src={user.avatar}
                  alt={user.alias}
                  className="w-5 h-5 rounded-full"
                  referrerPolicy="no-referrer"
                />
                <span className="hidden xl:inline text-[#FDE047] max-w-[80px] truncate">
                  {user.alias}
                </span>
              </>
            ) : (
              <>
                <User className="w-4 h-4 text-purple-200/80" />
                <span className="hidden md:inline text-purple-200">Sign In</span>
              </>
            )}
          </button>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="p-2 lg:hidden text-purple-200/80 hover:text-white"
          >
            {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Potency Surge Slider Drawer */}
      {isSurgeModalOpen && (
        <div className="border-t border-[#2d1b46] bg-[#170e24] px-4 py-3 shadow-inner">
          <div className="max-w-md mx-auto flex items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4 text-[#FDE047]" />
              <span className="text-xs font-whimsical uppercase text-purple-200">
                Alchemical Potency:
              </span>
              <span className="text-xs font-mono text-[#FDE047] font-bold">{powerSurge}%</span>
            </div>
            <input
              type="range"
              min="20"
              max="100"
              value={powerSurge}
              onChange={(e) => setPowerSurge(Number(e.target.value))}
              className="flex-1 accent-[#D4AF37] cursor-pointer"
            />
            <button
              onClick={() => setIsSurgeModalOpen(false)}
              className="text-xs text-purple-300/70 hover:text-white"
            >
              Done
            </button>
          </div>
        </div>
      )}

      {/* Mobile Menu Drawer */}
      {isMobileMenuOpen && (
        <div className="lg:hidden border-t border-[#2d1b46] bg-[#170e24] px-4 py-6 space-y-4 animate-in slide-in-from-top-2">
          {/* Day / Night Toggle on Mobile */}
          <button
            onClick={() => {
              toggleVillainMode();
              setIsMobileMenuOpen(false);
            }}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl border border-[#D4AF37]/50 bg-[#1e1330] text-xs font-whimsical uppercase text-[#FDE047]"
          >
            {isVillainMode ? (
              <>
                <Moon className="w-4 h-4 text-[#C084FC]" />
                <span>Switch to Hero Mode (Day)</span>
              </>
            ) : (
              <>
                <Sun className="w-4 h-4 text-[#FDE047]" />
                <span>Switch to Villan Mode (Night)</span>
              </>
            )}
          </button>

          <div className="space-y-2 text-sm font-whimsical">
            <button
              onClick={() => {
                navigateTo('home');
                setIsMobileMenuOpen(false);
              }}
              className="block w-full text-left py-2 text-purple-100 hover:text-[#FDE047]"
            >
              Sanctuary
            </button>
            <button
              onClick={() => {
                navigateTo('shop');
                setIsMobileMenuOpen(false);
              }}
              className="block w-full text-left py-2 text-purple-100 hover:text-[#FDE047]"
            >
              Arcane Shop
            </button>
            <button
              onClick={() => {
                navigateTo('quiz');
                setIsMobileMenuOpen(false);
              }}
              className="block w-full text-left py-2 text-[#FDE047]"
            >
              ✦ Power Quiz
            </button>
            <button
              onClick={() => {
                navigateTo('help');
                setIsMobileMenuOpen(false);
              }}
              className="block w-full text-left py-2 text-purple-100 hover:text-[#FDE047]"
            >
              Support Witch
            </button>
            <button
              onClick={() => {
                navigateTo('account');
                setIsMobileMenuOpen(false);
              }}
              className="block w-full text-left py-2 text-purple-100 hover:text-[#FDE047]"
            >
              Alchemist Dossier
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
