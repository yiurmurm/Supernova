import React, { useState } from 'react';
import { useSuper } from '../context/SuperContext';
import { Order } from '../types';
import { InteractiveDeliveryMap } from './InteractiveDeliveryMap';
import {
  MapPin,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  CreditCard,
  Layers,
} from 'lucide-react';

export const CheckoutPage: React.FC = () => {
  const {
    cart,
    cartSubtotal,
    cartDiscount,
    cartShipping,
    cartTotal,
    user,
    placeOrder,
    navigateTo,
    triggerSoundFx,
  } = useSuper();

  const [heroAlias, setHeroAlias] = useState(user.alias);
  const [secretEmail, setSecretEmail] = useState(user.email);
  const [hideoutAddress, setHideoutAddress] = useState(user.hideoutAddress);
  const [deliveryMode, setDeliveryMode] = useState<Order['deliveryMode']>('Sonic Drone');
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'coven-vault'>('card');

  // Interactive Celestial Sanctuary Map
  const [pinPos, setPinPos] = useState({ x: 55, y: 48 });
  const [distanceText, setDistanceText] = useState('2.4 Celestial Leagues from Coven Spire');
  const [isLocating, setIsLocating] = useState(false);

  // Post-order state
  const [confirmedOrder, setConfirmedOrder] = useState<Order | null>(null);

  const handleMapClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = Math.round(((e.clientX - rect.left) / rect.width) * 100);
    const y = Math.round(((e.clientY - rect.top) / rect.height) * 100);
    setPinPos({ x, y });

    const dist = (Math.hypot(x - 20, y - 80) * 0.05).toFixed(1);
    setDistanceText(`${dist} Celestial Leagues from Coven Spire`);
    triggerSoundFx('✦ Sanctuary Marked');
  };

  const handleGPSLocate = () => {
    setIsLocating(true);
    triggerSoundFx('✧ Scrying Sanctuary');
    setTimeout(() => {
      setPinPos({ x: 60, y: 45 });
      setHideoutAddress('Sanctuary Spire 44, Mystic Haven');
      setDistanceText('1.8 Celestial Leagues from Coven Spire');
      setIsLocating(false);
    }, 600);
  };

  const handleDispatchOrder = () => {
    if (cart.length === 0) return;
    const order = placeOrder(deliveryMode, hideoutAddress);
    setConfirmedOrder(order);
    triggerSoundFx('✨ Seal Bound');
  };

  if (confirmedOrder) {
    return (
      <div className="min-h-screen bg-[#0d0814] dark:bg-[#050308] text-white py-12 px-4 sm:px-6">
        <div className="max-w-3xl mx-auto space-y-8">
          <div className="rounded-3xl bg-[#170e24] border border-[#D4AF37]/50 p-8 arcane-card text-center space-y-4">
            <div className="inline-flex p-3 rounded-full bg-[#D4AF37]/20 border border-[#D4AF37] text-[#FDE047]">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <div className="font-witch text-3xl sm:text-4xl text-white tracking-wide">
              Sacred Ritual Inscribed!
            </div>
            <p className="font-whimsical text-purple-200/90 text-sm max-w-lg mx-auto">
              Ritual Order ID: <span className="text-[#FDE047] font-mono-nums font-bold">{confirmedOrder.id}</span> · Method: {confirmedOrder.deliveryMode}
            </p>
            <div className="text-xs font-whimsical text-purple-300/70">
              Sanctuary: <span className="text-white font-semibold">{confirmedOrder.shippingAddress.street}</span>
            </div>
          </div>

          {/* Tracking Step Sequence */}
          <div className="p-6 rounded-3xl bg-[#170e24] border border-[#2d1b46] space-y-6">
            <h3 className="font-witch text-lg text-white">Astral Courier Transit</h3>
            <div className="grid grid-cols-4 gap-2 text-center text-xs font-whimsical">
              <div className="p-2 rounded-xl bg-[#0d0814] border border-[#D4AF37] text-[#FDE047]">
                <div className="font-bold">1. Attuned</div>
                <div className="text-[10px] text-purple-300/60">Brewed</div>
              </div>
              <div className="p-2 rounded-xl bg-[#0d0814] border border-[#D4AF37] text-[#FDE047]">
                <div className="font-bold">2. Sealed</div>
                <div className="text-[10px] text-purple-300/60">Warded</div>
              </div>
              <div className="p-2 rounded-xl bg-[#0d0814] border border-[#D4AF37] text-[#FDE047] animate-pulse">
                <div className="font-bold">3. In Flight</div>
                <div className="text-[10px] text-purple-300/60">Couriers</div>
              </div>
              <div className="p-2 rounded-xl bg-[#0d0814] border border-[#2d1b46] text-purple-400/50">
                <div className="font-bold">4. Summoned</div>
                <div className="text-[10px]">Delivered</div>
              </div>
            </div>

            <div className="flex justify-center pt-2">
              <button
                onClick={() => navigateTo('home')}
                className="px-6 py-2.5 rounded-xl font-whimsical text-xs uppercase tracking-wider text-black font-bold bg-[#D4AF37] hover:bg-[#FDE047] transition-all"
              >
                Return to Sanctuary
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0d0814] dark:bg-[#050308] text-white py-10 px-4 sm:px-6 transition-colors duration-400">
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-xs font-whimsical uppercase text-[#FDE047]">
            <Sparkles className="w-3.5 h-3.5" /> High Coven Finalization
          </div>
          <h1 className="font-witch text-3xl sm:text-4xl text-white">
            Astral Dispatch & Tribute
          </h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Form: Delivery & Coordinates (lg:col-span-7) */}
          <div className="lg:col-span-7 space-y-6">
            {/* Sanctuary Details */}
            <div className="p-6 rounded-2xl bg-[#170e24] border border-[#D4AF37]/30 arcane-card space-y-4">
              <div className="flex items-center gap-2 font-witch text-base text-white">
                <MapPin className="w-4 h-4 text-[#FDE047]" />
                <span>Sanctuary Coordinates</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-whimsical">
                <div>
                  <label className="block text-purple-300/70 mb-1">Alchemist Alias</label>
                  <input
                    type="text"
                    value={heroAlias}
                    onChange={(e) => setHeroAlias(e.target.value)}
                    className="w-full bg-[#0d0814] border border-[#2d1b46] rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>
                <div>
                  <label className="block text-purple-300/70 mb-1">Coven Correspondence</label>
                  <input
                    type="email"
                    value={secretEmail}
                    onChange={(e) => setSecretEmail(e.target.value)}
                    className="w-full bg-[#0d0814] border border-[#2d1b46] rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-purple-300/70 mb-1">Sanctuary Spire Address</label>
                  <input
                    type="text"
                    value={hideoutAddress}
                    onChange={(e) => setHideoutAddress(e.target.value)}
                    className="w-full bg-[#0d0814] border border-[#2d1b46] rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>
              </div>

              {/* Interactive Astral Courier & Owl Delivery Map */}
              <div className="space-y-2 pt-2">
                <div className="flex items-center justify-between text-xs font-whimsical">
                  <span className="text-[#FDE047] font-semibold">
                    Interactive Astral Courier & Delivery Owl Flightpath:
                  </span>
                  <span className="text-purple-300/70">Click map to adjust destination</span>
                </div>

                <InteractiveDeliveryMap
                  onCoordinateSelect={(coords) => {
                    setHideoutAddress(coords.address);
                  }}
                />
              </div>
            </div>

            {/* Astral Delivery Mode */}
            <div className="p-6 rounded-2xl bg-[#170e24] border border-[#D4AF37]/30 arcane-card space-y-3">
              <span className="font-witch text-base text-white block">Dispatch Method</span>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {[
                  { id: 'Sonic Drone', title: 'Astral Courier', time: 'Instant Attunement', fee: 'Free' },
                  { id: 'Instant Teleport', title: 'Dimensional Gate', time: '0.1s Rift', fee: '+$15' },
                  { id: 'Drop-Pod', title: 'Moonlight Familiar', time: 'Nightfall Delivery', fee: 'Free' },
                ].map((mode) => (
                  <button
                    key={mode.id}
                    onClick={() => setDeliveryMode(mode.id as Order['deliveryMode'])}
                    className={`p-3 rounded-xl border text-left font-whimsical transition-all ${
                      deliveryMode === mode.id
                        ? 'border-[#FDE047] bg-[#1e1330] shadow-[0_0_12px_rgba(212,175,55,0.25)]'
                        : 'border-[#2d1b46] bg-[#0d0814] text-purple-300/70 hover:border-[#D4AF37]/40'
                    }`}
                  >
                    <div className="font-bold text-white text-xs">{mode.title}</div>
                    <div className="text-[11px] text-purple-300/60">{mode.time}</div>
                    <div className="text-[11px] text-[#FDE047] font-semibold mt-1">{mode.fee}</div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Right Summary: Review & Finalize (lg:col-span-5) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="p-6 rounded-2xl bg-[#170e24] border border-[#D4AF37]/40 arcane-card space-y-4">
              <h3 className="font-witch text-lg text-white">Attunement Manifest</h3>

              <div className="space-y-3 max-h-56 overflow-y-auto pr-1">
                {cart.map((item) => (
                  <div
                    key={`${item.product.id}-${item.selectedVariant}`}
                    className="flex items-center justify-between gap-3 text-xs font-whimsical"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="w-9 h-9 rounded-lg overflow-hidden border border-[#D4AF37]/30 shrink-0 bg-black">
                        <img
                          src={item.product.image}
                          alt={item.product.name}
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                      <div className="truncate">
                        <div className="text-white font-semibold truncate">{item.product.name}</div>
                        <div className="text-purple-300/60 text-[10px]">Qty: {item.quantity}</div>
                      </div>
                    </div>
                    <span className="font-mono-nums text-[#FDE047] font-bold">
                      ${item.product.price * item.quantity}
                    </span>
                  </div>
                ))}
              </div>

              {/* Tribute Breakdown */}
              <div className="pt-3 border-t border-[#2d1b46] space-y-1.5 text-xs font-whimsical text-purple-200">
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span className="font-mono-nums">${cartSubtotal}</span>
                </div>
                {cartDiscount > 0 && (
                  <div className="flex justify-between text-emerald-400">
                    <span>Coven Runic Discount:</span>
                    <span className="font-mono-nums">-${cartDiscount}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Astral Dispatch:</span>
                  <span className="font-mono-nums">
                    {cartShipping === 0 ? 'Complimentary' : `$${cartShipping}`}
                  </span>
                </div>
                <div className="flex justify-between font-witch text-xl text-white pt-2 border-t border-[#2d1b46]">
                  <span>Total Tribute:</span>
                  <span className="text-[#FDE047]">${cartTotal}</span>
                </div>
              </div>

              {/* Sealed Dispatch CTA */}
              <button
                onClick={handleDispatchOrder}
                className="w-full py-3.5 px-6 rounded-xl font-whimsical text-xs uppercase tracking-wider text-black font-bold bg-[#D4AF37] hover:bg-[#FDE047] transition-all flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(212,175,55,0.35)]"
              >
                <span>Seal & Summon Delivery</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
