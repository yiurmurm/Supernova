import React from 'react';
import { useSuper } from '../context/SuperContext';
import { CATEGORIES_DATA } from '../data/products';
import { CategoryId } from '../types';
import { Sparkles, Sun, Moon } from 'lucide-react';

export const Footer: React.FC = () => {
  const {
    navigateTo,
    isVillainMode,
    toggleVillainMode,
  } = useSuper();

  return (
    <footer className="w-full bg-[#08050e] border-t border-[#2d1b46] text-purple-300/70 py-12 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      <div className="max-w-7xl mx-auto space-y-10 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8">
          {/* Col 1: Brand (lg:col-span-4) */}
          <div className="lg:col-span-4 space-y-3">
            <div className="flex items-center gap-2">
              <span className="text-[#FDE047] text-xl font-bold animate-twinkle">✦</span>
              <span className="font-witch text-2xl text-white tracking-wider">
                SUPRANOVA
              </span>
            </div>

            <p className="font-whimsical text-xs text-purple-200/80 leading-relaxed max-w-sm">
              The grand apothecary for supernatural metamorphosis. Bottled elixirs, celestial talismans, reality lenses, and awakened familiars crafted for modern adepts.
            </p>

            <button
              onClick={toggleVillainMode}
              className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-[#D4AF37]/40 text-xs font-whimsical uppercase text-[#FDE047] hover:border-[#FDE047] transition-all bg-[#170e24]"
            >
              {isVillainMode ? (
                <>
                  <Moon className="w-3.5 h-3.5 text-[#C084FC]" />
                  <span>Villan Mode (Nightfall)</span>
                </>
              ) : (
                <>
                  <Sun className="w-3.5 h-3.5 text-[#FDE047]" />
                  <span>Hero Mode (Daybreak)</span>
                </>
              )}
            </button>
          </div>

          {/* Col 2: Grimoires (lg:col-span-4) */}
          <div className="lg:col-span-4 space-y-3 font-whimsical text-xs">
            <span className="uppercase text-[#FDE047] font-semibold block tracking-wider">
              Sacred Grimoires
            </span>
            <ul className="space-y-2">
              {CATEGORIES_DATA.map((cat) => (
                <li key={cat.id}>
                  <button
                    onClick={() => navigateTo('category', { categoryId: cat.id as CategoryId })}
                    className="hover:text-[#FDE047] transition-colors flex items-center gap-2"
                  >
                    <span className="text-[#D4AF37]">✧</span>
                    <span>{cat.name}</span>
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 3: Sanctum Sanctuary (lg:col-span-4) */}
          <div className="lg:col-span-4 space-y-3 font-whimsical text-xs">
            <span className="uppercase text-[#FDE047] font-semibold block tracking-wider">
              Sanctum Navigation
            </span>
            <ul className="space-y-2">
              <li>
                <button onClick={() => navigateTo('quiz')} className="hover:text-[#FDE047]">
                  Oracle Power Quiz
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('account')} className="hover:text-[#FDE047]">
                  Adept Dossier & Wishlist
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('shop')} className="hover:text-[#FDE047]">
                  All 32 Powers
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('help')} className="hover:text-[#FDE047]">
                  Coven Protocols & FAQ
                </button>
              </li>
            </ul>

            {/* Celestial Moon Phase Card in Footer */}
            <div className="pt-2">
              <div className="flex items-center gap-3 p-2.5 rounded-xl bg-[#170e24] border border-[#D4AF37]/30">
                <div className="w-9 h-9 rounded-lg overflow-hidden shrink-0 border border-[#D4AF37]/40">
                  <img
                    src="/src/assets/images/celestial_moon_stars_1790162488603.jpg"
                    alt="Moon Phase"
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div>
                  <div className="text-[10px] uppercase text-[#FDE047] font-semibold">Lunar Attunement</div>
                  <div className="text-white text-[11px]">Waxing Gibbous • 96%</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="pt-6 border-t border-[#2d1b46]/60 flex flex-col sm:flex-row items-center justify-between gap-4 font-whimsical text-xs text-purple-300/50">
          <div>
            © {new Date().getFullYear()} SUPRANOVA Grand Apothecary. All powers runically bound.
          </div>
          <div className="flex items-center gap-4">
            <span className="text-[#FDE047] flex items-center gap-1">
              <Sparkles className="w-3 h-3" /> Hand-crafted Metamorphic Magic
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};
