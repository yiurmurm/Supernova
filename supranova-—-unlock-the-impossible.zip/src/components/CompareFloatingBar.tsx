import React from 'react';
import { useSuper } from '../context/SuperContext';
import { PRODUCTS } from '../data/products';
import { Sparkles, X, ChevronUp, Layers } from 'lucide-react';

export const CompareFloatingBar: React.FC = () => {
  const {
    comparedProductIds,
    removeFromCompare,
    clearCompare,
    setIsCompareOpen,
    isCompareOpen,
    isVillainMode,
  } = useSuper();

  if (comparedProductIds.length === 0 || isCompareOpen) return null;

  const comparedProducts = comparedProductIds
    .map((id) => PRODUCTS.find((p) => p.id === id))
    .filter(Boolean);

  return (
    <div className="fixed bottom-6 left-1/2 transform -translate-x-1/2 z-40 animate-in slide-in-from-bottom-6 duration-300">
      <div
        className={`flex items-center gap-3 px-4 py-2.5 rounded-2xl border shadow-2xl backdrop-blur-md transition-all ${
          isVillainMode
            ? 'bg-[#150924]/95 border-[#D4AF37]/50 text-white shadow-[0_8px_32px_rgba(0,0,0,0.8)]'
            : 'bg-[#FFFFFF]/95 border-[#D4AF37]/60 text-[#1F1432] shadow-[0_8px_32px_rgba(0,0,0,0.18)]'
        }`}
      >
        <div className="flex items-center gap-2 pr-2 border-r border-[#D4AF37]/30">
          <div className="w-8 h-8 rounded-xl bg-[#D4AF37]/20 border border-[#D4AF37] flex items-center justify-center text-[#D4AF37]">
            <Layers className="w-4 h-4" />
          </div>
          <div className="hidden sm:block">
            <div className="text-[10px] font-whimsical uppercase tracking-wider text-[#D4AF37] font-bold">
              Web Map Compare
            </div>
            <div className="text-xs font-witch font-bold">
              {comparedProducts.length} / 4 Arcana
            </div>
          </div>
        </div>

        {/* Thumbnail Previews */}
        <div className="flex items-center gap-2">
          {comparedProducts.map((p) => (
            <div key={p!.id} className="relative group">
              <div className="w-9 h-9 rounded-xl overflow-hidden border border-[#D4AF37]/40 shadow-sm">
                <img
                  src={p!.image}
                  alt={p!.name}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <button
                onClick={() => removeFromCompare(p!.id)}
                title="Remove from map"
                className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-black text-white flex items-center justify-center text-[10px] opacity-0 group-hover:opacity-100 transition-opacity border border-white/40"
              >
                ×
              </button>
            </div>
          ))}
        </div>

        {/* Open Button */}
        <button
          onClick={() => setIsCompareOpen(true)}
          className="ml-1 px-4 py-2 rounded-xl bg-[#D4AF37] hover:bg-[#FDE047] text-black font-whimsical text-xs font-bold uppercase tracking-wider transition-all hover:scale-105 shadow-[0_0_12px_rgba(212,175,55,0.3)] flex items-center gap-1.5"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Launch Web Map</span>
        </button>

        {/* Clear */}
        <button
          onClick={clearCompare}
          title="Clear compare"
          className="p-1.5 rounded-lg opacity-60 hover:opacity-100 hover:text-rose-400 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
