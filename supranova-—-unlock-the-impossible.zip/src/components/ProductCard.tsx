import React, { useState } from 'react';
import { Product } from '../types';
import { useSuper } from '../context/SuperContext';
import { Heart, ShoppingBag, Eye, Star, Sparkles, Layers } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  onQuickView?: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onQuickView }) => {
  const {
    navigateTo,
    addToCart,
    toggleWishlist,
    isInWishlist,
    triggerSoundFx,
    isVillainMode,
    toggleCompare,
    isInCompare,
  } = useSuper();

  const [isHovered, setIsHovered] = useState(false);
  const isWish = isInWishlist(product.id);
  const isComp = isInCompare(product.id);

  const getRarityBadge = (rarity: string) => {
    switch (rarity) {
      case 'God-Tier':
        return { bg: '#F59E0B', text: '#000', label: '✦ Arcane Masterpiece' };
      case 'Cosmic':
        return { bg: '#A855F7', text: '#FFF', label: '✧ Starlit Cosmic' };
      case 'Mythic':
        return { bg: '#D4AF37', text: '#000', label: '✦ Coven Mythic' };
      case 'Legendary':
        return { bg: '#C084FC', text: '#000', label: '✧ Eldritch High' };
      case 'Epic':
        return { bg: '#7E22CE', text: '#FFF', label: '✦ Enchanted' };
      default:
        return { bg: '#4C1D95', text: '#FFF', label: '✦ Adept Grade' };
    }
  };

  const badge = getRarityBadge(product.rarity);

  const handleCardClick = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('button')) return;
    triggerSoundFx('✧ Relic Inspected');
    navigateTo('product', { productId: product.id });
  };

  return (
    <div
      onClick={handleCardClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="group relative cursor-pointer rounded-2xl bg-[#170e24] border border-[#D4AF37]/30 hover:border-[#FDE047] arcane-card overflow-hidden flex flex-col justify-between transition-all duration-300 hover:-translate-y-1.5 select-none"
    >
      <div>
        {/* Relic Image Stage */}
        <div className="relative aspect-[4/3] w-full overflow-hidden bg-[#0d0814] border-b border-[#2d1b46]/70">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700"
            referrerPolicy="no-referrer"
          />

          {/* Grimoire Foil Sheen Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#170e24] via-transparent to-black/20 opacity-80" />

          {/* Rarity Watermark */}
          <div className="absolute top-3 left-3 flex items-center gap-1.5">
            <span
              className="px-2 py-0.5 rounded-full text-[10px] font-whimsical uppercase font-bold tracking-wider shadow-[0_2px_6px_rgba(0,0,0,0.6)]"
              style={{ backgroundColor: badge.bg, color: badge.text }}
            >
              {product.rarity}
            </span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-mono-nums text-[#FDE047] bg-[#0d0814]/80 backdrop-blur-sm border border-[#D4AF37]/30">
              {product.powerGrade}
            </span>
          </div>

          {/* Top Actions: Compare & Wishlist */}
          <div className="absolute top-3 right-3 flex items-center gap-1.5 z-10">
            {/* Compare in Web Map Button */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                toggleCompare(product.id);
              }}
              title={isComp ? 'Remove from Web Map' : 'Add to Web Map Compare'}
              className={`p-2 rounded-full border transition-all shadow-[0_2px_8px_rgba(0,0,0,0.6)] ${
                isComp
                  ? 'bg-[#D4AF37] text-black border-[#FDE047] shadow-[0_0_10px_rgba(212,175,55,0.4)]'
                  : 'bg-[#0d0814]/80 hover:bg-[#1e1330] border-[#D4AF37]/40 text-purple-200'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
            </button>

            {/* Wishlist Button */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                toggleWishlist(product.id);
              }}
              title={isWish ? 'Remove from Wishlist' : 'Add to Wishlist'}
              className="p-2 rounded-full bg-[#0d0814]/80 hover:bg-[#1e1330] border border-[#D4AF37]/40 text-purple-100 transition-colors shadow-[0_2px_8px_rgba(0,0,0,0.6)]"
            >
              <Heart
                className={`w-3.5 h-3.5 ${isWish ? 'fill-[#D4AF37] text-[#D4AF37]' : 'text-purple-200'}`}
              />
            </button>
          </div>

          {/* Quick Inspect Hover Button */}
          <div
            className={`absolute inset-0 bg-black/50 backdrop-blur-[2px] flex items-center justify-center gap-3 transition-opacity duration-200 ${
              isHovered ? 'opacity-100' : 'opacity-0 pointer-events-none'
            }`}
          >
            <button
              onClick={(e) => {
                e.stopPropagation();
                if (onQuickView) onQuickView(product);
                else navigateTo('product', { productId: product.id });
              }}
              className="px-3.5 py-1.5 rounded-xl bg-[#1e1330] text-[#FDE047] font-whimsical text-xs uppercase tracking-wider font-bold border border-[#D4AF37] hover:bg-[#D4AF37] hover:text-black transition-all flex items-center gap-1.5 shadow-[0_4px_16px_rgba(0,0,0,0.7)]"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Scry Details</span>
            </button>
          </div>

          {/* Energy Tier Ribbon */}
          <div
            className={`absolute bottom-0 inset-x-0 bg-[#0d0814]/90 px-3 py-1 border-t border-[#2d1b46] transition-transform duration-200 flex items-center justify-between text-[10px] font-whimsical ${
              isHovered ? 'translate-y-0' : 'translate-y-full'
            }`}
          >
            <span className="text-[#FDE047] font-bold flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-[#FDE047]" /> Potency: {product.powerLevel}
            </span>
            <span className="text-purple-300 font-mono-nums">Attunement Active</span>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-4 space-y-2">
          <div className="flex items-center justify-between text-xs text-purple-300/70 font-whimsical">
            <span className="capitalize">{product.category}</span>
            <span className="text-[#D4AF37]">✦</span>
            <span className="truncate">{product.archetype}</span>
            <div className="flex items-center gap-1 text-[#FDE047]">
              <Star className="w-3 h-3 fill-current" />
              <span className="font-bold font-mono-nums">{product.rating}</span>
            </div>
          </div>

          {/* Relic Title */}
          <h3 className="font-witch text-base sm:text-lg text-white group-hover:text-[#FDE047] transition-colors line-clamp-1">
            {product.name}
          </h3>

          {/* Poetic description */}
          <p className="font-whimsical text-xs text-purple-200/75 line-clamp-2 leading-relaxed">
            {product.shortDesc}
          </p>
        </div>
      </div>

      {/* Card Footer: Price & Attune Button */}
      <div className="p-4 pt-1 flex items-center justify-between gap-3 border-t border-[#2d1b46]/50">
        <div>
          <div className="font-witch text-xl text-[#FDE047]">
            ${product.price}
          </div>
          {product.originalPrice && (
            <div className="text-[11px] font-mono-nums text-purple-300/50 line-through">
              ${product.originalPrice}
            </div>
          )}
        </div>

        <button
          onClick={(e) => {
            e.stopPropagation();
            addToCart(product, 1);
          }}
          className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl font-whimsical text-xs uppercase tracking-wider text-black font-bold bg-[#D4AF37] hover:bg-[#FDE047] transition-all hover:scale-105 shadow-[0_0_12px_rgba(212,175,55,0.25)]"
        >
          <ShoppingBag className="w-3.5 h-3.5" />
          <span>Attune Relic</span>
        </button>
      </div>
    </div>
  );
};
