import React, { useState } from 'react';
import { useSuper } from '../context/SuperContext';
import { X, Sparkles, Mail, Lock, User, ArrowRight } from 'lucide-react';

export const LoginModal: React.FC = () => {
  const {
    isLoginModalOpen,
    setIsLoginModalOpen,
    loginUser,
    triggerSoundFx,
  } = useSuper();

  const [mode, setMode] = useState<'login' | 'signup' | 'forgot'>('login');
  const [email, setEmail] = useState('bathijarajeshp@gmail.com');
  const [password, setPassword] = useState('••••••••••••');
  const [alias, setAlias] = useState('Apex Vanguard');
  const [forgotSent, setForgotSent] = useState(false);

  if (!isLoginModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (mode === 'forgot') {
      setForgotSent(true);
      triggerSoundFx('✧ Reset Sent');
      return;
    }
    loginUser(email, alias);
  };

  const handleGoogleOneTap = () => {
    loginUser('bathijarajeshp@gmail.com', 'Rajesh P. Bathija (Adept)');
    triggerSoundFx('✦ Astral Bound');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div
        className="fixed inset-0 bg-black/85 backdrop-blur-md"
        onClick={() => setIsLoginModalOpen(false)}
      />

      <div className="relative w-full max-w-md bg-[#170e24] border border-[#D4AF37]/50 rounded-3xl p-6 sm:p-8 arcane-card z-10 space-y-5 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-[#FDE047] text-lg font-bold">✦</span>
            <span className="font-witch text-xl text-white tracking-wide">
              {mode === 'login'
                ? 'Enter the Sanctum'
                : mode === 'signup'
                ? 'Initiate Adept File'
                : 'Recover Ward'}
            </span>
          </div>
          <button
            onClick={() => setIsLoginModalOpen(false)}
            className="p-1 text-purple-300 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Google Fast Sign-In */}
        {mode !== 'forgot' && (
          <div className="space-y-2 font-whimsical">
            <button
              onClick={handleGoogleOneTap}
              className="w-full py-2.5 px-4 rounded-xl text-xs uppercase tracking-wider text-black font-bold bg-[#D4AF37] hover:bg-[#FDE047] transition-all flex items-center justify-center gap-2 shadow-[0_0_12px_rgba(212,175,55,0.25)]"
            >
              <Sparkles className="w-4 h-4" />
              <span>One-Tap Enter (bathijarajeshp@gmail.com)</span>
            </button>

            <div className="flex items-center gap-2 my-3 text-[11px] text-purple-300/50 uppercase text-center justify-center">
              <span>— or inscribe credentials —</span>
            </div>
          </div>
        )}

        {forgotSent ? (
          <div className="p-4 rounded-xl bg-[#0d0814] border border-[#D4AF37] text-center space-y-2 font-whimsical text-xs">
            <p className="text-white font-bold">Lunar recovery link whispered to {email}.</p>
            <button
              onClick={() => {
                setForgotSent(false);
                setMode('login');
              }}
              className="text-[#FDE047] underline"
            >
              Return to Sign In
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-3 font-whimsical text-xs">
            {mode === 'signup' && (
              <div>
                <label className="block text-purple-300/70 mb-1">Adept Chosen Alias</label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={alias}
                    onChange={(e) => setAlias(e.target.value)}
                    className="w-full bg-[#0d0814] border border-[#2d1b46] rounded-xl px-3 py-2 pl-9 text-white focus:outline-none focus:border-[#D4AF37]"
                  />
                  <User className="w-4 h-4 text-purple-400 absolute left-3 top-2.5" />
                </div>
              </div>
            )}

            <div>
              <label className="block text-purple-300/70 mb-1">Coven Correspondence</label>
              <div className="relative">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-[#0d0814] border border-[#2d1b46] rounded-xl px-3 py-2 pl-9 text-white focus:outline-none focus:border-[#D4AF37]"
                />
                <Mail className="w-4 h-4 text-purple-400 absolute left-3 top-2.5" />
              </div>
            </div>

            {mode !== 'forgot' && (
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-purple-300/70">Secret Ward Password</label>
                  {mode === 'login' && (
                    <button
                      type="button"
                      onClick={() => setMode('forgot')}
                      className="text-[11px] text-[#FDE047] hover:underline"
                    >
                      Forgot Cipher?
                    </button>
                  )}
                </div>
                <div className="relative">
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-[#0d0814] border border-[#2d1b46] rounded-xl px-3 py-2 pl-9 text-white focus:outline-none focus:border-[#D4AF37]"
                  />
                  <Lock className="w-4 h-4 text-purple-400 absolute left-3 top-2.5" />
                </div>
              </div>
            )}

            <button
              type="submit"
              className="w-full py-3 px-4 rounded-xl font-whimsical text-xs uppercase tracking-wider text-black font-bold bg-[#D4AF37] hover:bg-[#FDE047] transition-all flex items-center justify-center gap-2 shadow-[0_0_16px_rgba(212,175,55,0.3)]"
            >
              <span>{mode === 'login' ? 'Enter Sanctuary' : mode === 'signup' ? 'Awaken Dossier' : 'Send Reset'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        )}

        {/* Mode Toggle Footer */}
        <div className="pt-2 text-center text-xs font-whimsical text-purple-300/70">
          {mode === 'login' ? (
            <div>
              New adept?{' '}
              <button
                onClick={() => setMode('signup')}
                className="text-[#FDE047] font-semibold hover:underline"
              >
                Inscribe your name here
              </button>
            </div>
          ) : (
            <div>
              Already initiated?{' '}
              <button
                onClick={() => setMode('login')}
                className="text-[#FDE047] font-semibold hover:underline"
              >
                Sign into sanctum
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
