import React, { useState } from 'react';
import { useSuper } from '../context/SuperContext';
import { Star, ShieldCheck, Sparkles, MessageSquarePlus, X } from 'lucide-react';

export const ReviewsSection: React.FC = () => {
  const { reviews, addCustomerReview, triggerSoundFx } = useSuper();
  const [filterRating, setFilterRating] = useState<number | 'all'>('all');
  const [isModalOpen, setIsModalOpen] = useState(false);

  // New Review Form State
  const [author, setAuthor] = useState('');
  const [productName, setProductName] = useState('Voltaris 250kV Elixir');
  const [title, setTitle] = useState('');
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!author.trim() || !comment.trim() || !title.trim()) return;
    addCustomerReview(productName, author, title, rating, comment);
    setIsModalOpen(false);
    setAuthor('');
    setTitle('');
    setComment('');
    triggerSoundFx('✦ Testament Inscribed');
  };

  const filtered = reviews.filter((r) => {
    if (filterRating === 'all') return true;
    return r.rating === filterRating;
  });

  return (
    <section className="relative w-full py-16 bg-[#0d0814] dark:bg-[#050308] border-b border-[#2d1b46]/70 transition-colors duration-400">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-xs font-whimsical uppercase text-[#FDE047] font-semibold tracking-wider">
              <Sparkles className="w-3.5 h-3.5 animate-twinkle" /> Whispers from Awakened Adepts Under Full Moons
            </div>
            <h2 className="font-witch text-3xl sm:text-4xl text-white tracking-wide">
              Testaments of the Coven
            </h2>
            <div className="flex items-center gap-3 text-xs font-whimsical text-purple-200/80">
              <div className="flex text-[#FDE047]">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-3.5 h-3.5 fill-current" />
                ))}
              </div>
              <span className="font-bold text-[#FDE047] font-mono-nums">4.9 / 5.0</span>
              <span className="text-[#D4AF37]">✦</span>
              <span>Over 2,800+ authenticated rituals</span>
            </div>
          </div>

          <button
            onClick={() => {
              setIsModalOpen(true);
              triggerSoundFx('✧ Inscribe Testament');
            }}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl font-whimsical text-xs uppercase tracking-wider text-black font-bold bg-[#D4AF37] hover:bg-[#FDE047] shadow-[0_0_16px_rgba(212,175,55,0.3)] transition-all hover:-translate-y-0.5"
          >
            <MessageSquarePlus className="w-4 h-4" />
            <span>Inscribe Testament</span>
          </button>
        </div>

        {/* Featured Moonlit Ritual Spotlight Card */}
        <div className="relative rounded-3xl overflow-hidden bg-[#170e24] border border-[#D4AF37]/40 p-6 sm:p-8 arcane-card">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
            <div className="md:col-span-4 relative aspect-square sm:aspect-video md:aspect-square rounded-2xl overflow-hidden border border-[#D4AF37]/50 shadow-lg">
              <img
                src="/src/assets/images/crescent_moon_relic_1790162503365.jpg"
                alt="Golden Crescent Moon Talisman"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute top-2 left-2 px-2.5 py-0.5 rounded-full bg-[#0d0814]/85 text-[10px] font-whimsical uppercase text-[#FDE047] border border-[#D4AF37]/40">
                ✦ High Solstice Relic
              </div>
            </div>

            <div className="md:col-span-8 space-y-3">
              <div className="inline-flex items-center gap-2 text-xs font-whimsical text-[#FDE047]">
                <span>🌙</span>
                <span className="uppercase tracking-wider font-semibold">Verified Adept Field Inscription</span>
              </div>
              <h3 className="font-witch text-xl sm:text-2xl text-white">
                "Activated beneath the eclipse. The starlight veil parted instantly."
              </h3>
              <p className="font-whimsical text-purple-200/90 text-sm leading-relaxed">
                “I was skeptical of non-verbal spellcasting until the Golden Crescent and Voltaris arrived. During the full lunar apex, my kinetic shielding manifested effortlessly with zero mental strain. The craftsmanship is divine.”
              </p>
              <div className="flex items-center gap-3 pt-2 text-xs font-whimsical text-purple-300">
                <span className="text-[#FDE047] font-bold">— Arch-Mage Valeria Thorne</span>
                <span>•</span>
                <span>Third Sanctum Order</span>
                <span>•</span>
                <span className="text-emerald-400">✦ Verified Lunar Attunement</span>
              </div>
            </div>
          </div>
        </div>

        {/* Rating Filter Tabs */}
        <div className="flex items-center gap-2 pb-2 border-b border-[#2d1b46]">
          <button
            onClick={() => setFilterRating('all')}
            className={`px-3 py-1.5 text-xs font-whimsical uppercase rounded-lg border transition-all ${
              filterRating === 'all'
                ? 'bg-[#D4AF37] text-black font-bold border-[#FDE047]'
                : 'bg-[#170e24] text-purple-300 border-[#2d1b46]'
            }`}
          >
            All Testaments ({reviews.length})
          </button>
          {[5, 4].map((star) => (
            <button
              key={star}
              onClick={() => setFilterRating(star)}
              className={`px-3 py-1.5 text-xs font-whimsical uppercase rounded-lg border transition-all ${
                filterRating === star
                  ? 'bg-[#D4AF37] text-black font-bold border-[#FDE047]'
                  : 'bg-[#170e24] text-purple-300 border-[#2d1b46]'
              }`}
            >
              {star} Stars
            </button>
          ))}
        </div>

        {/* Reviews Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((rev) => (
            <div
              key={rev.id}
              className="p-6 rounded-2xl bg-[#170e24] border border-[#D4AF37]/30 arcane-card space-y-3 flex flex-col justify-between"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex text-[#FDE047]">
                    {[...Array(rev.rating)].map((_, i) => (
                      <Star key={i} className="w-3.5 h-3.5 fill-current" />
                    ))}
                  </div>
                  <span className="text-[10px] font-whimsical text-purple-300/60">{rev.date}</span>
                </div>

                <h4 className="font-witch text-base text-white">{rev.title}</h4>
                <p className="font-whimsical text-xs text-purple-200/80 leading-relaxed">
                  "{rev.comment}"
                </p>
              </div>

              <div className="pt-3 border-t border-[#2d1b46] flex items-center justify-between font-whimsical text-xs">
                <div>
                  <div className="font-bold text-white">{rev.author}</div>
                  <div className="text-[10px] text-[#FDE047]">{rev.productName}</div>
                </div>
                {rev.badge && (
                  <span className="flex items-center gap-1 text-[10px] text-emerald-400">
                    <ShieldCheck className="w-3.5 h-3.5" /> {rev.badge}
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Inscribe Modal */}
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div className="fixed inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setIsModalOpen(false)} />
            <div className="relative w-full max-w-lg bg-[#170e24] border border-[#D4AF37]/50 rounded-3xl p-6 sm:p-8 arcane-card z-10 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-witch text-xl text-white">Inscribe Your Testament</h3>
                <button onClick={() => setIsModalOpen(false)} className="text-purple-300 hover:text-white">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSubmitReview} className="space-y-3 font-whimsical text-xs">
                <div>
                  <label className="block text-purple-300/70 mb-1">Adept Name / Alias</label>
                  <input
                    type="text"
                    required
                    value={author}
                    onChange={(e) => setAuthor(e.target.value)}
                    placeholder="e.g. Althea Blackwood"
                    className="w-full bg-[#0d0814] border border-[#2d1b46] rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>

                <div>
                  <label className="block text-purple-300/70 mb-1">Attuned Relic</label>
                  <input
                    type="text"
                    required
                    value={productName}
                    onChange={(e) => setProductName(e.target.value)}
                    className="w-full bg-[#0d0814] border border-[#2d1b46] rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>

                <div>
                  <label className="block text-purple-300/70 mb-1">Title</label>
                  <input
                    type="text"
                    required
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. Pure elemental transformation"
                    className="w-full bg-[#0d0814] border border-[#2d1b46] rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>

                <div>
                  <label className="block text-purple-300/70 mb-1">Testament</label>
                  <textarea
                    required
                    rows={3}
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    placeholder="Share how this power manifested for you..."
                    className="w-full bg-[#0d0814] border border-[#2d1b46] rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>

                <div className="pt-2 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="px-4 py-2 rounded-xl text-purple-300 hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl bg-[#D4AF37] text-black font-bold hover:bg-[#FDE047]"
                  >
                    Seal Testament
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
