import React, { useState } from 'react';
import { useSuper } from '../context/SuperContext';
import { ArrowRight, Sparkles, Moon, Sun, Wand2, Compass } from 'lucide-react';

const HERO_CELESTIAL_IMAGES = [
  {
    id: 'moon-stars',
    title: 'Celestial Full Moon & Nebula',
    subtitle: 'Under Midnight Solstice Alignment',
    src: '/src/assets/images/celestial_moon_stars_1790162488603.jpg',
    badge: '✦ 100% Lunar Radiance',
  },
  {
    id: 'moon-apothecary',
    title: 'Moonlit Apothecary Chamber',
    subtitle: 'Bottled Starlight & Suspended Moons',
    src: '/src/assets/images/moon_star_apothecary_1790162531057.jpg',
    badge: '✧ Living Starlight Elixirs',
  },
  {
    id: 'crescent-relic',
    title: 'Golden Crescent Talisman',
    subtitle: 'Hand-Forged Filigree & Star Crystals',
    src: '/src/assets/images/crescent_moon_relic_1790162503365.jpg',
    badge: '✦ Sacred Lunar Ward',
  },
  {
    id: 'star-chart',
    title: 'Ancient Zodiac Star Chart',
    subtitle: 'Constellations of the Adepts',
    src: '/src/assets/images/star_chart_nebula_1790162515204.jpg',
    badge: '✧ Astral Navigation',
  },
];

export const HeroSection: React.FC = () => {
  const {
    navigateTo,
    isVillainMode,
    toggleVillainMode,
    triggerSoundFx,
    setSearchQuery,
  } = useSuper();

  const [selectedImageIdx, setSelectedImageIdx] = useState(0);
  const [selectedElement, setSelectedElement] = useState<'Celestial' | 'Alchemical' | 'Shadow'>('Celestial');

  const currentHeroImg = HERO_CELESTIAL_IMAGES[selectedImageIdx];

  return (
    <section className="relative w-full overflow-hidden bg-[#0d0814] dark:bg-[#050308] pt-8 pb-16 border-b border-[#2d1b46]/70 transition-colors duration-400">
      {/* Background Starry Constellations & Ambient Arcane Glow */}
      <div
        className="pointer-events-none absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[500px] rounded-full blur-[150px] transition-all duration-700"
        style={{
          background: isVillainMode
            ? 'radial-gradient(circle, rgba(147,51,234,0.25) 0%, rgba(245,158,11,0.14) 50%, transparent 80%)'
            : 'radial-gradient(circle, rgba(212,175,55,0.24) 0%, rgba(168,85,247,0.18) 50%, transparent 80%)',
        }}
      />

      {/* Subtle Star Dust Overlay */}
      <div className="pointer-events-none absolute inset-0 bg-celestial-stars opacity-45" />

      {/* Decorative Twinkling Mini-Stars Floating in Ambient Space */}
      <div className="pointer-events-none absolute top-8 left-8 text-[#FDE047] text-xl animate-twinkle select-none">✦</div>
      <div className="pointer-events-none absolute top-28 right-12 text-[#C084FC] text-base animate-twinkle-slow select-none">✧</div>
      <div className="pointer-events-none absolute bottom-16 left-1/5 text-[#D4AF37] text-sm animate-twinkle select-none">★</div>
      <div className="pointer-events-none absolute top-1/2 right-1/4 text-[#FEF08A] text-sm animate-twinkle-slow select-none">✦</div>
      <div className="pointer-events-none absolute top-20 right-1/3 text-[#FDE047] text-xs animate-twinkle select-none">🌙</div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Arcane Mode Indicator Bar */}
        <div className="flex flex-wrap items-center justify-between gap-4 pb-5 border-b border-[#2d1b46]/60">
          <div className="flex items-center gap-3">
            <span className="w-2.5 h-2.5 rounded-full bg-[#D4AF37] animate-pulse" />
            <span className="font-whimsical text-xs tracking-widest uppercase text-purple-200/90 flex items-center gap-1.5">
              <span>✦ The Grand Coven Apothecary</span>
              <span className="text-purple-400/60 hidden sm:inline">•</span>
              <span className="text-[#FDE047] hidden sm:inline font-mono-nums">Waxing Moon Cycle • 96% Starlight Potency</span>
            </span>
          </div>

          {/* Quick Hero / Villan Switch */}
          <button
            onClick={toggleVillainMode}
            className="flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-whimsical tracking-wide uppercase border border-[#D4AF37]/50 bg-[#170e24] hover:border-[#FDE047] text-[#FDE047] transition-all shadow-[0_0_12px_rgba(212,175,55,0.2)]"
          >
            {isVillainMode ? (
              <>
                <Moon className="w-3.5 h-3.5 text-[#C084FC]" />
                <span>Villan Mode (Nightfall)</span>
              </>
            ) : (
              <>
                <Sun className="w-3.5 h-3.5 text-[#FDE047]" />
                <span>Hero Mode (Daybreak)</span>
              </>
            )}
          </button>
        </div>

        {/* Hero Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center pt-8 pb-10">
          {/* Left Column: Headlines & Call to Action (lg:col-span-6) */}
          <div className="lg:col-span-6 space-y-6">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#170e24] border border-[#D4AF37]/40 text-xs font-whimsical text-[#FDE047]">
              <Sparkles className="w-3.5 h-3.5 animate-twinkle" />
              <span className="tracking-wider uppercase font-semibold">Hand-Brewed Metamorphic Arcana</span>
            </div>

            <h1 className="font-witch text-4xl sm:text-5xl xl:text-6xl text-white tracking-wide leading-[1.15] [text-wrap:balance]">
              Woven from the{' '}
              <span className="text-[#FDE047] drop-shadow-[0_0_22px_rgba(253,224,71,0.5)]">
                MOON & STARS
              </span>
              , Awakened for You.
            </h1>

            <p className="font-whimsical text-lg sm:text-xl text-purple-200/90 leading-relaxed max-w-xl">
              Authentic celestial talismans, bottled starlight elixirs, and dimension-folding rings forged under lunar eclipses. Step into the impossible.
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                onClick={() => {
                  navigateTo('shop');
                  triggerSoundFx('✦ Grimoire Unlocked');
                }}
                className="group flex items-center gap-2 px-6 py-3.5 rounded-xl font-whimsical text-base uppercase tracking-wider text-black font-bold bg-gradient-to-r from-[#D4AF37] to-[#FDE047] shadow-[0_0_20px_rgba(212,175,55,0.35)] hover:shadow-[0_0_28px_rgba(253,224,71,0.5)] transition-all hover:-translate-y-0.5"
              >
                <span>Explore Sacred Powers</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                onClick={() => navigateTo('quiz')}
                className="flex items-center gap-2 px-5 py-3.5 rounded-xl font-whimsical text-base uppercase tracking-wider text-purple-100 bg-[#1e1330] border border-[#D4AF37]/50 hover:border-[#FDE047] hover:text-[#FDE047] transition-all hover:-translate-y-0.5"
              >
                <Wand2 className="w-4 h-4 text-[#FDE047]" />
                <span>Oracle Power Quiz</span>
              </button>
            </div>

            {/* Micro Stats with Moon & Star Accents */}
            <div className="grid grid-cols-3 gap-6 pt-4 border-t border-[#2d1b46]/70 text-left">
              <div>
                <div className="font-witch text-2xl text-[#FDE047] flex items-center gap-1">
                  <span>32+</span>
                  <span className="text-xs">✧</span>
                </div>
                <div className="font-whimsical text-xs text-purple-300/70">Woven Arcana</div>
              </div>
              <div>
                <div className="font-witch text-2xl text-purple-300 flex items-center gap-1">
                  <span>Instant</span>
                  <span className="text-xs">🌙</span>
                </div>
                <div className="font-whimsical text-xs text-purple-300/70">Astral Dispatch</div>
              </div>
              <div>
                <div className="font-witch text-2xl text-[#D4AF37] flex items-center gap-1">
                  <span>100%</span>
                  <span className="text-xs">✦</span>
                </div>
                <div className="font-whimsical text-xs text-purple-300/70">Pure Celestial Magic</div>
              </div>
            </div>
          </div>

          {/* Right Column: Visual Moon & Star Showcase with Interactive Gallery Switcher */}
          <div className="lg:col-span-6 relative">
            <div className="relative mx-auto max-w-lg rounded-3xl border border-[#D4AF37]/50 overflow-hidden arcane-card bg-[#170e24] shadow-[0_8px_32px_rgba(0,0,0,0.7)]">
              {/* Main Visual Frame */}
              <div className="relative aspect-[4/3] w-full overflow-hidden bg-black/60">
                <img
                  key={currentHeroImg.id}
                  src={currentHeroImg.src}
                  alt={currentHeroImg.title}
                  className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-700 animate-in fade-in duration-300"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#170e24] via-transparent to-black/30 opacity-90" />

                {/* Top Badge: Celestial Status */}
                <div className="absolute top-4 left-4 px-3 py-1 rounded-full bg-[#0d0814]/90 backdrop-blur-md border border-[#D4AF37]/60 shadow-[0_4px_16px_rgba(0,0,0,0.6)] flex items-center gap-2">
                  <span className="text-[#FDE047] text-xs animate-twinkle">✦</span>
                  <span className="text-xs font-whimsical text-[#FDE047] font-semibold uppercase tracking-wider">
                    {currentHeroImg.badge}
                  </span>
                </div>

                {/* Floating Talisman 1: Voltaris Elixir */}
                <div className="absolute bottom-16 left-4 p-2.5 rounded-xl bg-[#0d0814]/90 backdrop-blur-md border border-[#D4AF37]/50 shadow-[0_4px_16px_rgba(0,0,0,0.7)] flex items-center gap-2.5 animate-float">
                  <div className="w-8 h-8 rounded-lg bg-[#D4AF37]/20 border border-[#D4AF37] flex items-center justify-center text-[#FDE047] text-xs font-bold">
                    ⚡
                  </div>
                  <div>
                    <div className="text-xs font-whimsical font-bold text-white">Voltaris 250kV</div>
                    <div className="text-[10px] font-mono-nums text-[#D4AF37]">Celestial Current</div>
                  </div>
                </div>

                {/* Floating Talisman 2: Crescent Moon Badge */}
                <div className="absolute top-4 right-4 p-2.5 rounded-xl bg-[#0d0814]/90 backdrop-blur-md border border-[#A855F7]/50 shadow-[0_4px_16px_rgba(0,0,0,0.7)] flex items-center gap-2 animate-float-delayed">
                  <div className="w-8 h-8 rounded-lg bg-[#A855F7]/25 border border-[#A855F7] flex items-center justify-center text-[#FDE047] text-sm">
                    🌙
                  </div>
                  <div>
                    <div className="text-xs font-whimsical font-bold text-white">Lunar Matrix</div>
                    <div className="text-[10px] font-mono-nums text-purple-300">Phase 4 Active</div>
                  </div>
                </div>

                {/* Floating Talisman 3: Portal Ring */}
                <div className="absolute bottom-4 right-4 p-2 rounded-xl bg-[#0d0814]/90 backdrop-blur-md border border-[#D4AF37]/50 shadow-[0_4px_16px_rgba(0,0,0,0.7)] flex items-center gap-2">
                  <span className="text-[#FDE047] text-sm">✧</span>
                  <span className="text-xs font-whimsical text-white font-bold">Gate Attuned</span>
                </div>
              </div>

              {/* Bottom Card Bar: Interactive Moon & Star Picture Thumbnails */}
              <div className="p-4 bg-[#170e24] border-t border-[#2d1b46] space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-[10px] font-whimsical tracking-wider text-purple-300/70 uppercase">
                      Active Celestial Vision
                    </div>
                    <div className="text-sm font-witch text-white">
                      {currentHeroImg.title}
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      navigateTo('shop');
                      triggerSoundFx('✨ Sanctum Opened');
                    }}
                    className="px-3.5 py-1.5 rounded-lg font-whimsical text-xs uppercase tracking-wider text-black font-bold bg-[#D4AF37] hover:bg-[#FDE047] transition-all"
                  >
                    View Relic →
                  </button>
                </div>

                {/* 4 Clickable Moon & Star Picture Thumbnails */}
                <div className="grid grid-cols-4 gap-2 pt-1">
                  {HERO_CELESTIAL_IMAGES.map((img, idx) => (
                    <button
                      key={img.id}
                      onClick={() => {
                        setSelectedImageIdx(idx);
                        triggerSoundFx('✧ Moon Attuned');
                      }}
                      className={`relative aspect-video rounded-lg overflow-hidden border transition-all ${
                        selectedImageIdx === idx
                          ? 'border-[#FDE047] ring-2 ring-[#FDE047]/50 scale-105 shadow-[0_0_10px_rgba(253,224,71,0.4)]'
                          : 'border-[#2d1b46] opacity-60 hover:opacity-100 hover:border-[#D4AF37]'
                      }`}
                    >
                      <img
                        src={img.src}
                        alt={img.title}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Interactive Element Alignment Banner */}
        <div className="mt-4 p-4 sm:p-5 rounded-2xl bg-[#170e24] border border-[#D4AF37]/30 arcane-card">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-xs font-whimsical uppercase text-[#FDE047] font-semibold">
                <Sparkles className="w-3.5 h-3.5" /> Lunar & Elemental Alignment
              </div>
              <h3 className="font-witch text-base sm:text-lg text-white mt-0.5">
                Tune your aura to filter powers
              </h3>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {(['Celestial', 'Alchemical', 'Shadow'] as const).map((elem) => (
                <button
                  key={elem}
                  onClick={() => {
                    setSelectedElement(elem);
                    setSearchQuery(elem);
                    navigateTo('shop');
                    triggerSoundFx(`✧ ${elem} Filter`);
                  }}
                  className={`px-3.5 py-1.5 text-xs font-whimsical uppercase rounded-lg border transition-all ${
                    selectedElement === elem
                      ? 'bg-[#D4AF37] text-black font-bold border-[#FDE047] shadow-[0_0_10px_rgba(212,175,55,0.3)]'
                      : 'bg-[#1e1330] text-purple-200 border-[#2d1b46] hover:border-[#D4AF37]/60'
                  }`}
                >
                  {elem === 'Celestial' ? '✦ ' : elem === 'Shadow' ? '🌙 ' : '⚡ '}
                  {elem}
                </button>
              ))}

              <button
                onClick={() => navigateTo('quiz')}
                className="px-3.5 py-1.5 text-xs font-whimsical uppercase tracking-wider rounded-lg bg-[#9333EA] text-white border border-[#A855F7] hover:bg-[#7E22CE] transition-all shadow-[0_0_12px_rgba(147,51,234,0.3)]"
              >
                Diagnostic Quiz →
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
