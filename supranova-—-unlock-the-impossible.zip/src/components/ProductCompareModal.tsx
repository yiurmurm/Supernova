import React, { useState } from 'react';
import { useSuper } from '../context/SuperContext';
import { PRODUCTS } from '../data/products';
import { Product } from '../types';
import {
  X,
  Sparkles,
  ShoppingBag,
  Trash2,
  Plus,
  Zap,
  Shield,
  Eye,
  Brain,
  Wind,
  Check,
  RotateCcw,
} from 'lucide-react';

const STAT_CONFIG = [
  { key: 'power' as const, label: 'Power', icon: Zap, angle: -Math.PI / 2 },
  { key: 'speed' as const, label: 'Speed', icon: Wind, angle: -Math.PI / 2 + (2 * Math.PI) / 5 },
  { key: 'durability' as const, label: 'Durability', icon: Shield, angle: -Math.PI / 2 + (4 * Math.PI) / 5 },
  { key: 'stealth' as const, label: 'Stealth', icon: Eye, angle: -Math.PI / 2 + (6 * Math.PI) / 5 },
  { key: 'intelligence' as const, label: 'Arcana', icon: Brain, angle: -Math.PI / 2 + (8 * Math.PI) / 5 },
];

const PALETTE = [
  { stroke: '#D4AF37', fill: 'rgba(212, 175, 55, 0.28)', dot: '#FDE047', name: 'Gold' },
  { stroke: '#C084FC', fill: 'rgba(192, 132, 252, 0.25)', dot: '#E879F9', name: 'Amethyst' },
  { stroke: '#38BDF8', fill: 'rgba(56, 189, 248, 0.25)', dot: '#7DD3FC', name: 'Cyan' },
  { stroke: '#F43F5E', fill: 'rgba(244, 63, 94, 0.25)', dot: '#FB7185', name: 'Crimson' },
];

export const ProductCompareModal: React.FC = () => {
  const {
    comparedProductIds,
    removeFromCompare,
    addToCompare,
    clearCompare,
    isCompareOpen,
    setIsCompareOpen,
    addToCart,
    navigateTo,
    triggerSoundFx,
    isVillainMode,
  } = useSuper();

  const [activeTab, setActiveTab] = useState<'map' | 'table'>('map');
  const [hoveredPoint, setHoveredPoint] = useState<{
    text: string;
    x: number;
    y: number;
  } | null>(null);
  const [isAddPickerOpen, setIsAddPickerOpen] = useState(false);
  const [pickerSearch, setPickerSearch] = useState('');

  if (!isCompareOpen) return null;

  const comparedProducts: Product[] = comparedProductIds
    .map((id) => PRODUCTS.find((p) => p.id === id))
    .filter((p): p is Product => Boolean(p));

  // Radar chart sizing
  const size = 380;
  const center = size / 2;
  const radius = 130;

  // Compute polygon points for a product
  const getPolygonPoints = (product: Product) => {
    return STAT_CONFIG.map((stat) => {
      const val = product.stats[stat.key] || 50;
      const r = (val / 100) * radius;
      const x = center + r * Math.cos(stat.angle);
      const y = center + r * Math.sin(stat.angle);
      return { x, y, val, statLabel: stat.label };
    });
  };

  const handleProductSelect = (id: string) => {
    addToCompare(id);
    setIsAddPickerOpen(false);
    setPickerSearch('');
  };

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center p-2 sm:p-4 md:p-6 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className={`relative w-full max-w-5xl max-h-[92vh] flex flex-col rounded-3xl border shadow-2xl overflow-hidden transition-colors ${
          isVillainMode
            ? 'bg-[#0F071B] border-[#D4AF37]/40 text-[#F3E8FF]'
            : 'bg-[#FFFDF9] border-[#D4AF37]/50 text-[#1F1432]'
        }`}
      >
        {/* Header */}
        <div
          className={`flex items-center justify-between p-4 sm:p-6 border-b transition-colors ${
            isVillainMode ? 'border-[#2d1b46] bg-[#150924]' : 'border-[#E6DEC8] bg-[#F7F3E9]'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#D4AF37]/20 border border-[#D4AF37] flex items-center justify-center text-[#FDE047]">
              <Sparkles className="w-5 h-5 text-[#D4AF37]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-witch text-xl sm:text-2xl font-bold tracking-wide">
                  Astral Resonance Web Map
                </h2>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-whimsical uppercase bg-[#D4AF37]/20 text-[#D4AF37] font-bold border border-[#D4AF37]/40">
                  {comparedProducts.length} of 4 Relics
                </span>
              </div>
              <p className="text-xs font-whimsical opacity-75">
                Geometric spectral comparison of power output, speed, and metaphysical durability.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* View switcher */}
            <div
              className={`flex items-center p-1 rounded-xl border text-xs font-whimsical ${
                isVillainMode ? 'bg-[#07040B] border-[#2d1b46]' : 'bg-[#EFE8DA] border-[#D8CEB8]'
              }`}
            >
              <button
                onClick={() => setActiveTab('map')}
                className={`px-3 py-1 rounded-lg transition-all font-semibold ${
                  activeTab === 'map'
                    ? 'bg-[#D4AF37] text-black shadow-sm'
                    : 'opacity-70 hover:opacity-100'
                }`}
              >
                Web Radar Map
              </button>
              <button
                onClick={() => setActiveTab('table')}
                className={`px-3 py-1 rounded-lg transition-all font-semibold ${
                  activeTab === 'table'
                    ? 'bg-[#D4AF37] text-black shadow-sm'
                    : 'opacity-70 hover:opacity-100'
                }`}
              >
                Side-by-Side Matrix
              </button>
            </div>

            {comparedProducts.length > 0 && (
              <button
                onClick={clearCompare}
                className="p-2 rounded-xl text-xs font-whimsical opacity-70 hover:opacity-100 hover:text-rose-400 transition-colors"
                title="Clear All"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            )}

            <button
              onClick={() => setIsCompareOpen(false)}
              className="p-2 rounded-xl border border-transparent hover:border-[#D4AF37]/50 hover:bg-[#D4AF37]/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {comparedProducts.length === 0 ? (
            <div className="text-center py-16 space-y-4">
              <div className="w-16 h-16 rounded-full bg-[#D4AF37]/10 border border-[#D4AF37]/30 flex items-center justify-center mx-auto text-[#D4AF37]">
                <Sparkles className="w-8 h-8" />
              </div>
              <h3 className="font-witch text-xl">No Relics Selected for Web Map</h3>
              <p className="font-whimsical text-sm max-w-sm mx-auto opacity-75">
                Select up to 4 magical relics from the Grimoire to map their attributes side-by-side.
              </p>
              <button
                onClick={() => {
                  addToCompare('potion-voltaris');
                  addToCompare('potion-aetherwing');
                }}
                className="px-5 py-2 rounded-xl bg-[#D4AF37] text-black font-whimsical text-xs font-bold uppercase tracking-wider hover:bg-[#FDE047] transition-all"
              >
                Load Sample Comparison
              </button>
            </div>
          ) : activeTab === 'map' ? (
            /* Radar Web Map View */
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
              {/* Spider / Radar Web Map SVG */}
              <div className="lg:col-span-7 flex flex-col items-center justify-center relative p-4 rounded-3xl border border-[#D4AF37]/30 bg-black/10">
                <div className="relative">
                  <svg
                    width={size}
                    height={size}
                    viewBox={`0 0 ${size} ${size}`}
                    className="overflow-visible select-none max-w-full h-auto drop-shadow-xl"
                  >
                    {/* Concentric Web Polygons (20%, 40%, 60%, 80%, 100%) */}
                    {[0.2, 0.4, 0.6, 0.8, 1.0].map((level, i) => {
                      const r = radius * level;
                      const points = STAT_CONFIG.map((stat) => {
                        const x = center + r * Math.cos(stat.angle);
                        const y = center + r * Math.sin(stat.angle);
                        return `${x},${y}`;
                      }).join(' ');

                      return (
                        <polygon
                          key={i}
                          points={points}
                          fill="none"
                          stroke={isVillainMode ? 'rgba(212, 175, 55, 0.18)' : 'rgba(180, 130, 20, 0.22)'}
                          strokeWidth={level === 1.0 ? 1.8 : 1}
                          strokeDasharray={level === 1.0 ? 'none' : '3 3'}
                        />
                      );
                    })}

                    {/* Radial Axis Lines */}
                    {STAT_CONFIG.map((stat, i) => {
                      const x2 = center + radius * Math.cos(stat.angle);
                      const y2 = center + radius * Math.sin(stat.angle);
                      return (
                        <line
                          key={i}
                          x1={center}
                          y1={center}
                          x2={x2}
                          y2={y2}
                          stroke={isVillainMode ? 'rgba(212, 175, 55, 0.25)' : 'rgba(180, 130, 20, 0.3)'}
                          strokeWidth={1.2}
                        />
                      );
                    })}

                    {/* Center Beacon */}
                    <circle cx={center} cy={center} r={4} fill="#D4AF37" />

                    {/* Product Overlaid Polygons */}
                    {comparedProducts.map((product, idx) => {
                      const points = getPolygonPoints(product);
                      const pointsString = points.map((p) => `${p.x},${p.y}`).join(' ');
                      const style = PALETTE[idx % PALETTE.length];

                      return (
                        <g key={product.id} className="transition-all duration-500">
                          {/* Polygon Body */}
                          <polygon
                            points={pointsString}
                            fill={style.fill}
                            stroke={style.stroke}
                            strokeWidth={2.4}
                            strokeLinejoin="round"
                            className="transition-all hover:opacity-100"
                          />

                          {/* Vertices */}
                          {points.map((pt, pIdx) => (
                            <circle
                              key={pIdx}
                              cx={pt.x}
                              cy={pt.y}
                              r={4.5}
                              fill={style.dot}
                              stroke={isVillainMode ? '#07040B' : '#FFFFFF'}
                              strokeWidth={1.5}
                              className="cursor-pointer transition-transform hover:scale-150"
                              onMouseEnter={() =>
                                setHoveredPoint({
                                  text: `${product.name}: ${pt.statLabel} ${pt.val}%`,
                                  x: pt.x,
                                  y: pt.y - 12,
                                Yang: 0,
                                } as any)
                              }
                              onMouseLeave={() => setHoveredPoint(null)}
                            />
                          ))}
                        </g>
                      );
                    })}

                    {/* Axis Labels */}
                    {STAT_CONFIG.map((stat, i) => {
                      const labelRadius = radius + 26;
                      const lx = center + labelRadius * Math.cos(stat.angle);
                      const ly = center + labelRadius * Math.sin(stat.angle);
                      return (
                        <text
                          key={i}
                          x={lx}
                          y={ly}
                          textAnchor="middle"
                          dominantBaseline="central"
                          fill={isVillainMode ? '#FDE047' : '#B48214'}
                          className="text-[11px] font-whimsical uppercase font-bold tracking-wider"
                        >
                          {stat.label}
                        </text>
                      );
                    })}
                  </svg>

                  {/* Hover Tooltip */}
                  {hoveredPoint && (
                    <div
                      className="absolute z-20 pointer-events-none px-2.5 py-1 rounded-lg text-xs font-whimsical bg-[#07040B] border border-[#D4AF37] text-[#FDE047] shadow-lg transform -translate-x-1/2 -translate-y-full"
                      style={{ left: `${hoveredPoint.x}px`, top: `${hoveredPoint.y}px` }}
                    >
                      {hoveredPoint.text}
                    </div>
                  )}
                </div>

                <div className="text-[11px] font-whimsical opacity-70 mt-2 text-center">
                  ✦ Hover over any vertex anchor to reveal resonance values.
                </div>
              </div>

              {/* Product Cards Legend & Controls (lg:col-span-5) */}
              <div className="lg:col-span-5 space-y-3">
                <div className="flex items-center justify-between text-xs font-whimsical opacity-75">
                  <span>Mapped Relics</span>
                  <span>Max 4 Arcana</span>
                </div>

                {comparedProducts.map((product, idx) => {
                  const style = PALETTE[idx % PALETTE.length];
                  return (
                    <div
                      key={product.id}
                      className={`p-3 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
                        isVillainMode ? 'bg-[#150924] border-[#2d1b46]' : 'bg-[#FFFFFF] border-[#E8DFC8]'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div
                          className="w-4 h-4 rounded-full shrink-0 border"
                          style={{ backgroundColor: style.stroke, borderColor: style.dot }}
                        />
                        <div className="w-10 h-10 rounded-xl overflow-hidden shrink-0 border border-[#D4AF37]/30">
                          <img
                            src={product.image}
                            alt={product.name}
                            className="w-full h-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                        </div>
                        <div className="min-w-0">
                          <div className="font-witch text-xs truncate">{product.name}</div>
                          <div className="text-[11px] font-mono-nums text-[#D4AF37] font-bold">
                            ${product.price} · {product.powerGrade}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          onClick={() => addToCart(product, 1)}
                          className="p-2 rounded-xl bg-[#D4AF37] text-black font-bold hover:bg-[#FDE047] transition-all"
                          title="Attune Relic"
                        >
                          <ShoppingBag className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => removeFromCompare(product.id)}
                          className="p-2 rounded-xl opacity-60 hover:opacity-100 hover:text-rose-400 transition-colors"
                          title="Remove from Map"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}

                {/* Add Product Slot */}
                {comparedProducts.length < 4 && (
                  <div className="relative pt-2">
                    {isAddPickerOpen ? (
                      <div
                        className={`p-3 rounded-2xl border space-y-2 ${
                          isVillainMode ? 'bg-[#150924] border-[#D4AF37]/50' : 'bg-[#FFFFFF] border-[#D4AF37]/50'
                        }`}
                      >
                        <div className="flex items-center justify-between text-xs font-whimsical">
                          <span className="font-bold">Select Relic to Map</span>
                          <button
                            onClick={() => setIsAddPickerOpen(false)}
                            className="text-xs opacity-60 hover:opacity-100"
                          >
                            Cancel
                          </button>
                        </div>
                        <input
                          type="text"
                          placeholder="Filter arcana..."
                          value={pickerSearch}
                          onChange={(e) => setPickerSearch(e.target.value)}
                          className="w-full px-2.5 py-1.5 rounded-xl text-xs bg-black/20 border border-[#D4AF37]/30 focus:outline-none focus:border-[#D4AF37]"
                        />
                        <div className="max-h-48 overflow-y-auto space-y-1 pr-1">
                          {PRODUCTS.filter(
                            (p) =>
                              !comparedProductIds.includes(p.id) &&
                              p.name.toLowerCase().includes(pickerSearch.toLowerCase())
                          ).map((p) => (
                            <button
                              key={p.id}
                              onClick={() => handleProductSelect(p.id)}
                              className="w-full text-left p-2 rounded-xl text-xs flex items-center justify-between hover:bg-[#D4AF37]/20 transition-colors"
                            >
                              <span className="truncate">{p.name}</span>
                              <span className="text-[#D4AF37] font-mono-nums shrink-0">${p.price}</span>
                            </button>
                          ))}
                        </div>
                      </div>
                    ) : (
                      <button
                        onClick={() => setIsAddPickerOpen(true)}
                        className={`w-full py-3 px-4 rounded-2xl border border-dashed flex items-center justify-center gap-2 font-whimsical text-xs uppercase tracking-wider transition-all ${
                          isVillainMode
                            ? 'border-[#D4AF37]/40 text-[#D4AF37] hover:bg-[#D4AF37]/10'
                            : 'border-[#B48214]/50 text-[#B48214] hover:bg-[#B48214]/10'
                        }`}
                      >
                        <Plus className="w-4 h-4" />
                        <span>Add Another Relic to Web Map</span>
                      </button>
                    )}
                  </div>
                )}
              </div>
            </div>
          ) : (
            /* Side-by-Side Matrix View */
            <div className="overflow-x-auto pb-4">
              <div className="min-w-[650px] grid grid-cols-5 gap-3 text-xs font-whimsical">
                {/* Metric Labels Column */}
                <div className="space-y-4 pt-44 font-semibold opacity-75">
                  <div className="h-9 flex items-center">Tribute Price</div>
                  <div className="h-8 flex items-center">Power Grade</div>
                  <div className="h-8 flex items-center">Potency Level</div>
                  <div className="h-8 flex items-center">Archetype</div>
                  <div className="h-8 flex items-center">Magic Type</div>
                  <div className="h-8 flex items-center">Duration</div>
                  <div className="h-8 flex items-center">Speed</div>
                  <div className="h-8 flex items-center">Durability</div>
                  <div className="h-8 flex items-center">Stealth</div>
                  <div className="h-8 flex items-center">Arcana Intellect</div>
                  <div className="h-10 flex items-center">Attune Action</div>
                </div>

                {/* Compared Products Columns */}
                {comparedProducts.map((p, idx) => {
                  const style = PALETTE[idx % PALETTE.length];
                  return (
                    <div
                      key={p.id}
                      className={`p-4 rounded-2xl border space-y-4 ${
                        isVillainMode ? 'bg-[#150924] border-[#2d1b46]' : 'bg-[#FFFFFF] border-[#E8DFC8]'
                      }`}
                    >
                      {/* Product Header */}
                      <div className="h-40 space-y-2 text-center flex flex-col items-center justify-between">
                        <div className="relative w-16 h-16 rounded-2xl overflow-hidden border border-[#D4AF37]/40 shadow-md">
                          <img
                            src={p.image}
                            alt={p.name}
                            className="w-full h-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                        </div>
                        <div className="font-witch text-sm line-clamp-2">{p.name}</div>
                        <button
                          onClick={() => removeFromCompare(p.id)}
                          className="text-[11px] text-rose-400 hover:underline flex items-center gap-1"
                        >
                          <Trash2 className="w-3 h-3" /> Remove
                        </button>
                      </div>

                      {/* Row values */}
                      <div className="h-9 flex items-center justify-center font-witch text-base text-[#D4AF37]">
                        ${p.price}
                      </div>
                      <div className="h-8 flex items-center justify-center">
                        <span className="px-2 py-0.5 rounded-full text-[10px] bg-[#D4AF37]/20 border border-[#D4AF37]/40 text-[#D4AF37] font-bold">
                          {p.powerGrade}
                        </span>
                      </div>
                      <div className="h-8 flex items-center justify-center font-mono-nums font-bold text-[#D4AF37]">
                        {p.powerLevel}
                      </div>
                      <div className="h-8 flex items-center justify-center opacity-85">{p.archetype}</div>
                      <div className="h-8 flex items-center justify-center text-center opacity-85 truncate">
                        {p.magicType}
                      </div>
                      <div className="h-8 flex items-center justify-center opacity-85">{p.duration}</div>

                      {/* Stat Bars */}
                      <div className="h-8 flex items-center justify-center w-full">
                        <div className="w-full bg-black/20 rounded-full h-2 overflow-hidden border border-[#D4AF37]/20">
                          <div
                            className="h-full rounded-full transition-all duration-500"
                            style={{ width: `${p.stats.speed}%`, backgroundColor: style.stroke }}
                          />
                        </div>
                      </div>
                      <div className="h-8 flex items-center justify-center w-full">
                        <div className="w-full bg-black/20 rounded-full h-2 overflow-hidden border border-[#D4AF37]/20">
                          <div
                            className="h-full rounded-full transition-all duration-500"
                            style={{ width: `${p.stats.durability}%`, backgroundColor: style.stroke }}
                          />
                        </div>
                      </div>
                      <div className="h-8 flex items-center justify-center w-full">
                        <div className="w-full bg-black/20 rounded-full h-2 overflow-hidden border border-[#D4AF37]/20">
                          <div
                            className="h-full rounded-full transition-all duration-500"
                            style={{ width: `${p.stats.stealth}%`, backgroundColor: style.stroke }}
                          />
                        </div>
                      </div>
                      <div className="h-8 flex items-center justify-center w-full">
                        <div className="w-full bg-black/20 rounded-full h-2 overflow-hidden border border-[#D4AF37]/20">
                          <div
                            className="h-full rounded-full transition-all duration-500"
                            style={{ width: `${p.stats.intelligence}%`, backgroundColor: style.stroke }}
                          />
                        </div>
                      </div>

                      {/* Action */}
                      <div className="h-10 flex items-center justify-center">
                        <button
                          onClick={() => addToCart(p, 1)}
                          className="w-full py-2 px-3 rounded-xl bg-[#D4AF37] hover:bg-[#FDE047] text-black font-bold uppercase tracking-wider text-[11px] transition-all flex items-center justify-center gap-1.5"
                        >
                          <ShoppingBag className="w-3.5 h-3.5" />
                          <span>Attune</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
