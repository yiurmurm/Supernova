import React, { useState, useEffect, useRef } from 'react';
import { useSuper } from '../context/SuperContext';
import {
  Compass,
  Wind,
  CloudMoon,
  Sparkles,
  MapPin,
  Crosshair,
  Play,
  RotateCcw,
  Shield,
  Feather,
} from 'lucide-react';

interface Waypoint {
  id: string;
  name: string;
  type: string;
  x: number;
  y: number;
  description: string;
}

const LANDMARKS: Waypoint[] = [
  {
    id: 'coven-spire',
    name: 'High Coven Spire',
    type: 'Origin Perch',
    x: 18,
    y: 76,
    description: 'Ancient obsidian tower where elixirs are warded and owls take flight.',
  },
  {
    id: 'leyline-gorge',
    name: 'Whispering Leyline Gorge',
    type: 'Thermal Updraft',
    x: 42,
    y: 52,
    description: 'Aetheric wind currents granting +18 knots to courier flight.',
  },
  {
    id: 'cloud-wyrm-ridge',
    name: 'Cloud Wyrm Ridge',
    type: 'Mountain Pass',
    x: 58,
    y: 30,
    description: 'High altitude mountain corridor bathed in perpetual moonlight.',
  },
  {
    id: 'aether-waystation',
    name: 'Starlight Waystation 7',
    type: 'Courier Perch',
    x: 74,
    y: 65,
    description: 'Rest station for long-range night messenger owls.',
  },
];

const OWLS = [
  {
    id: 'barn-owl',
    name: 'Solstice Barn Owl',
    wingSpan: '44 inches',
    speed: '82 knots',
    element: 'Golden Solar',
    color: '#D4AF37',
    featherColor: '#FAF5EE',
    desc: 'Bred under solstice light; exceptionally sharp night vision and silent wing-beats.',
  },
  {
    id: 'snowy-owl',
    name: 'Snowy Owl of the Void',
    wingSpan: '48 inches',
    speed: '94 knots',
    element: 'Frost Arcana',
    color: '#38BDF8',
    featherColor: '#F0F9FF',
    desc: 'Glides through gale-force winds and dimensional rifts without losing course.',
  },
  {
    id: 'horned-owl',
    name: 'Great Horned Astral Owl',
    wingSpan: '52 inches',
    speed: '88 knots',
    element: 'Midnight Shadow',
    color: '#C084FC',
    featherColor: '#3B0764',
    desc: 'Heavy cargo specialist capable of transporting whole chests of volatile potions.',
  },
];

interface InteractiveDeliveryMapProps {
  onCoordinateSelect?: (coords: { x: number; y: number; address: string }) => void;
  initialPin?: { x: number; y: number };
}

export const InteractiveDeliveryMap: React.FC<InteractiveDeliveryMapProps> = ({
  onCoordinateSelect,
  initialPin = { x: 78, y: 34 },
}) => {
  const { triggerSoundFx, isVillainMode } = useSuper();

  // Destination Beacon Pin
  const [sanctuaryPin, setSanctuaryPin] = useState(initialPin);
  const [activeOwlIdx, setActiveOwlIdx] = useState(0);
  const [weatherMode, setWeatherMode] = useState<'starlight' | 'gale' | 'fog'>('starlight');
  const [altitude, setAltitude] = useState(4200);

  // Flight simulation state
  const [isSimulatingFlight, setIsSimulatingFlight] = useState(false);
  const [flightProgress, setFlightProgress] = useState(0); // 0 to 1
  const [owlPos, setOwlPos] = useState({ x: 18, y: 76 });
  const [owlAngle, setOwlAngle] = useState(0);
  const [activeWaypoint, setActiveWaypoint] = useState<Waypoint | null>(null);
  const [deliveredBurst, setDeliveredBurst] = useState(false);

  const mapRef = useRef<HTMLDivElement>(null);
  const currentOwl = OWLS[activeOwlIdx];

  // Calculate Bezier flight position
  const getFlightPathPoint = (t: number) => {
    // P0: Coven Spire (18, 76)
    // P1: Leyline Gorge (42, 52)
    // P2: Cloud Ridge (58, 30)
    // P3: Sanctuary (sanctuaryPin.x, sanctuaryPin.y)
    const p0 = { x: 18, y: 76 };
    const p1 = { x: 42, y: 52 };
    const p2 = { x: 58, y: 30 };
    const p3 = sanctuaryPin;

    // Cubic Bezier
    const cx = 3 * (p1.x - p0.x);
    const bx = 3 * (p2.x - p1.x) - cx;
    const ax = p3.x - p0.x - cx - bx;

    const cy = 3 * (p1.y - p0.y);
    const by = 3 * (p2.y - p1.y) - cy;
    const ay = p3.y - p0.y - cy - by;

    const x = ax * Math.pow(t, 3) + bx * Math.pow(t, 2) + cx * t + p0.x;
    const y = ay * Math.pow(t, 3) + by * Math.pow(t, 2) + cy * t + p0.y;

    return { x, y };
  };

  // Handle Map Click to place destination
  const handleMapClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (isSimulatingFlight) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const rawX = ((e.clientX - rect.left) / rect.width) * 100;
    const rawY = ((e.clientY - rect.top) / rect.height) * 100;
    const x = Math.max(5, Math.min(95, Math.round(rawX)));
    const y = Math.max(5, Math.min(95, Math.round(rawY)));

    setSanctuaryPin({ x, y });
    triggerSoundFx('✦ Sanctuary Coordinates Set');

    if (onCoordinateSelect) {
      onCoordinateSelect({
        x,
        y,
        address: `Sanctuary Sector [${x}°E, ${y}°N], Mystic Realm`,
      });
    }
  };

  // Flight simulation loop
  useEffect(() => {
    if (!isSimulatingFlight) {
      // Default owl position follows t = 0.5 or 0
      const pt = getFlightPathPoint(0.45);
      setOwlPos(pt);
      return;
    }

    let start: number | null = null;
    const duration = 5000; // 5 seconds flight

    const step = (timestamp: number) => {
      if (!start) start = timestamp;
      const elapsed = timestamp - start;
      const t = Math.min(1, elapsed / duration);

      setFlightProgress(t);
      const cur = getFlightPathPoint(t);
      const ahead = getFlightPathPoint(Math.min(1, t + 0.05));
      const angle = Math.atan2(ahead.y - cur.y, ahead.x - cur.x) * (180 / Math.PI);

      setOwlPos(cur);
      setOwlAngle(angle);

      if (t < 1) {
        requestAnimationFrame(step);
      } else {
        setIsSimulatingFlight(false);
        setDeliveredBurst(true);
        triggerSoundFx('✦ OWL DELIVERY COMPLETE!');
        setTimeout(() => setDeliveredBurst(false), 3000);
      }
    };

    const animId = requestAnimationFrame(step);
    return () => cancelAnimationFrame(animId);
  }, [isSimulatingFlight, sanctuaryPin]);

  const startFlightSimulation = () => {
    setIsSimulatingFlight(true);
    setFlightProgress(0);
    setDeliveredBurst(false);
    triggerSoundFx('✧ Owl Dispatched on Flightpath');
  };

  const calculatedDistance = (
    Math.hypot(sanctuaryPin.x - 18, sanctuaryPin.y - 76) * 0.08
  ).toFixed(1);

  return (
    <div className="space-y-6">
      {/* Top Map Control Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-2xl border border-[#D4AF37]/30 bg-black/20 text-xs font-whimsical">
        {/* Owl Selector */}
        <div className="flex items-center gap-1.5">
          <span className="opacity-70 font-semibold">Courier Familiar:</span>
          <div className="flex items-center gap-1">
            {OWLS.map((owl, idx) => (
              <button
                key={owl.id}
                onClick={() => {
                  setActiveOwlIdx(idx);
                  triggerSoundFx(`✧ ${owl.name} Attuned`);
                }}
                className={`px-2.5 py-1 rounded-xl transition-all font-semibold flex items-center gap-1 ${
                  activeOwlIdx === idx
                    ? 'bg-[#D4AF37] text-black shadow-md'
                    : 'bg-black/30 opacity-70 hover:opacity-100'
                }`}
              >
                <span>🦉</span>
                <span className="hidden sm:inline">{owl.name.split(' ')[0]}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Weather Mode */}
        <div className="flex items-center gap-1.5">
          <span className="opacity-70 font-semibold">Leyline Weather:</span>
          <div className="flex items-center gap-1">
            {[
              { id: 'starlight', label: 'Clear Starlight', icon: Sparkles },
              { id: 'gale', label: 'Solar Gale (+15kts)', icon: Wind },
              { id: 'fog', label: 'Lunar Fog', icon: CloudMoon },
            ].map((w) => (
              <button
                key={w.id}
                onClick={() => setWeatherMode(w.id as any)}
                className={`px-2 py-1 rounded-xl transition-all flex items-center gap-1 ${
                  weatherMode === w.id
                    ? 'bg-[#D4AF37]/30 text-[#D4AF37] border border-[#D4AF37]'
                    : 'opacity-60 hover:opacity-100'
                }`}
              >
                <w.icon className="w-3 h-3" />
                <span className="hidden md:inline">{w.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Dispatch Action */}
        <button
          onClick={startFlightSimulation}
          disabled={isSimulatingFlight}
          className="px-3 py-1.5 rounded-xl bg-[#D4AF37] hover:bg-[#FDE047] text-black font-bold uppercase tracking-wider transition-all flex items-center gap-1.5 shadow-[0_0_12px_rgba(212,175,55,0.3)] disabled:opacity-50"
        >
          <Play className="w-3 h-3 fill-current" />
          <span>{isSimulatingFlight ? 'Owl in Flight...' : 'Dispatch Owl Flight'}</span>
        </button>
      </div>

      {/* Main Interactive Map Canvas */}
      <div
        ref={mapRef}
        onClick={handleMapClick}
        className="relative aspect-[16/9] sm:aspect-[21/9] w-full rounded-3xl overflow-hidden border-2 border-[#D4AF37]/50 shadow-2xl cursor-crosshair select-none bg-[#090510]"
      >
        {/* Celestial Starfield & Parchment Grid Backdrop */}
        <div className="absolute inset-0 bg-celestial-stars opacity-45 pointer-events-none" />

        {/* Subtle Leyline River Gradient */}
        <div
          className="absolute inset-0 pointer-events-none opacity-30"
          style={{
            background:
              'radial-gradient(ellipse at 50% 50%, rgba(168,85,247,0.35) 0%, rgba(212,175,55,0.15) 50%, transparent 80%)',
          }}
        />

        {/* Dynamic Flightpath SVG with Curved Arc */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none overflow-visible">
          <defs>
            <linearGradient id="flightGlow" x1="0%" y1="100%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#D4AF37" stopOpacity="0.8" />
              <stop offset="50%" stopColor="#C084FC" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#FDE047" stopOpacity="0.95" />
            </linearGradient>
            <filter id="glow">
              <feGaussianBlur stdDeviation="3" result="coloredBlur" />
              <feMerge>
                <feMergeNode in="coloredBlur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          {/* Curved Flightpath Arc */}
          <path
            d={`M 18% 76% C 42% 52%, 58% 30%, ${sanctuaryPin.x}% ${sanctuaryPin.y}%`}
            fill="none"
            stroke="url(#flightGlow)"
            strokeWidth="3"
            strokeDasharray="6 4"
            filter="url(#glow)"
            className="transition-all duration-300"
          />

          {/* Completed path glow if simulating */}
          {isSimulatingFlight && (
            <circle
              cx={`${owlPos.x}%`}
              cy={`${owlPos.y}%`}
              r="8"
              fill="rgba(253, 224, 71, 0.4)"
              className="animate-ping"
            />
          )}
        </svg>

        {/* Landmarks Waypoints */}
        {LANDMARKS.map((landmark) => (
          <div
            key={landmark.id}
            className="absolute transform -translate-x-1/2 -translate-y-1/2 z-10 cursor-pointer group"
            style={{ left: `${landmark.x}%`, top: `${landmark.y}%` }}
            onClick={(e) => {
              e.stopPropagation();
              setActiveWaypoint(landmark);
              triggerSoundFx(`✧ Landmark: ${landmark.name}`);
            }}
          >
            <div className="relative flex flex-col items-center">
              <div className="w-7 h-7 rounded-full bg-[#150924] border border-[#D4AF37] flex items-center justify-center text-xs shadow-[0_0_12px_rgba(212,175,55,0.4)] group-hover:scale-125 transition-transform">
                {landmark.id === 'coven-spire' ? '🏰' : landmark.id === 'leyline-gorge' ? '⚡' : '🏔️'}
              </div>
              <span className="mt-1 px-1.5 py-0.5 rounded-md bg-black/80 text-[10px] font-whimsical text-[#FDE047] border border-[#D4AF37]/30 whitespace-nowrap shadow-sm">
                {landmark.name}
              </span>
            </div>
          </div>
        ))}

        {/* Adept's Sanctuary Destination Beacon */}
        <div
          className="absolute transform -translate-x-1/2 -translate-y-1/2 z-20 pointer-events-none transition-all duration-300"
          style={{ left: `${sanctuaryPin.x}%`, top: `${sanctuaryPin.y}%` }}
        >
          <div className="relative flex flex-col items-center">
            {/* Pulsing Ripple Rings */}
            <span className="w-12 h-12 rounded-full border-2 border-[#FDE047] absolute -inset-2.5 animate-ping opacity-75" />
            <span className="w-8 h-8 rounded-full border border-[#D4AF37] absolute -inset-0.5 animate-pulse" />

            <div className="w-6 h-6 rounded-full bg-[#FDE047] border-2 border-black flex items-center justify-center text-black font-bold text-xs shadow-[0_0_20px_#FDE047]">
              ✦
            </div>

            <div className="mt-2 px-2 py-0.5 rounded-full bg-black/90 border border-[#FDE047] text-[10px] font-whimsical text-[#FDE047] font-bold whitespace-nowrap shadow-xl">
              Sanctuary Target
            </div>
          </div>
        </div>

        {/* ANIMATED DELIVERY OWL COURIER */}
        <div
          className="absolute transform -translate-x-1/2 -translate-y-1/2 z-30 pointer-events-none transition-transform duration-75"
          style={{
            left: `${owlPos.x}%`,
            top: `${owlPos.y}%`,
            transform: `translate(-50%, -50%) rotate(${owlAngle * 0.4}deg)`,
          }}
        >
          <div className="relative animate-owl-glide flex flex-col items-center">
            {/* Stardust Wake Trail behind owl */}
            <div className="absolute -bottom-3 flex gap-1 opacity-70">
              <span className="text-[10px] text-[#FDE047] animate-twinkle">✦</span>
              <span className="text-[8px] text-[#C084FC] animate-twinkle-slow">✧</span>
            </div>

            {/* Custom SVG Animated Owl with Flapping Wings */}
            <svg
              width="54"
              height="44"
              viewBox="0 0 60 48"
              className="drop-shadow-[0_4px_12px_rgba(0,0,0,0.8)]"
            >
              {/* Left Wing (Animated) */}
              <g className="animate-wing-left origin-[30px_20px]">
                <path
                  d="M 28 20 C 18 10, 4 14, 2 24 C 8 26, 18 24, 26 22 Z"
                  fill={currentOwl.featherColor}
                  stroke={currentOwl.color}
                  strokeWidth="1.8"
                />
                <path d="M 6 22 C 14 18, 22 20, 26 21" stroke={currentOwl.color} strokeWidth="1" />
              </g>

              {/* Right Wing (Animated) */}
              <g className="animate-wing-right origin-[32px_20px]">
                <path
                  d="M 32 20 C 42 10, 56 14, 58 24 C 52 26, 42 24, 34 22 Z"
                  fill={currentOwl.featherColor}
                  stroke={currentOwl.color}
                  strokeWidth="1.8"
                />
                <path d="M 54 22 C 46 18, 38 20, 34 21" stroke={currentOwl.color} strokeWidth="1" />
              </g>

              {/* Owl Body */}
              <ellipse
                cx="30"
                cy="26"
                rx="10"
                ry="14"
                fill={currentOwl.featherColor}
                stroke={currentOwl.color}
                strokeWidth="1.8"
              />

              {/* Feather Chest Markings */}
              <path
                d="M 26 24 Q 30 26 34 24 M 27 28 Q 30 30 33 28"
                stroke={currentOwl.color}
                strokeWidth="1.2"
                fill="none"
              />

              {/* Owl Head & Ears */}
              <circle cx="30" cy="14" r="8" fill={currentOwl.featherColor} stroke={currentOwl.color} strokeWidth="1.5" />
              {/* Ear Tufts */}
              <polygon points="24,8 26,12 22,12" fill={currentOwl.color} />
              <polygon points="36,8 38,12 34,12" fill={currentOwl.color} />

              {/* Glowing Eyes */}
              <circle cx="27" cy="14" r="2.5" fill="#FDE047" stroke="#000" strokeWidth="0.5" />
              <circle cx="33" cy="14" r="2.5" fill="#FDE047" stroke="#000" strokeWidth="0.5" />
              <circle cx="27" cy="14" r="1" fill="#000" />
              <circle cx="33" cy="14" r="1" fill="#000" />

              {/* Beak */}
              <polygon points="29,16 31,16 30,19" fill="#F59E0B" />

              {/* Enchanted Delivery Scroll in Claws */}
              <g transform="translate(23, 35)">
                <rect x="0" y="0" width="14" height="6" rx="2" fill="#D4AF37" stroke="#000" strokeWidth="0.8" />
                <line x1="7" y1="0" x2="7" y2="6" stroke="#92400E" strokeWidth="1" />
              </g>
            </svg>

            {/* Courier Label Tag */}
            <div className="px-2 py-0.5 rounded-full bg-[#150924]/90 border border-[#D4AF37] text-[9px] font-whimsical text-[#FDE047] whitespace-nowrap shadow-md mt-0.5">
              ✦ {currentOwl.name.split(' ')[0]} Familiar
            </div>
          </div>
        </div>

        {/* Arrival Celebration Particles */}
        {deliveredBurst && (
          <div
            className="absolute transform -translate-x-1/2 -translate-y-1/2 z-40 pointer-events-none"
            style={{ left: `${sanctuaryPin.x}%`, top: `${sanctuaryPin.y}%` }}
          >
            <div className="flex flex-col items-center animate-bounce">
              <span className="text-2xl">✨ 🎁 ✨</span>
              <div className="px-3 py-1 rounded-xl bg-[#FDE047] text-black font-witch text-xs font-bold shadow-2xl border border-black">
                Sanctuary Sealed & Delivered!
              </div>
            </div>
          </div>
        )}

        {/* Map Click Instructions Overlay */}
        <div className="absolute top-3 left-3 z-10 px-3 py-1.5 rounded-xl bg-black/75 backdrop-blur-sm border border-[#D4AF37]/30 text-[11px] font-whimsical text-[#FDE047]">
          <span>✦ Click map anywhere to route your delivery beacon</span>
        </div>

        {/* Live Distance Gauge */}
        <div className="absolute bottom-3 right-3 z-10 px-3 py-1.5 rounded-xl bg-black/85 backdrop-blur-sm border border-[#D4AF37]/40 text-[11px] font-whimsical text-white flex items-center gap-2">
          <Compass className="w-3.5 h-3.5 text-[#FDE047] animate-spin-slow" />
          <span>
            Vector: <strong className="text-[#FDE047]">{calculatedDistance} Celestial Leagues</strong>
          </span>
        </div>
      </div>

      {/* Flight Telemetry HUD & Details */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-whimsical">
        <div className="p-3 rounded-2xl border border-[#D4AF37]/30 bg-black/20 space-y-1">
          <div className="opacity-70 flex items-center gap-1">
            <Feather className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>Courier Wingspan</span>
          </div>
          <div className="font-witch text-sm text-[#FDE047]">{currentOwl.wingSpan}</div>
          <div className="text-[10px] opacity-60">Silent flight feathers</div>
        </div>

        <div className="p-3 rounded-2xl border border-[#D4AF37]/30 bg-black/20 space-y-1">
          <div className="opacity-70 flex items-center gap-1">
            <Wind className="w-3.5 h-3.5 text-cyan-400" />
            <span>Airspeed Cruise</span>
          </div>
          <div className="font-witch text-sm text-cyan-300">
            {weatherMode === 'gale' ? '102 knots (Gale Boost)' : currentOwl.speed}
          </div>
          <div className="text-[10px] opacity-60">Leyline assisted</div>
        </div>

        <div className="p-3 rounded-2xl border border-[#D4AF37]/30 bg-black/20 space-y-1">
          <div className="opacity-70 flex items-center gap-1">
            <Shield className="w-3.5 h-3.5 text-emerald-400" />
            <span>Sanctuary Ward</span>
          </div>
          <div className="font-witch text-sm text-emerald-300">Runically Sealed</div>
          <div className="text-[10px] opacity-60">Zero spatial leak</div>
        </div>

        <div className="p-3 rounded-2xl border border-[#D4AF37]/30 bg-black/20 space-y-1">
          <div className="opacity-70 flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            <span>Delivery Guarantee</span>
          </div>
          <div className="font-witch text-sm text-purple-300">Lunar Protected</div>
          <div className="text-[10px] opacity-60">30-day talisman guarantee</div>
        </div>
      </div>

      {/* Selected Landmark Info Modal if clicked */}
      {activeWaypoint && (
        <div className="p-4 rounded-2xl border border-[#D4AF37] bg-black/80 backdrop-blur-md flex items-center justify-between text-xs font-whimsical animate-in fade-in">
          <div>
            <span className="font-witch text-sm text-[#FDE047]">{activeWaypoint.name}</span>
            <p className="opacity-80 text-[11px] mt-0.5">{activeWaypoint.description}</p>
          </div>
          <button
            onClick={() => setActiveWaypoint(null)}
            className="px-3 py-1 rounded-xl bg-[#D4AF37] text-black font-bold uppercase text-[10px]"
          >
            Acknowledge
          </button>
        </div>
      )}
    </div>
  );
};
