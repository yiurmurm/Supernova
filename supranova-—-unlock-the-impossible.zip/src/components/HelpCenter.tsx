import React, { useState } from 'react';
import { useSuper } from '../context/SuperContext';
import {
  Sparkles,
  HelpCircle,
  ChevronDown,
  Package,
  RotateCcw,
  CheckCircle2,
  Send,
  Zap,
} from 'lucide-react';

const ISSUE_CATEGORIES = [
  { id: 'Track Order', icon: Package, label: 'Track Order', hint: 'Track astral couriers' },
  { id: 'Return Product', icon: RotateCcw, label: 'Return Relic', hint: '30-day lunar guarantee' },
  { id: 'Product Question', icon: HelpCircle, label: 'Dosage Inquiry', hint: 'Elixir potency & safety' },
  { id: 'Damaged Seal', icon: Sparkles, label: 'Broken Ward', hint: 'Damaged packaging' },
];

const FAQS = [
  {
    q: 'How long do elixir powers last after consumption?',
    a: 'Standard potions (like Voltaris) last 2 to 4 hours. Powers fade gently with zero cellular fatigue or disorientation.',
  },
  {
    q: 'Are awakened bio-familiars safe?',
    a: 'Yes. All bio-familiars are warded with pacification runes and bond exclusively to their keeper.',
  },
  {
    q: 'What is the 30-Day Lunar Guarantee?',
    a: 'If a power does not harmonize with your aura, return the talisman within 30 solar cycles for a full tribute refund.',
  },
  {
    q: 'Can I combine multiple powers safely?',
    a: 'Yes. Most celestial relics and elixirs resonate harmoniously, enhancing each other without metaphysical strain.',
  },
];

export const HelpCenter: React.FC = () => {
  const {
    submitSupportTicket,
    orders,
    triggerSoundFx,
  } = useSuper();

  const [selectedIssue, setSelectedIssue] = useState('Track Order');
  const [subject, setSubject] = useState('');
  const [orderId, setOrderId] = useState(orders[0]?.id || '');
  const [message, setMessage] = useState('');
  const [submittedTicketId, setSubmittedTicketId] = useState<string | null>(null);
  const [openFaqIdx, setOpenFaqIdx] = useState<number | null>(0);

  const handleTicketSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject.trim() || !message.trim()) return;

    const tck = submitSupportTicket(selectedIssue, subject, message, orderId);
    setSubmittedTicketId(tck.id);
    setSubject('');
    setMessage('');
    triggerSoundFx('✦ Inscription Dispatched');
  };

  return (
    <div className="min-h-screen bg-[#0d0814] dark:bg-[#050308] text-white py-10 px-4 sm:px-6 transition-colors duration-400">
      <div className="max-w-4xl mx-auto space-y-10">
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#170e24] border border-[#D4AF37]/40 text-xs font-whimsical uppercase text-[#FDE047]">
            <Sparkles className="w-3.5 h-3.5" /> High Coven Sanctuary Help
          </div>
          <h1 className="font-witch text-3xl sm:text-4xl text-white">
            Protocols & Guidance
          </h1>
          <p className="font-whimsical text-purple-200/80 text-sm max-w-md mx-auto">
            Guidance for courier tracking, elixir attunement, and ritual safety.
          </p>
        </div>

        {/* Quick Topic Badges */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {ISSUE_CATEGORIES.map((cat) => {
            const Icon = cat.icon;
            const isSelected = selectedIssue === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedIssue(cat.id)}
                className={`p-4 rounded-2xl border text-left font-whimsical transition-all ${
                  isSelected
                    ? 'bg-[#1e1330] border-[#FDE047] shadow-[0_0_12px_rgba(212,175,55,0.25)]'
                    : 'bg-[#170e24] border-[#2d1b46] hover:border-[#D4AF37]/50'
                }`}
              >
                <Icon className={`w-5 h-5 mb-2 ${isSelected ? 'text-[#FDE047]' : 'text-purple-300'}`} />
                <div className="font-bold text-white text-xs">{cat.label}</div>
                <div className="text-[11px] text-purple-300/60">{cat.hint}</div>
              </button>
            );
          })}
        </div>

        {/* FAQ Accordion */}
        <div className="p-6 rounded-3xl bg-[#170e24] border border-[#D4AF37]/30 arcane-card space-y-4">
          <h2 className="font-witch text-xl text-white">Frequently Asked Ritual Questions</h2>
          <div className="space-y-2">
            {FAQS.map((faq, idx) => {
              const isOpen = openFaqIdx === idx;
              return (
                <div
                  key={idx}
                  className="rounded-xl bg-[#0d0814] border border-[#2d1b46] overflow-hidden"
                >
                  <button
                    onClick={() => setOpenFaqIdx(isOpen ? null : idx)}
                    className="w-full p-3.5 text-left font-whimsical text-xs text-white font-semibold flex items-center justify-between"
                  >
                    <span>{faq.q}</span>
                    <ChevronDown className={`w-4 h-4 text-[#FDE047] transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                  </button>
                  {isOpen && (
                    <div className="px-3.5 pb-3.5 font-whimsical text-xs text-purple-200/80 leading-relaxed border-t border-[#2d1b46]/50 pt-2">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Contact High Coven */}
        <div className="p-6 sm:p-8 rounded-3xl bg-[#170e24] border border-[#D4AF37]/35 arcane-card space-y-5">
          <h2 className="font-witch text-xl text-white">Inscribe to the High Coven</h2>

          {submittedTicketId ? (
            <div className="p-4 rounded-xl bg-[#0d0814] border border-[#D4AF37] text-center space-y-2 font-whimsical">
              <CheckCircle2 className="w-8 h-8 text-[#FDE047] mx-auto" />
              <div className="text-white font-bold text-sm">Inscription Dispatched!</div>
              <p className="text-purple-300/80 text-xs">
                Reference ID: <span className="text-[#FDE047] font-mono-nums font-bold">{submittedTicketId}</span>. A Coven Adept will respond shortly.
              </p>
              <button
                onClick={() => setSubmittedTicketId(null)}
                className="text-xs text-[#FDE047] underline pt-1"
              >
                Inscribe another query
              </button>
            </div>
          ) : (
            <form onSubmit={handleTicketSubmit} className="space-y-3 font-whimsical text-xs">
              <div>
                <label className="block text-purple-300/70 mb-1">Subject</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Courier tracking inquiry"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="w-full bg-[#0d0814] border border-[#2d1b46] rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#D4AF37]"
                />
              </div>

              <div>
                <label className="block text-purple-300/70 mb-1">Message</label>
                <textarea
                  required
                  rows={3}
                  placeholder="Describe your inquiry..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="w-full bg-[#0d0814] border border-[#2d1b46] rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#D4AF37]"
                />
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-[#D4AF37] text-black font-bold hover:bg-[#FDE047] transition-all flex items-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Send Inscription</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
