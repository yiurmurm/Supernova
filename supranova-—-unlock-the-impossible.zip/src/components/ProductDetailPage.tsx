import React, { useState, useRef } from 'react';
import { Product } from '../types';
import { PRODUCTS } from '../data/products';
import { useSuper } from '../context/SuperContext';
import { ProductCard } from './ProductCard';
import {
  Heart,
  ShoppingBag,
  Sparkles,
  ShieldCheck,
  RotateCcw,
  Truck,
  ArrowLeft,
  Share2,
  Layers,
  Zap,
  Star,
  MessageSquarePlus,
  Send,
  Check,
} from 'lucide-react';

interface ProductDetailPageProps {
  productId?: string | null;
}

export const ProductDetailPage: React.FC<ProductDetailPageProps> = ({ productId }) => {
  const {
    navigateTo,
    addToCart,
    toggleWishlist,
    isInWishlist,
    triggerSoundFx,
    addToCompare,
    removeFromCompare,
    isInCompare,
    setIsCompareOpen,
    reviews,
    addCustomerReview,
    user,
    isVillainMode,
  } = useSuper();

  const product: Product =
    PRODUCTS.find((p) => p.id === productId) || PRODUCTS[0];

  const [quantity, setQuantity] = useState(1);
  const [selectedVariant, setSelectedVariant] = useState(product.variants?.[0] || 'Standard Spec');
  const [activeTab, setActiveTab] = useState<'lore' | 'how' | 'specs'>('lore');

  // Interactive Aura Color & Spell Casting Animation
  const [auraTheme, setAuraTheme] = useState<'gold' | 'violet' | 'cyan' | 'crimson'>('gold');
  const [isTestCasting, setIsTestCasting] = useState(false);
  const [castMessage, setCastMessage] = useState<string | null>(null);

  // Review Inscription Form
  const [isReviewFormOpen, setIsReviewFormOpen] = useState(false);
  const [newReviewRating, setNewReviewRating] = useState(5);
  const [newReviewTitle, setNewReviewTitle] = useState('');
  const [newReviewComment, setNewReviewComment] = useState('');
  const [newReviewAlias, setNewReviewAlias] = useState(user.alias || 'Adept Seeker');

  // Arcane Card 3D tilt state
  const cardRef = useRef<HTMLDivElement>(null);
  const [tilt, setTilt] = useState({ x: 0, y: 0, glareX: 50, glareY: 50 });

  const handleCardMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;

    const rotateX = ((y - centerY) / centerY) * -12;
    const rotateY = ((x - centerX) / centerX) * 12;

    setTilt({
      x: rotateX,
      y: rotateY,
      glareX: (x / rect.width) * 100,
      glareY: (y / rect.height) * 100,
    });
  };

  const handleCardMouseLeave = () => {
    setTilt({ x: 0, y: 0, glareX: 50, glareY: 50 });
  };

  const isWish = isInWishlist(product.id);
  const inCompare = isInCompare(product.id);

  const related = PRODUCTS.filter((p) => p.category === product.category && p.id !== product.id).slice(0, 3);

  // Filter reviews matching product or generic coven reviews
  const productReviews = reviews.filter(
    (r) => r.productName.toLowerCase() === product.name.toLowerCase()
  );
  const allDisplayReviews = productReviews.length > 0 ? productReviews : reviews.slice(0, 4);

  const handleEquip = () => {
    addToCart(product, quantity, selectedVariant);
  };

  const handleBuyNow = () => {
    addToCart(product, quantity, selectedVariant);
    navigateTo('checkout');
  };

  const handleTestCastSpell = () => {
    setIsTestCasting(true);
    triggerSoundFx('✦ SPELL INVOCATION TRIGGERED');
    setCastMessage('Concentrating mana... Spell circle materializing!');

    setTimeout(() => {
      setCastMessage('✦ Resonance 99.8% Harmonic! Cellular stabilization complete.');
      triggerSoundFx('✦ SPELL HARMONIZED');
    }, 1200);

    setTimeout(() => {
      setIsTestCasting(false);
      setTimeout(() => setCastMessage(null), 3000);
    }, 3200);
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReviewTitle.trim() || !newReviewComment.trim()) return;

    addCustomerReview(
      product.name,
      newReviewAlias,
      newReviewTitle,
      newReviewRating,
      newReviewComment
    );

    setIsReviewFormOpen(false);
    setNewReviewTitle('');
    setNewReviewComment('');
    triggerSoundFx('✦ ADEPT REVIEW INSCRIBED');
  };

  const auraColorMap = {
    gold: {
      border: 'border-[#D4AF37]',
      glow: 'shadow-[0_0_35px_rgba(212,175,55,0.4)]',
      accent: '#D4AF37',
    },
    violet: {
      border: 'border-[#C084FC]',
      glow: 'shadow-[0_0_35px_rgba(192,132,252,0.45)]',
      accent: '#C084FC',
    },
    cyan: {
      border: 'border-[#38BDF8]',
      glow: 'shadow-[0_0_35px_rgba(56,189,248,0.45)]',
      accent: '#38BDF8',
    },
    crimson: {
      border: 'border-[#FB7185]',
      glow: 'shadow-[0_0_35px_rgba(251,113,133,0.45)]',
      accent: '#FB7185',
    },
  };

  const activeAura = auraColorMap[auraTheme];

  return (
    <div className="min-h-screen bg-[#0d0814] dark:bg-[#050308] text-white py-8 transition-colors duration-400">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        {/* Navigation Breadcrumb */}
        <div className="flex items-center justify-between">
          <button
            onClick={() => navigateTo('shop')}
            className="flex items-center gap-2 text-xs font-whimsical uppercase tracking-wider text-purple-300 hover:text-[#FDE047] transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Return to Grimoire</span>
          </button>

          <div className="flex items-center gap-2 text-xs font-whimsical text-purple-300/70">
            <span className="capitalize">{product.category}</span>
            <span className="text-[#D4AF37]">✦</span>
            <span className="text-[#FDE047]">{product.name}</span>
          </div>
        </div>

        {/* Product Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          {/* LEFT: 3D Tarot Inspector */}
          <div className="lg:col-span-5 flex flex-col items-center">
            <div className="w-full max-w-md perspective-1000">
              <div
                ref={cardRef}
                onMouseMove={handleCardMouseMove}
                onMouseLeave={handleCardMouseLeave}
                style={{
                  transform: `perspective(1000px) rotateX(${tilt.x}deg) rotateY(${tilt.y}deg)`,
                  transition: 'transform 0.1s ease-out',
                }}
                className="relative rounded-3xl bg-[#170e24] border border-[#D4AF37]/50 p-5 arcane-card overflow-hidden select-none cursor-grab holographic-card"
              >
                {/* Dynamic Starlight Glare */}
                <div
                  className="pointer-events-none absolute inset-0 mix-blend-overlay opacity-50 transition-opacity"
                  style={{
                    background: `radial-gradient(circle at ${tilt.glareX}% ${tilt.glareY}%, rgba(253,224,71,0.6) 0%, rgba(168,85,247,0.25) 40%, transparent 80%)`,
                  }}
                />

                {/* Simulated Spell Invocation Overlay */}
                {isTestCasting && (
                  <div className="absolute inset-0 z-30 bg-black/60 backdrop-blur-xs flex flex-col items-center justify-center p-4 text-center pointer-events-none animate-in fade-in">
                    <div className="relative w-32 h-32 flex items-center justify-center">
                      <div className="absolute inset-0 rounded-full border-2 border-[#FDE047] animate-ping opacity-60" />
                      <div className="w-24 h-24 rounded-full border-2 border-dashed border-[#C084FC] animate-spin-slow flex items-center justify-center text-2xl">
                        ✨
                      </div>
                    </div>
                    <div className="mt-3 px-3 py-1 rounded-xl bg-black/90 border border-[#D4AF37] font-witch text-xs text-[#FDE047]">
                      Harmonizing Bio-Currents...
                    </div>
                  </div>
                )}

                {/* Card Top Header */}
                <div className="flex items-center justify-between pb-3 border-b border-[#2d1b46]">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-full font-whimsical text-[11px] uppercase bg-[#0d0814] text-[#FDE047] border border-[#D4AF37]/40">
                      {product.powerGrade}
                    </span>
                    <span className="font-witch text-base text-white truncate max-w-[180px]">
                      {product.name}
                    </span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-[#FDE047]" />
                    <span className="font-mono-nums text-xs text-[#FDE047] font-bold">
                      {product.powerLevel} Potency
                    </span>
                  </div>
                </div>

                {/* Relic Visual Window */}
                <div className={`relative aspect-[4/3] w-full mt-3 rounded-2xl overflow-hidden border ${activeAura.border} ${activeAura.glow} bg-[#0d0814] transition-all duration-500`}>
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-700"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-tr from-[#170e24]/40 via-transparent to-transparent pointer-events-none" />

                  <div className="absolute bottom-2 right-2 px-2 py-0.5 rounded-full bg-[#0d0814]/80 backdrop-blur-sm border border-[#D4AF37]/30 text-[10px] font-whimsical text-[#FDE047]">
                    {product.archetype}
                  </div>
                </div>

                {/* Aura Resonator Picker & Test Spell */}
                <div className="mt-3 p-2 rounded-xl bg-[#0d0814]/80 border border-[#2d1b46] flex items-center justify-between text-[11px] font-whimsical">
                  <div className="flex items-center gap-1.5">
                    <span className="opacity-70 text-[10px] uppercase">Aura Resonance:</span>
                    {(['gold', 'violet', 'cyan', 'crimson'] as const).map((col) => (
                      <button
                        key={col}
                        onClick={() => {
                          setAuraTheme(col);
                          triggerSoundFx('✦ Aura Attuned');
                        }}
                        className={`w-4 h-4 rounded-full border transition-transform ${
                          auraTheme === col ? 'scale-125 ring-2 ring-white/50' : 'opacity-60'
                        }`}
                        style={{
                          backgroundColor:
                            col === 'gold'
                              ? '#D4AF37'
                              : col === 'violet'
                              ? '#C084FC'
                              : col === 'cyan'
                              ? '#38BDF8'
                              : '#FB7185',
                        }}
                      />
                    ))}
                  </div>

                  <button
                    onClick={handleTestCastSpell}
                    disabled={isTestCasting}
                    className="px-2.5 py-1 rounded-lg bg-[#26183d] hover:bg-[#D4AF37] hover:text-black text-[#FDE047] border border-[#D4AF37]/40 font-bold transition-all flex items-center gap-1 disabled:opacity-50"
                  >
                    <Zap className="w-3 h-3" />
                    <span>Test Spell</span>
                  </button>
                </div>

                {/* Spell Cast Readout */}
                {castMessage && (
                  <div className="mt-2 p-2 rounded-xl bg-black/90 border border-[#FDE047] text-[11px] font-whimsical text-[#FDE047] text-center animate-in fade-in">
                    {castMessage}
                  </div>
                )}

                {/* Card Attributes */}
                <div className="mt-4 p-3 rounded-xl bg-[#0d0814] border border-[#2d1b46] space-y-1.5">
                  <div className="flex items-center justify-between text-xs font-whimsical">
                    <span className="text-purple-300/70">Incantation:</span>
                    <span className="text-[#FDE047] font-semibold">{product.magicType}</span>
                  </div>
                  <div className="flex items-center justify-between text-xs font-whimsical">
                    <span className="text-purple-300/70">Duration:</span>
                    <span className="text-purple-200">{product.duration}</span>
                  </div>
                </div>

                {/* Card Footer Stamp */}
                <div className="mt-4 pt-2 border-t border-[#2d1b46] flex items-center justify-between text-[10px] font-whimsical text-purple-300/60">
                  <span>GRIMOIRE #{product.id.toUpperCase()}</span>
                  <span className="text-[#FDE047] font-semibold">✦ {product.rarity}</span>
                </div>
              </div>
            </div>
            <p className="text-xs font-whimsical text-purple-300/60 mt-3 text-center">
              Hover card for interactive celestial sheen
            </p>
          </div>

          {/* RIGHT: Attributes & Purchase Module */}
          <div className="lg:col-span-7 space-y-6">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-whimsical uppercase tracking-wider text-[#FDE047]">
                  {product.category} · {product.rarity} · {product.archetype}
                </span>
                <button
                  onClick={() => {
                    navigator.clipboard?.writeText(window.location.href);
                    triggerSoundFx('✦ Rune Copied');
                  }}
                  className="p-1.5 rounded-lg text-purple-300 hover:text-white hover:bg-[#170e24] transition-colors"
                  title="Share Arcana"
                >
                  <Share2 className="w-4 h-4" />
                </button>
              </div>

              <h1 className="font-witch text-3xl sm:text-4xl text-white">
                {product.name}
              </h1>

              <div className="flex items-center gap-4 pt-1">
                <div className="font-witch text-3xl text-[#FDE047]">
                  ${product.price}
                </div>
                {product.originalPrice && (
                  <div className="text-sm font-mono-nums text-purple-300/50 line-through">
                    ${product.originalPrice}
                  </div>
                )}
                <span className="px-2.5 py-0.5 rounded-full text-xs font-whimsical text-emerald-300 bg-emerald-950/40 border border-emerald-500/30">
                  In Sanctum · Ready for Dispatch
                </span>
              </div>
            </div>

            {/* Arcane Potency Metrics */}
            <div className="p-5 rounded-2xl bg-[#170e24] border border-[#D4AF37]/30 space-y-3 arcane-card">
              <div className="flex items-center justify-between text-xs font-whimsical uppercase text-purple-200">
                <span className="font-semibold flex items-center gap-1.5 text-[#FDE047]">
                  <Sparkles className="w-3.5 h-3.5" /> Aura Resonance Metrics
                </span>
                <span className="text-[#FDE047] font-mono-nums">Total Potency: {product.powerLevel}</span>
              </div>

              <div className="space-y-2 pt-1 font-whimsical text-xs">
                <div>
                  <div className="flex justify-between mb-1 text-purple-200">
                    <span>Swiftness & Agility</span>
                    <span className="font-mono-nums text-[#FDE047]">{product.stats.speed} / 100</span>
                  </div>
                  <div className="w-full h-1.5 bg-[#0d0814] rounded-full overflow-hidden border border-[#2d1b46]">
                    <div className="h-full bg-gradient-to-r from-[#D4AF37] to-[#FDE047]" style={{ width: `${product.stats.speed}%` }} />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between mb-1 text-purple-200">
                    <span>Kinetic Force</span>
                    <span className="font-mono-nums text-[#FDE047]">{product.stats.power} / 100</span>
                  </div>
                  <div className="w-full h-1.5 bg-[#0d0814] rounded-full overflow-hidden border border-[#2d1b46]">
                    <div className="h-full bg-gradient-to-r from-[#A855F7] to-[#C084FC]" style={{ width: `${product.stats.power}%` }} />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between mb-1 text-purple-200">
                    <span>Mind & Divination</span>
                    <span className="font-mono-nums text-[#FDE047]">{product.stats.intelligence} / 100</span>
                  </div>
                  <div className="w-full h-1.5 bg-[#0d0814] rounded-full overflow-hidden border border-[#2d1b46]">
                    <div className="h-full bg-gradient-to-r from-[#8B5CF6] to-[#A855F7]" style={{ width: `${product.stats.intelligence}%` }} />
                  </div>
                </div>
              </div>
            </div>

            {/* Calibrated Dosage/Variant Selector */}
            {product.variants && product.variants.length > 0 && (
              <div className="space-y-2">
                <label className="block text-xs font-whimsical uppercase text-purple-300/70">
                  Select Calibrated Dosage:
                </label>
                <div className="flex flex-wrap gap-2">
                  {product.variants.map((v) => (
                    <button
                      key={v}
                      onClick={() => {
                        setSelectedVariant(v);
                        triggerSoundFx('✧ Dosage Adjusted');
                      }}
                      className={`px-3 py-1.5 text-xs font-whimsical rounded-xl border transition-all ${
                        selectedVariant === v
                          ? 'bg-[#D4AF37] text-black font-bold border-[#FDE047] shadow-[0_0_10px_rgba(212,175,55,0.3)]'
                          : 'bg-[#170e24] text-purple-200 border-[#2d1b46] hover:border-[#D4AF37]/50'
                      }`}
                    >
                      {v}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Quantity and Actions */}
            <div className="space-y-3 pt-2">
              <div className="flex items-center gap-3">
                <div className="flex items-center bg-[#170e24] border border-[#D4AF37]/40 rounded-xl p-1">
                  <button
                    onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                    className="w-8 h-8 flex items-center justify-center font-bold text-base text-purple-300 hover:text-white rounded"
                  >
                    -
                  </button>
                  <span className="w-8 text-center font-mono-nums text-sm font-bold text-[#FDE047]">
                    {quantity}
                  </span>
                  <button
                    onClick={() => setQuantity((q) => Math.min(10, q + 1))}
                    className="w-8 h-8 flex items-center justify-center font-bold text-base text-purple-300 hover:text-white rounded"
                  >
                    +
                  </button>
                </div>

                <button
                  onClick={handleEquip}
                  className="flex-1 py-3 px-6 rounded-xl font-whimsical text-xs uppercase tracking-wider text-black font-bold bg-[#D4AF37] hover:bg-[#FDE047] transition-all flex items-center justify-center gap-2 shadow-[0_0_16px_rgba(212,175,55,0.3)]"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>Attune to Satchel</span>
                </button>

                <button
                  onClick={() => toggleWishlist(product.id)}
                  className="p-3 rounded-xl bg-[#170e24] border border-[#D4AF37]/40 text-purple-200 hover:text-[#FDE047] transition-colors"
                >
                  <Heart className={`w-4 h-4 ${isWish ? 'fill-[#D4AF37] text-[#D4AF37]' : ''}`} />
                </button>

                {/* Compare in Web Map Button */}
                <button
                  onClick={() => {
                    if (inCompare) {
                      removeFromCompare(product.id);
                    } else {
                      addToCompare(product.id);
                    }
                  }}
                  className={`px-3 py-3 rounded-xl border font-whimsical text-xs transition-all flex items-center gap-1.5 ${
                    inCompare
                      ? 'bg-[#D4AF37] text-black border-[#FDE047] font-bold shadow-[0_0_12px_rgba(212,175,55,0.4)]'
                      : 'bg-[#170e24] border-[#D4AF37]/40 text-[#FDE047] hover:bg-[#D4AF37]/20'
                  }`}
                  title={inCompare ? 'Remove from Web Map' : 'Add to Web Map Compare'}
                >
                  <Layers className="w-4 h-4" />
                  <span className="hidden sm:inline">{inCompare ? 'In Web Map' : 'Compare'}</span>
                </button>
              </div>

              <button
                onClick={handleBuyNow}
                className="w-full py-3 px-6 rounded-xl font-whimsical text-xs uppercase tracking-wider text-white font-bold bg-[#7E22CE] hover:bg-[#9333EA] border border-[#A855F7]/60 transition-all flex items-center justify-center gap-2 shadow-[0_0_16px_rgba(147,51,234,0.3)]"
              >
                <Sparkles className="w-4 h-4 text-[#FDE047]" />
                <span>Instant Astral Dispatch →</span>
              </button>
            </div>

            {/* Tabs: Lore, Activation, Specs */}
            <div className="pt-3 border-t border-[#2d1b46] space-y-3">
              <div className="flex items-center gap-2 p-1 bg-[#170e24] rounded-xl border border-[#2d1b46]">
                <button
                  onClick={() => setActiveTab('lore')}
                  className={`flex-1 py-1.5 text-xs font-whimsical uppercase rounded-lg transition-colors ${
                    activeTab === 'lore' ? 'bg-[#D4AF37] text-black font-bold' : 'text-purple-300 hover:text-white'
                  }`}
                >
                  Coven Lore
                </button>
                <button
                  onClick={() => setActiveTab('how')}
                  className={`flex-1 py-1.5 text-xs font-whimsical uppercase rounded-lg transition-colors ${
                    activeTab === 'how' ? 'bg-[#D4AF37] text-black font-bold' : 'text-purple-300 hover:text-white'
                  }`}
                >
                  Activation
                </button>
                <button
                  onClick={() => setActiveTab('specs')}
                  className={`flex-1 py-1.5 text-xs font-whimsical uppercase rounded-lg transition-colors ${
                    activeTab === 'specs' ? 'bg-[#D4AF37] text-black font-bold' : 'text-purple-300 hover:text-white'
                  }`}
                >
                  Properties
                </button>
              </div>

              <div className="p-4 rounded-xl bg-[#170e24]/70 border border-[#2d1b46] text-xs font-whimsical text-purple-200/90 leading-relaxed min-h-[90px]">
                {activeTab === 'lore' && (
                  <div className="space-y-1.5">
                    <p>{product.lore}</p>
                    <p className="text-purple-300/60 italic">Attunement: {product.compatibility}</p>
                  </div>
                )}
                {activeTab === 'how' && (
                  <div className="space-y-1.5">
                    <div className="text-[#FDE047] font-bold">Ritual Protocol:</div>
                    <p>{product.howItWorks}</p>
                  </div>
                )}
                {activeTab === 'specs' && (
                  <div className="grid grid-cols-2 gap-2 font-whimsical">
                    {product.specs.map((s, idx) => (
                      <div key={idx} className="p-2 rounded-lg bg-[#0d0814] border border-[#2d1b46]">
                        <span className="text-purple-300/60 block text-[10px] uppercase">{s.label}</span>
                        <span className="text-[#FDE047] font-semibold">{s.value}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Delivery Markers */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 text-xs font-whimsical text-purple-300/70">
              <div className="flex items-center gap-2 p-2.5 rounded-xl bg-[#170e24] border border-[#2d1b46]">
                <Truck className="w-3.5 h-3.5 text-[#FDE047]" />
                <span>Astral Courier Dispatch</span>
              </div>
              <div className="flex items-center gap-2 p-2.5 rounded-xl bg-[#170e24] border border-[#2d1b46]">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Runically Warded Glass</span>
              </div>
              <div className="flex items-center gap-2 p-2.5 rounded-xl bg-[#170e24] border border-[#2d1b46]">
                <RotateCcw className="w-3.5 h-3.5 text-[#FDE047]" />
                <span>Full Lunar Attunement Guarantee</span>
              </div>
            </div>
          </div>
        </div>

        {/* Customer Reviews & Revelations Section */}
        <div className="pt-10 border-t border-[#2d1b46] space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span className="text-xs font-whimsical uppercase text-[#FDE047]">
                Adept Testimonials
              </span>
              <h3 className="font-witch text-2xl text-white">
                Grimoire Reviews for {product.name}
              </h3>
            </div>

            <button
              onClick={() => setIsReviewFormOpen(!isReviewFormOpen)}
              className="px-4 py-2 rounded-xl bg-[#D4AF37] hover:bg-[#FDE047] text-black font-whimsical text-xs font-bold uppercase tracking-wider transition-all hover:scale-105 flex items-center gap-2 shadow-[0_0_12px_rgba(212,175,55,0.3)] self-start sm:self-auto"
            >
              <MessageSquarePlus className="w-4 h-4" />
              <span>{isReviewFormOpen ? 'Cancel Inscription' : 'Inscribe Adept Review'}</span>
            </button>
          </div>

          {/* Inline Review Inscription Form */}
          {isReviewFormOpen && (
            <form
              onSubmit={handleReviewSubmit}
              className="p-5 sm:p-6 rounded-2xl border border-[#D4AF37] bg-[#170e24] space-y-4 text-xs font-whimsical animate-in fade-in"
            >
              <div className="flex items-center justify-between">
                <span className="font-witch text-base text-[#FDE047]">
                  Inscribe New Relic Review
                </span>
                <span className="text-purple-300/70">Warded by High Coven</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block mb-1 text-purple-300 font-semibold">
                    Reviewer Alias:
                  </label>
                  <input
                    type="text"
                    required
                    value={newReviewAlias}
                    onChange={(e) => setNewReviewAlias(e.target.value)}
                    placeholder="e.g. Master Alchemist Bathija"
                    className="w-full px-3 py-2 rounded-xl bg-black/40 border border-[#2d1b46] text-white focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>

                <div>
                  <label className="block mb-1 text-purple-300 font-semibold">
                    Resonance Potency Rating:
                  </label>
                  <div className="flex items-center gap-1.5 py-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        type="button"
                        key={star}
                        onClick={() => setNewReviewRating(star)}
                        className="p-1 text-[#FDE047] hover:scale-125 transition-transform"
                      >
                        <Star
                          className={`w-5 h-5 ${
                            star <= newReviewRating ? 'fill-current text-[#FDE047]' : 'text-purple-300/30'
                          }`}
                        />
                      </button>
                    ))}
                    <span className="ml-2 font-bold text-sm text-[#FDE047]">
                      {newReviewRating} / 5 Stars
                    </span>
                  </div>
                </div>
              </div>

              <div>
                <label className="block mb-1 text-purple-300 font-semibold">
                  Review Inscription Title:
                </label>
                <input
                  type="text"
                  required
                  value={newReviewTitle}
                  onChange={(e) => setNewReviewTitle(e.target.value)}
                  placeholder="e.g. Unbelievable sensory expansion upon drinking"
                  className="w-full px-3 py-2 rounded-xl bg-black/40 border border-[#2d1b46] text-white focus:outline-none focus:border-[#D4AF37]"
                />
              </div>

              <div>
                <label className="block mb-1 text-purple-300 font-semibold">
                  Arcane Field Test Observations:
                </label>
                <textarea
                  required
                  rows={3}
                  value={newReviewComment}
                  onChange={(e) => setNewReviewComment(e.target.value)}
                  placeholder="Describe the cellular sensation, duration, flight thermals, or aura color..."
                  className="w-full px-3 py-2 rounded-xl bg-black/40 border border-[#2d1b46] text-white focus:outline-none focus:border-[#D4AF37]"
                />
              </div>

              <div className="flex justify-end">
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-[#D4AF37] hover:bg-[#FDE047] text-black font-bold uppercase tracking-wider flex items-center gap-2"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Bind Review to Grimoire</span>
                </button>
              </div>
            </form>
          )}

          {/* Reviews List */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {allDisplayReviews.map((rev) => (
              <div
                key={rev.id}
                className="p-4 sm:p-5 rounded-2xl bg-[#170e24] border border-[#2d1b46] space-y-3 font-whimsical"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1 text-[#FDE047]">
                    {[...Array(rev.rating)].map((_, i) => (
                      <Star key={i} className="w-3.5 h-3.5 fill-current" />
                    ))}
                  </div>
                  <span className="text-[11px] text-purple-300/50 font-mono-nums">
                    {rev.date}
                  </span>
                </div>

                <div>
                  <h4 className="font-witch text-sm text-white font-bold">{rev.title}</h4>
                  <p className="text-xs text-purple-200/80 mt-1 leading-relaxed">
                    "{rev.comment}"
                  </p>
                </div>

                <div className="pt-2 border-t border-[#2d1b46]/60 flex items-center justify-between text-[11px] text-purple-300/70">
                  <span className="font-semibold text-[#D4AF37]">✦ {rev.author}</span>
                  {rev.badge && (
                    <span className="flex items-center gap-1 text-emerald-400">
                      <ShieldCheck className="w-3 h-3" />
                      <span>{rev.badge}</span>
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Related Powers */}
        {related.length > 0 && (
          <div className="pt-10 border-t border-[#2d1b46] space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-whimsical uppercase text-[#FDE047]">Resonant Frequencies</span>
                <h3 className="font-witch text-2xl text-white">Related {product.category} Arcana</h3>
              </div>
              <button
                onClick={() => navigateTo('category', { categoryId: product.category })}
                className="text-xs font-whimsical text-[#FDE047] hover:underline"
              >
                View Full Grimoire →
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {related.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
