import React, { useEffect, useState, useRef } from 'react';
import { useSuper } from '../context/SuperContext';

interface TwinkleStar {
  id: number;
  x: number;
  y: number;
  size: number;
  color: string;
  opacity: number;
  rotation: number;
  rotationSpeed: number;
  type: 'sparkle' | 'star8' | 'moon' | 'dot';
  vx: number;
  vy: number;
}

export const CustomCursor: React.FC = () => {
  const { isVillainMode } = useSuper();
  const [pos, setPos] = useState({ x: -100, y: -100 });
  const [isVisible, setIsVisible] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const [isClicking, setIsClicking] = useState(false);
  const [stars, setStars] = useState<TwinkleStar[]>([]);
  const lastSpawnRef = useRef(0);
  const lastPosRef = useRef({ x: -100, y: -100 });

  useEffect(() => {
    const onPointerMove = (e: PointerEvent | MouseEvent) => {
      const curX = e.clientX;
      const curY = e.clientY;
      setPos({ x: curX, y: curY });
      if (!isVisible) setIsVisible(true);

      const dist = Math.hypot(curX - lastPosRef.current.x, curY - lastPosRef.current.y);
      const now = performance.now();

      // Emit glowing stardust, stars, and crescent moon particles as cursor travels
      if (dist > 4 && now - lastSpawnRef.current > 20) {
        lastSpawnRef.current = now;
        lastPosRef.current = { x: curX, y: curY };

        // Gold and celestial violet starlight palette
        const goldPalette = ['#FDE047', '#F59E0B', '#D4AF37', '#FEF08A', '#FFFBEB'];
        const violetPalette = isVillainMode
          ? ['#C084FC', '#A855F7', '#E879F9', '#F43F5E', '#FDE047']
          : ['#E9D5FF', '#C084FC', '#D4AF37', '#FDE047', '#FBBF24'];

        const palette = Math.random() > 0.35 ? goldPalette : violetPalette;
        const color = palette[Math.floor(Math.random() * palette.length)];

        const types: ('sparkle' | 'star8' | 'moon' | 'dot')[] = [
          'sparkle',
          'star8',
          'dot',
          'moon',
          'sparkle',
        ];
        const chosenType = types[Math.floor(Math.random() * types.length)];

        const size =
          chosenType === 'dot'
            ? Math.random() * 4 + 3
            : chosenType === 'moon'
            ? Math.random() * 12 + 10
            : Math.random() * 14 + 10;

        const newStar: TwinkleStar = {
          id: now + Math.random(),
          x: curX + (Math.random() * 14 - 7),
          y: curY + (Math.random() * 14 - 7),
          size,
          color,
          opacity: 1,
          rotation: Math.random() * 360,
          rotationSpeed: (Math.random() - 0.5) * 6,
          type: chosenType,
          vx: (Math.random() - 0.5) * 1.2,
          vy: (Math.random() - 0.5) * 1.2 - 0.4, // float upwards like incense and stardust
        };

        setStars((prev) => [...prev.slice(-45), newStar]);
      }

      // Check interactive hover target
      const target = e.target as HTMLElement;
      if (
        target &&
        (target.tagName === 'BUTTON' ||
          target.tagName === 'A' ||
          target.tagName === 'INPUT' ||
          target.tagName === 'SELECT' ||
          target.tagName === 'TEXTAREA' ||
          target.closest('button') ||
          target.closest('a') ||
          target.getAttribute('role') === 'button' ||
          target.classList.contains('cursor-pointer'))
      ) {
        setIsHovered(true);
      } else {
        setIsHovered(false);
      }
    };

    const onPointerDown = (e: MouseEvent) => {
      setIsClicking(true);

      // Celestial burst on click: spawn 8 glowing stars and crescent moons in a circle
      const now = performance.now();
      const burstStars: TwinkleStar[] = [];
      const count = 10;

      for (let i = 0; i < count; i++) {
        const angle = (i / count) * 2 * Math.PI;
        const speed = Math.random() * 2.5 + 1.5;
        const isMoon = i % 3 === 0;

        burstStars.push({
          id: now + i + Math.random(),
          x: e.clientX,
          y: e.clientY,
          size: isMoon ? 14 : Math.random() * 12 + 10,
          color: i % 2 === 0 ? '#FDE047' : '#C084FC',
          opacity: 1,
          rotation: Math.random() * 360,
          rotationSpeed: (Math.random() - 0.5) * 10,
          type: isMoon ? 'moon' : 'sparkle',
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
        });
      }

      setStars((prev) => [...prev.slice(-35), ...burstStars]);
    };

    const onPointerUp = () => setIsClicking(false);

    window.addEventListener('mousemove', onPointerMove, { passive: true });
    window.addEventListener('pointermove', onPointerMove, { passive: true });
    window.addEventListener('mousedown', onPointerDown);
    window.addEventListener('mouseup', onPointerUp);

    return () => {
      window.removeEventListener('mousemove', onPointerMove);
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('mousedown', onPointerDown);
      window.removeEventListener('mouseup', onPointerUp);
    };
  }, [isVisible, isVillainMode]);

  // Smooth animation frame ticker for starlight drift and fade
  useEffect(() => {
    let animationFrameId: number;

    const tick = () => {
      setStars((prev) =>
        prev
          .map((s) => ({
            ...s,
            x: s.x + s.vx,
            y: s.y + s.vy,
            opacity: s.opacity - 0.022, // graceful decay
            size: s.size * 0.985,
            rotation: s.rotation + s.rotationSpeed,
          }))
          .filter((s) => s.opacity > 0.04)
      );

      animationFrameId = requestAnimationFrame(tick);
    };

    animationFrameId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(animationFrameId);
  }, []);

  const cursorGold = isVillainMode ? '#FBBF24' : '#FDE047';

  return (
    <div className="pointer-events-none fixed inset-0 z-[99999] overflow-hidden">
      {/* Twinkling Traveling Stars & Crescent Moons */}
      {stars.map((star) => (
        <div
          key={star.id}
          className="absolute transform -translate-x-1/2 -translate-y-1/2 pointer-events-none transition-none"
          style={{
            left: star.x,
            top: star.y,
            width: `${star.size}px`,
            height: `${star.size}px`,
            opacity: star.opacity,
            transform: `translate(-50%, -50%) rotate(${star.rotation}deg)`,
            filter: `drop-shadow(0 0 6px ${star.color})`,
          }}
        >
          {star.type === 'dot' ? (
            <div
              className="w-full h-full rounded-full"
              style={{
                backgroundColor: star.color,
                boxShadow: `0 0 6px ${star.color}`,
              }}
            />
          ) : star.type === 'moon' ? (
            // Crescent Moon particle
            <svg viewBox="0 0 24 24" className="w-full h-full" fill={star.color}>
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10c4.14 0 7.7-2.52 9.2-6.17-.4.07-.81.11-1.2.11-5.52 0-10-4.48-10-10 0-2.39.84-4.58 2.25-6.31C12.87 2.13 12.44 2 12 2z" />
            </svg>
          ) : star.type === 'star8' ? (
            // 8-point celestial star
            <svg viewBox="0 0 24 24" className="w-full h-full" fill={star.color}>
              <path d="M12 0L13.8 8.2L22 10L14.8 13.8L16 22L11 15.5L4 20L7.5 12.8L0 12L8 8.5L12 0Z" />
            </svg>
          ) : (
            // 4-point magical starlight spark
            <svg viewBox="0 0 24 24" className="w-full h-full" fill={star.color}>
              <path d="M12 0L14.2 9.8L24 12L14.2 14.2L12 24L9.8 14.2L0 12L9.8 9.8L12 0Z" />
            </svg>
          )}
        </div>
      ))}

      {/* Main Witchy Cursor Wand: Radiant Golden Moon + Star Cross */}
      {isVisible && (
        <div
          className="absolute transform -translate-x-1/2 -translate-y-1/2 pointer-events-none transition-transform duration-75 ease-out"
          style={{
            left: pos.x,
            top: pos.y,
            transform: `translate(-50%, -50%) scale(${isClicking ? 0.75 : isHovered ? 1.35 : 1})`,
          }}
        >
          <div className="relative flex items-center justify-center">
            {/* Pulsing Starlight Aura Glow */}
            <div
              className="absolute w-8 h-8 rounded-full blur-[6px] opacity-70 animate-pulse"
              style={{
                backgroundColor: isVillainMode ? '#C084FC' : '#FDE047',
              }}
            />

            {/* Witchy Moon + Star Wand Cursor Icon */}
            <div className="relative flex items-center justify-center filter drop-shadow-[0_0_8px_rgba(253,224,71,0.9)]">
              {/* Crescent Moon Backdrop */}
              <svg
                className="w-7 h-7 text-[#D4AF37] transition-all"
                viewBox="0 0 24 24"
                fill="currentColor"
              >
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10c4.14 0 7.7-2.52 9.2-6.17-.4.07-.81.11-1.2.11-5.52 0-10-4.48-10-10 0-2.39.84-4.58 2.25-6.31C12.87 2.13 12.44 2 12 2z" />
              </svg>

              {/* Radiant Centered 4-point Star */}
              <svg
                className="w-4 h-4 absolute text-white"
                viewBox="0 0 24 24"
                fill="currentColor"
              >
                <path d="M12 1L13.9 9.1L22 11L13.9 12.9L12 21L10.1 12.9L2 11L10.1 9.1L12 1Z" />
              </svg>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
